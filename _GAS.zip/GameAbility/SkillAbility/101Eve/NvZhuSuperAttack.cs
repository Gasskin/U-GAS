using System;
using System.Collections.Generic;
using cfg.gas;
using MemoryPack;
using Meow.Runtime.AOT;
using Meow.Runtime.HotUpdate.BattleConfig;
using Meow.Runtime.HotUpdate.BattleConfig.skill;

namespace Meow.Runtime.HotUpdate
{
    [Serializable]
    [MemoryPackable]
    public partial class NvZhuSuperAttack : SkillAbility
    {
        public GameEffectAssetIdRef buff;

        public override void ApplyCost(GameAbilitySystem owner, SkillConfig config, IEnumerable<GameEffectObjectField> costs)
        {
            if (costs == null)
            {
                return;
            }
            base.ApplyCost(owner, config, costs);
            // 处于奥义状态，扣除一层奥义层数
            if (owner.GameTagComponent.HasTag(EGameTag.State_Buff_Eve_Ultimate))
            {
                owner.GameEffectComponent.RemoveStackedGameEffectByAssetId(buff.assetId, 1);
            }
        }
    }
}