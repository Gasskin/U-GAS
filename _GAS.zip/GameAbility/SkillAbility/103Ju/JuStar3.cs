using MemoryPack;
using Meow.Runtime.AOT;
using Meow.Runtime.HotUpdate.BattleConfig.skill;
using Sirenix.OdinInspector;
using System;
using System.Collections.Generic;

namespace Meow.Runtime.HotUpdate
{
    [Serializable]
    [MemoryPackable]
    public partial class JuStar3 : SkillAbility
    {
        [LabelText("消耗替换")]
        public List<GameEffectObjectField> changeCosts;
        public override bool CheckCost(GameAbilitySystem owner, IEnumerable<GameEffectObjectField> costs)
        {
            if (costs == null)
            {
                return true;
            }
            var hasBuff = owner.GameTagComponent.HasTag(EGameTag.State_HeroStar3);
            if (hasBuff)
            {
                foreach (var cost in changeCosts)
                {
                    if (!CheckOneCost(owner, cost))
                    {
                        return false;
                    }
                }
            }
            else
            {
                foreach (var cost in costs)
                {
                    if (!CheckOneCost(owner, cost))
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        public override void ApplyCost(GameAbilitySystem owner, SkillConfig config, IEnumerable<GameEffectObjectField> costs)
        {
            if (costs == null)
            {
                return;
            }
            var hasBuff = owner.GameTagComponent.HasTag(EGameTag.State_HeroStar3);
            if (hasBuff)
            {
                foreach (var cost in changeCosts)
                {
                    owner.ApplyGameEffectTo(cost, owner);
                }
            }
            else
            {
                foreach (var cost in costs)
                {
                    owner.ApplyGameEffectTo(cost, owner);
                }
            }
        }

        private bool CheckOneCost(GameAbilitySystem owner, GameEffect cost)
        {
            if (cost == null)
            {
                return true;
            }

            var spec = cost.CreateSpec(owner, owner);
            var hasBuff = owner.GameTagComponent.HasTag(EGameTag.State_HeroStar1);
            if (spec.CanApply() && !spec.IsImmune())
            {
                foreach (var modifier in spec.GameEffect.modifiers)
                {
                    if (modifier.operation != EModifierOperation.Minus)
                    {
                        GameLog.Error("CheckCost modifier的操作类型只能为：减");
                        AOT.GenericPool<GameEffectSpec>.Release(spec);
                        return false;
                    }
                    var costValue = modifier.magnitude.CalculateMagnitude(spec);
                    var current = owner.GameAttributeComponent.GetCurrentValue(modifier.attribute);
                    if (current < costValue)
                    {
                        AOT.GenericPool<GameEffectSpec>.Release(spec);
                        return false;
                    }
                }
            }

            AOT.GenericPool<GameEffectSpec>.Release(spec);
            return true;
        }
    }
}