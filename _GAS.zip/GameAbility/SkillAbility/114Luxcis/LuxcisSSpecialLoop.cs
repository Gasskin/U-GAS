using System;
using System.Collections.Generic;
using MemoryPack;
using Meow.Runtime.HotUpdate.BattleConfig;

namespace Meow.Runtime.HotUpdate
{
    [Serializable]
    [MemoryPackable]
    public partial class LuxcisSSpecialLoop : SkillAbility
    {
        public GameEffectAssetIdRef buff;

        public override bool CheckCost(GameAbilitySystem owner, IEnumerable<GameEffectObjectField> costs)
        {
            var spec = owner.GameEffectComponent.GetGameEffectSpecByAssetId(buff.assetId);
            if (spec != null && spec.StackCount == spec.GameEffect.stack.maxCount)
            {
                return false;
            }
            return base.CheckCost(owner, costs);
        }
    }
}