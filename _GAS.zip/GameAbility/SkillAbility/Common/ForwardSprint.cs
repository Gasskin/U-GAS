using System;
using System.Collections.Generic;
using MemoryPack;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    [Serializable]
    [MemoryPackable]
    public partial class ForwardSprint: SkillAbility
    {
        public override bool CheckCost(GameAbilitySystem owner, IEnumerable<GameEffectObjectField> costs)
        {
            var map = InGameDomain.InputService.GetMap<BasicMap>();
            var v = map.Move.ReadValue<Vector2>();
            if (v == Vector2.zero)
            {
                return false;
            }
            return base.CheckCost(owner,costs);
        }
    }
}