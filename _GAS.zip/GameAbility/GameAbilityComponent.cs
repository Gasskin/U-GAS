﻿using System.Collections.Generic;
using Animancer;
using Meow.Runtime.AOT;
using Meow.Runtime.HotUpdate.BattleConfig;

namespace Meow.Runtime.HotUpdate
{
    public class GameAbilityComponent
    {
        private Dictionary<int, GameAbilitySpec> _abilities = new();
        private GameAbilitySystem _owner;

        private int _tid;

        // 暂时没有SkillId的意义，随便实现一下，后续可能扩展
        private int _skillId = -1;

        public void OnStart(GameAbilitySystem owner, int tid)
        {
            _tid = tid;
            _owner = owner;

            // 角色专属
            if (TbHeroAbilityCollection.Instance.DataMap.TryGetValue(_tid, out var cfg))
            {
                foreach (var a in cfg.gameAbilities)
                {
                    if (!a.CanAdd(_owner))
                    {
                        continue;
                    }
                    AddGameAbility(_skillId--, a);
                }
            }
            // 角色通用技能
            if (World.Current.TryGetEntityComp(_owner.Entity, out HeroUnitComp _))
            {
                // -2是约定值
                if (TbHeroAbilityCollection.Instance.DataMap.TryGetValue(-2, out var commonCfg))
                {
                    foreach (var a in commonCfg.gameAbilities)
                    {
                        if (!a.CanAdd(_owner))
                        {
                            continue;
                        }
                        AddGameAbility(_skillId--, a);
                    }
                }
            }
            // 怪物通用技能
            else if (World.Current.TryGetEntityComp(_owner.Entity, out MonsterUnitComp _))
            {
                // -3是约定值
                if (TbHeroAbilityCollection.Instance.DataMap.TryGetValue(-3, out var commonCfg))
                {
                    foreach (var a in commonCfg.gameAbilities)
                    {
                        if (!a.CanAdd(_owner))
                        {
                            continue;
                        }
                        AddGameAbility(_skillId--, a);
                    }
                }
            }
        }

        public void OnDispose()
        {
            foreach (var spec in _abilities.Values)
            {
                spec.DeActive();
                spec.Remove();
            }
            _abilities.Clear();
        }

        public void OnEnable()
        {
            foreach (var ability in _abilities.Values)
            {
                ability.Active();
            }
        }

        public void OnDisable()
        {
            foreach (var ability in _abilities.Values)
            {
                ability.DeActive();
            }
        }

        public void Update(float dt)
        {
            var list = UnityEngine.Pool.ListPool<GameAbilitySpec>.Get();
            list.AddRange(_abilities.Values);
            for (int i = 0; i < list.Count; i++)
            {
                list[i].Tick(dt);
            }
            UnityEngine.Pool.ListPool<GameAbilitySpec>.Release(list);
        }

        /// <summary>
        /// 配置的SkillId从-1开始递减，由Timeline动态添加的SkillId就是SkillConfig上配置的SkillId
        /// </summary>
        /// <param name="id"></param>
        /// <param name="ability"></param>
        /// <returns></returns>
        private void AddGameAbility(int id, GameAbility ability)
        {
            if (_abilities.ContainsKey(id))
            {
                GameLog.Error($"[GameAbility] 添加重复技能：{id}");
                return;
            }
            var spec = ability.CreateSpec(_owner);
            spec.Add(id, null);
            spec.Active();
            _abilities[id] = spec;
        }

        /// <summary>
        /// 通过GameEffect添加的Ability，不会自动Active，随GE一起Active/DeActive
        /// </summary>
        /// <param name="ability"></param>
        /// <returns></returns>
        public GameAbilitySpec AddGameAbilityByGameEffect(GameEffectSpec ge, GameAbility ability)
        {
            var id = _skillId;
            if (_abilities.ContainsKey(id))
            {
                GameLog.Error($"[GameAbility] 添加重复技能：{id}");
                return null;
            }
            var spec = ability.CreateSpec(_owner);
            spec.Add(id, ge);
            _abilities[id] = spec;
            return spec;
        }

        public void RemoveGameAbility(GameAbilitySpec a)
        {
            if (_abilities.Remove(a.Id, out var spec))
            {
                spec.DeActive();
                spec.Remove();
            }
        }

        public GameAbilitySpec GetGameAbilitySpec(int id)
        {
            return _abilities.GetValueOrDefault(id, null);
        }


        public bool CheckCosts(IEnumerable<GameEffectObjectField> costs)
        {
            if (costs == null)
            {
                return true;
            }
            foreach (var cost in costs)
            {
                if (!CheckOneCost(cost))
                {
                    return false;
                }
            }
            return true;
        }

        private bool CheckOneCost(GameEffect cost)
        {
            if (cost == null)
            {
                return true;
            }

            var spec = cost.CreateSpec(_owner, _owner);

            if (spec.CanApply() && !spec.IsImmune())
            {
                foreach (var modifier in spec.GameEffect.modifiers)
                {
                    if (modifier.operation != EModifierOperation.Minus)
                    {
                        GameLog.Error("CheckCost modifier的操作类型只能为：减");
                        return false;
                    }
                    var costValue = modifier.magnitude.CalculateMagnitude(spec);
                    var current = _owner.GameAttributeComponent.GetCurrentValue(modifier.attribute);
                    if (current < costValue)
                    {
                        return false;
                    }
                }
                return true;
            }

            GenericPool<GameEffectSpec>.Release(spec);
            return true;
        }
    }
}