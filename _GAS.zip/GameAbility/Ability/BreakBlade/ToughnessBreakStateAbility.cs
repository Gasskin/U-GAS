using System;
using System.Collections.Generic;
using MemoryPack;
using Sirenix.OdinInspector;
using Meow.Runtime.AOT;
using cfg.attribute;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 破韧状态管理 - 监听韧性值变化，管理破刃状态效果
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public sealed partial class ToughnessBreakStateAbility : GameAbility
    {
        [Title("破韧状态配置")]
        [LabelText("破刃状态效果")]
        [Tooltip("韧性值为0时施加的破刃状态")]
        public GameEffectObjectField breakBladeStatusEffect;


        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new ToughnessBreakStateAbilitySpec(this, owner);
        }
    }

    /// <summary>
    /// 破韧状态管理技能执行器
    /// </summary>
    public class ToughnessBreakStateAbilitySpec : GameAbilitySpec
    {
        private ToughnessBreakStateAbility _ability;
        private GameAbilitySystem _owner;
        private GameAbilitySystem _source;
        private EventGroup _eventGroup;
        private bool _isBroken = false;
        private Action<GameEffectSpec, ToughnessReduceEvent> _toughnessBreakCallback;
        private int _currentSkillDbId = 0; // 保存当前触发破韧的技能ID
        private ulong _breakBladeStatusId; //破韧状态  GE  id


        public ToughnessBreakStateAbilitySpec(ToughnessBreakStateAbility ability, GameAbilitySystem owner) : base(ability, owner)
        {
            _ability = ability;
            _owner = owner;
            _eventGroup = new EventGroup();
        }

        protected override void OnActive()
        {
            // 注册破韧事件监听
            ToughnessPipeline.Instance.OnToughnessBreak += OnToughnessBreak;
            GameEffectPipeline.Instance.OnPostRemoveGameEffect += OnPostRemoveGameEffect;
        }

        private void OnPostRemoveGameEffect(GameEffectSpec spec)
        {
            if (spec.Target == owner && _breakBladeStatusId == spec.Id)
            {
                var toughnessAttr = owner.GameAttributeComponent.GetAttribute(AttributeId.NowTough);
                if (toughnessAttr == null)
                {
                    GameLog.Warning("[ToughnessPipeline] 没有韧性值属性，跳过处理");
                    return;
                }
                var maxValue = owner.GameAttributeComponent.GetCurrentValue(AttributeId.ToughMax);
                toughnessAttr.SetBaseValue(maxValue);
                World.Current.TryGetEntityComp<CharacterControllerComponent>(_owner.Entity, out var ccc);
                ccc.FsmComp.ExitState(ECharacterStateType.Weakened);
                World.Current.TryGetEntityComp<AIComp>(_owner.Entity, out var aiComp);
                aiComp.SetAITargetState(true);
                ToughnessRecoverStateChanged.SendMsg(_owner.Entity, false, _ability.breakBladeStatusEffect.effect.duration);
            }
        }

        protected override void OnDeActive()
        {
            // 移除破韧事件监听
            ToughnessPipeline.Instance.OnToughnessBreak -= OnToughnessBreak;
            // _owner.GameEffectComponent.OnGameEffectDirty -= OnGameEffectDirty;
            GameEffectPipeline.Instance.OnPostRemoveGameEffect -= OnPostRemoveGameEffect;
            _eventGroup.RemoveAllListener();
        }

        protected override void OnTick(float dt)
        {
            // 被动技能，不需要主动更新
        }

        /// <summary>
        /// 破韧事件触发处理
        /// </summary>
        private void OnToughnessBreak(GameEffectSpec spec, ToughnessReduceEvent e)
        {
            _source = e.sourceSpec.Source;
            if (e.target == _owner.Entity && e.isBreakTriggered)
            {
                // 保存触发破韧的技能ID
                _currentSkillDbId = e.skillDbId;
                TriggerBreakBlade();
            }
        }

        /// <summary>
        /// 触发破刃效果
        /// </summary>
        private void TriggerBreakBlade()
        {
            _isBroken = true;
            World.Current.TryGetEntityComp<UnitGameObjectComp>(_owner.Entity, out var comp);
            var context = new GameEffectContext
            {
                hitPoint = comp.Root.transform.position,
                skillDbId = _currentSkillDbId // 传递触发破韧的技能ID
            };

            // 施加破刃状态效果
            if (_ability.breakBladeStatusEffect != null)
            {
                ToughnessRecoverStateChanged.SendMsg(_owner.Entity, true, _ability.breakBladeStatusEffect.effect.duration);
                _breakBladeStatusId = _source.ApplyGameEffectTo(_ability.breakBladeStatusEffect.effect, _owner);
            }

            GameLog.Info($"[ToughnessBreak] {_owner} 进入破刃状态，触发技能ID: {_currentSkillDbId}");
        }
    }
}