using System;
using MemoryPack;
using Sirenix.OdinInspector;
using Meow.Runtime.AOT;
using cfg.attribute;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 击破伤害 - 监听破韧事件，触发击破伤害效果
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public sealed partial class BreakBladeAbility : GameAbility
    {
        [Title("击破伤害配置")]
        [LabelText("击破伤害效果")]
        [Tooltip("触发破韧时造成的伤害")]
        public GameEffectObjectField breakBladeDamageEffect;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new BreakBladeAbilitySpec(this, owner);
        }
    }

    /// <summary>
    /// 击破伤害技能执行器
    /// </summary>
    public class BreakBladeAbilitySpec : GameAbilitySpec
    {
        private BreakBladeAbility _ability;
        private GameAbilitySystem _owner;
        private EventGroup _eventGroup;

        public BreakBladeAbilitySpec(BreakBladeAbility ability, GameAbilitySystem owner) : base(ability, owner)
        {
            _ability = ability;
            _owner = owner;
            _eventGroup = new EventGroup();
        }

        protected override void OnActive()
        {
            // 注册破韧事件监听
            ToughnessPipeline.Instance.OnToughnessBreak += OnToughnessBreak;
        }

        protected override void OnDeActive()
        {
            // 移除破韧事件监听
            ToughnessPipeline.Instance.OnToughnessBreak -= OnToughnessBreak;
            _eventGroup.RemoveAllListener();
        }

        protected override void OnTick(float dt)
        {
            // 被动技能，不需要主动更新
        }

        /// <summary>
        /// 破韧事件触发处理 - 专门处理击破伤害
        /// </summary>
        private void OnToughnessBreak(GameEffectSpec spec, ToughnessReduceEvent e)
        {
            if (spec.Source == _owner && e.isBreakTriggered)
            {
                TriggerBreakBladeDamage(e);
            }
        }

        /// <summary>
        /// 触发击破伤害效果
        /// </summary>
        private void TriggerBreakBladeDamage(ToughnessReduceEvent e)
        {
            if (_ability.breakBladeDamageEffect == null)
            {
                return;
            }

            // 获取目标位置
            World.Current.TryGetEntityComp<UnitGameObjectComp>(e.target, out var comp);
            var context = new GameEffectContext
            {
                hitPoint = comp.Root.transform.position,
                skillDbId = e.skillDbId // 传递触发破韧的技能ID
            };
            World.Current.TryGetEntityComp<CharacterControllerComponent>(e.target, out var ccc);
            ccc.FsmComp.TryEnterState(ECharacterStateType.Weakened);
            World.Current.TryGetEntityComp<AIComp>(e.target, out var aiComp);
            aiComp.SetAITargetState(false);
            // 造成击破伤害
            if (World.Current.TryGetEntityComp<GameAbilitySystem>(e.target, out var target))
            {
                owner.ApplyGameEffectTo(_ability.breakBladeDamageEffect, context, target);
                GameLog.Info($"[BreakBlade] {_owner} 受到击破伤害，来源技能ID: {e.skillDbId}");
            }
        }
    }
}
