using MemoryPack;
using Meow.Runtime.AOT;
using System;
using System.Collections.Generic;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 命座6
    /// 增加魔法值上限
    /// </summary>
    /// 
    [Serializable]
    [MemoryPackable]
    public partial class JuStar6 : GameAbility
    {
        public GameEffectObjectField effect;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new JuStar6Spec(this, owner);
        }

        public override bool CanAdd(GameAbilitySystem owner)
        {
            return owner.GameTagComponent.HasTag(EGameTag.State_HeroStar6);
        }
    }

    public class JuStar6Spec : GameAbilitySpec
    {

        public JuStar6Spec(JuStar6 a, GameAbilitySystem o) : base(a, o)
        {

        }

        protected override void OnActive()
        {
        }

        protected override void OnDeActive()
        {

        }

        protected override void OnAdd()
        {
            if (ability is JuStar6 _ability)
            {
                owner.ApplyGameEffectTo(_ability.effect, owner);
            }
        }


    }
}