using MemoryPack;
using Meow.Runtime.AOT;
using System;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// ju进入战斗时，队伍击败怪物
    /// </summary>
    [MemoryPackable]
    [Serializable]
    public partial class JuPassive1 : GameAbility
    {
        public GameEffectObjectField buff;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new JuPassive1Spec(this, owner);
        }
    }

    public class JuPassive1Spec : GameAbilitySpec
    {
        private ulong _buffId;
        private EventGroup _eventGroup = new();
        public JuPassive1Spec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
        }

        protected override void OnAdd()
        {
            _eventGroup.AddListener<EntityDieEvent>(OnEntityDie);
            _eventGroup.AddListener<BattleStateChange>(OnLeaveBattle);
        }

        protected override void OnRemove()
        {
            _eventGroup.RemoveAllListener();
        }

        private void OnEntityDie(IEventMessage message)
        {
            if (message is EntityDieEvent e && World.Current.TryGetEntityComp<MonsterUnitComp>(e.entityId, out var monsterComp))
            {
                if (ability is not JuPassive1 cfg)
                {
                    return;
                }
                _buffId = owner.ApplyGameEffectTo(cfg.buff, owner);
            }
        }

        /// <summary>
        /// 脱战清空
        /// </summary>
        private void OnLeaveBattle(IEventMessage message)
        {
            if (message is BattleStateChange battleChange)
            {
                if (!battleChange.isInBattle)
                {
                    owner.GameEffectComponent.RemoveGameEffectSpecById(_buffId);
                }
            }
        }
    }
}
