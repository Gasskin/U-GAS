using MemoryPack;
using Meow.Runtime.AOT;
using System;
using System.Collections.Generic;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 命座4
    /// 释放奥义后全体队友获得buff
    /// </summary>
    /// 
    [Serializable]
    [MemoryPackable]
    public partial class JuStar4 : GameAbility
    {
        public GameEffectObjectField buff;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new JuStar4Spec(this, owner);
        }

        public override bool CanAdd(GameAbilitySystem owner)
        {
            return owner.GameTagComponent.HasTag(EGameTag.State_HeroStar4);
        }
    }

    public class JuStar4Spec : GameAbilitySpec
    {
        private Dictionary<uint, ulong> _buffId = new();

        private EventGroup _eventGroup = new();
        public JuStar4Spec(JuStar4 a, GameAbilitySystem o) : base(a, o)
        {

        }

        protected override void OnActive()
        {

        }

        protected override void OnDeActive()
        {

        }

        protected override void OnAdd()
        {
            _eventGroup.AddListener<SkillCastFinishEvent>(OnCastSuperSkill);
        }
        protected override void OnRemove()
        {
            _eventGroup.RemoveAllListener();
        }

        private void OnCastSuperSkill(IEventMessage message)
        {
            if (message is SkillCastFinishEvent e && e.entityId == owner.Entity && e.eSkillType == BattleConfig.skill.ESkillType.Ultimate)
            {
                _buffId.Clear();
                if (ability is not JuStar4 cfg)
                {
                    return;
                }
                foreach (var roleInfo in World.Current.GetSystem<BattleTeamSystem>().Roles)
                {
                    if (World.Current.TryGetEntityComp(roleInfo.EntityId, out GameAbilitySystem gas))
                    {
                        var id = gas.ApplyGameEffectTo(cfg.buff, gas);
                        if (id > 0)
                        {
                            _buffId[roleInfo.EntityId] = id;
                        }
                    }
                }
            }
        }


    }
}