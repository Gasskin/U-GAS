using MemoryPack;
using System;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 命座1
    /// 魔力加持的持续时间增加X秒
    /// </summary>
    /// 
    [Serializable]
    [MemoryPackable]
    public partial class JuStar1 : GameAbility
    {
        public GameEffectObjectField changeSpecialEffect;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new JuStar1Spec(this, owner);
        }

        public override bool CanAdd(GameAbilitySystem owner)
        {
            return owner.GameTagComponent.HasTag(EGameTag.State_HeroStar1);
        }
    }

    public class JuStar1Spec : GameAbilitySpec
    {
        public JuStar1Spec(JuStar1 a, GameAbilitySystem o) : base(a, o)
        {

        }

        protected override void OnActive()
        {
            GameEffectPipeline.Instance.OnPreAddGameEffect += OnPreAddGameEffect;
        }

        protected override void OnDeActive()
        {
            GameEffectPipeline.Instance.OnPreAddGameEffect -= OnPreAddGameEffect;
        }

        private bool OnPreAddGameEffect(GameEffectSpec spec)
        {

            if (spec.GameEffect.durationPolicy != EDurationPolicy.Duration)
            {
                return true;
            }
            if (spec.GameEffect.AssetTagsContainer.HasTag(EGameTag.State_HeroStar1))
            {
                return true;
            }

            if (spec.Source == owner
                && spec.GameEffect.AssetTagsContainer.HasTag(EGameTag.Effect_Buff)
                && spec.GameEffect.AssetTagsContainer.HasTag(EGameTag.State_Buff_Ju_SpecialMagicalBlessing))
            {
                if (ability is JuStar1 starCfg)
                {
                    owner.ApplyGameEffectTo(starCfg.changeSpecialEffect, spec.Target);
                }
            }
            return false;
        }
    }
}