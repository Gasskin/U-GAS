using System;
using System.Collections.Generic;
using MemoryPack;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 队伍中所有成员增加X%攻击力和X%防御力
    /// </summary>
    [MemoryPackable]
    [Serializable]
    public partial class JuPassive2 : GameAbility
    {
        public GameEffectObjectField buff;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new JuPassive2Spec(this, owner);
        }
    }

    public class JuPassive2Spec : GameAbilitySpec
    {
        private Dictionary<uint, ulong> _buffId = new();

        public JuPassive2Spec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
        }

        protected override void OnAdd()
        {
            _buffId.Clear();
            if (ability is not JuPassive2 cfg)
            {
                return;
            }
            foreach (var roleInfo in World.Current.GetSystem<BattleTeamSystem>().Roles)
            {
                if (World.Current.TryGetEntityComp(roleInfo.EntityId, out GameAbilitySystem gas))
                {
                    var id = gas.ApplyGameEffectTo(cfg.buff, gas);
                    if (id > 0)
                    {
                        _buffId[roleInfo.EntityId] = id;
                    }
                }
            }
        }

        protected override void OnRemove()

        {
            foreach (var (ent, buff) in _buffId)
            {
                if (World.Current.TryGetEntityComp(ent, out GameAbilitySystem gas))
                {
                    gas.GameEffectComponent.RemoveGameEffectSpecById(buff);
                }
            }
        }

        protected override void OnTick(float dt)
        {
        }
    }
}