using System;
using cfg.gas;
using cfg.hero;
using MemoryPack;
using Meow.Runtime.HotUpdate.BattleConfig.gameAction;
using Sirenix.OdinInspector;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 队伍中任意角色成功施加虚无系异常参与的紊乱时，获取1个[气刃槽]。
    /// 若此时格露丝处于后台，则特殊攻击的派生技直接从场上角色发起。
    /// 格露丝的派生技命中处于虚无系异常的敌人时造成的伤害增加x%。
    /// </summary>
    [MemoryPackable]
    [Serializable]
    public partial class GhrothPassive1 : GameAbility
    {
        [LabelText("格露丝特殊攻击剑气派生")]
        public GameEffectObjectField damage;

        [LabelText("伤害增加")]
        public GasParam param1;

        [LabelText("剑气追击")]
        public GameActionCfg_Atk_Remote specialEx;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new GhrothPassive1Spec(this, owner);
        }
    }

    public class GhrothPassive1Spec : GameAbilitySpec
    {
        private GhrothPassive1 _cfg;
        private SkillComp _skill;

        public GhrothPassive1Spec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
            _skill = World.Current.GetComp<SkillComp>(owner.Entity);
            _cfg = ability as GhrothPassive1;
        }

        protected override void OnAdd()
        {
            AbnormalAccruePipeline.Instance.OnTriggerChaos += OnTriggerChaos;
        }

        protected override void OnRemove()
        {
            AbnormalAccruePipeline.Instance.OnTriggerChaos -= OnTriggerChaos;
        }

        protected override void OnActive()
        {
            DamagePipeline.Instance.OnPreProcessDamage += OnPreProcessDamage;
        }

        protected override void OnDeActive()
        {
            DamagePipeline.Instance.OnPreProcessDamage -= OnPreProcessDamage;
        }

        private float OnPreProcessDamage(GameEffectSpec spec, CommonSkillDamageEvent e)
        {
            if (spec.Source == owner
                && spec.GameEffect.assetId == _cfg.damage.effect.assetId
                && spec.Target.GameTagComponent.HasTag(EGameTag.State_DeBuff_Abnormal_Void))
            {
                return e.originalDamage * (1 + _cfg.param1.LvUpValue(owner));
            }
            return e.originalDamage;
        }

        private void OnTriggerChaos(GameEffectSpec spec, Element e, EGameTag ab)
        {
            if (!IsActive)
            {
                var active = World.Current.GetSystem<BattleTeamSystem>().ActiveRoleEntity;
                if (World.Current.TryGetEntityComp<UnitGameObjectComp>(active, out var unit))
                {
                    GameActionCfg_Atk_Remote.DoAtkRemote(owner.Entity,
                        _cfg.specialEx.range, _cfg.specialEx.castPos,
                        _cfg.specialEx.offset, _cfg.specialEx.skillId,
                        _cfg.specialEx.skillIdNoTarget, unit.Root.transform);
                }
            }
        }
    }
}