using System;
using cfg.attribute;
using cfg.gas;
using MemoryPack;
using Meow.Runtime.AOT;
using Meow.Runtime.HotUpdate.BattleConfig;
using Sirenix.OdinInspector;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 轻攻击造成的伤害提升x%
    /// 轻攻击45段命中时，额外获得x点气刃值
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class GhrothStar3 : GameAbility
    {
        [LabelText("轻攻击造成的伤害提升x%，45段命中时额外获得气刃")]
        public GasParam param1;

        [LabelText("轻攻击4")]
        [MemoryPackIgnore]
        public SkillConfigWrap attack4;

        [LabelText("轻攻击5")]
        [MemoryPackIgnore]
        public SkillConfigWrap attack5;

        [NonSerialized]
        [MemoryPackInclude]
        public int attack4Id;

        [NonSerialized]
        [MemoryPackInclude]
        public int attack5Id;

        [MemoryPackOnSerializing]
        public void OnSerializing()
        {
            attack4Id = attack4.data.id;
            attack5Id = attack5.data.id;
        }

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new GhrothStar3Spec(this, owner);
        }

        public override bool CanAdd(GameAbilitySystem owner)
        {
            return owner.GameTagComponent.HasTag(EGameTag.State_HeroStar3);
        }
    }

    public class GhrothStar3Spec : GameAbilitySpec
    {
        private GhrothStar3 _cfg;
        private EventGroup _eventGroup = new();

        public GhrothStar3Spec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
            _cfg = ability as GhrothStar3;
        }

        protected override void OnActive()
        {
            DamagePipeline.Instance.OnPreProcessDamage += OnPreProcessDamage;
            _eventGroup.AddListener<SkillStageTrigger>(OnSkillStageTrigger);
        }


        protected override void OnDeActive()
        {
            DamagePipeline.Instance.OnPreProcessDamage -= OnPreProcessDamage;
            _eventGroup.RemoveAllListener();
        }


        private float OnPreProcessDamage(GameEffectSpec spec, CommonSkillDamageEvent e)
        {
            if (spec.Source == owner && spec.GameEffect.AssetTagsContainer.HasTag(EGameTag.Skill_Ghroth_Attack))
            {
                return e.originalDamage *= 1 + _cfg.param1.Param1;
            }
            return e.originalDamage;
        }

        private void OnSkillStageTrigger(IEventMessage ie)
        {
            if (ie is not SkillStageTrigger e)
            {
                return;
            }
            if (e.casterId != owner.Entity || e.stage != ESkillStage.PostHit)
            {
                return;
            }
            if (e.skillTid == _cfg.attack4Id || e.skillTid == _cfg.attack5Id)
            {
                var e3 = owner.GameAttributeComponent.GetAttribute(AttributeId.PersonalEnergy3);
                e3.SetBaseValue(e3.BaseValue + _cfg.param1.Param2);
            }
        }
    }
}