using System;
using cfg.attribute;
using cfg.gas;
using cfg.hero;
using MemoryPack;
using Meow.Runtime.AOT;
using Meow.Runtime.HotUpdate.BattleConfig.gameAction;
using Sirenix.OdinInspector;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    public struct GhrothOverflow : IEventMessage
    {
        public static void Send()
        {
            new GhrothOverflow().SendMessage();
        }
    }

    /// <summary>
    /// 气刃机制
    /// 技能命中获取气刃，100点气刃值转化为 1气刃槽
    /// 格露斯收到伤害时，扣除x点气刃值
    /// 格露斯脱离战斗后，每秒扣除x点气刃值
    /// 当气刃值不够扣除时，1气刃槽转化为100点气刃值
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class GhrothEnergyControl : GameAbility
    {
        [LabelText("X点气刃值=1气刃槽")]
        public GasParam param1;

        [LabelText("受伤时气刃值扣除")]
        public GasParam param2;

        [LabelText("非战斗中气刃值每秒扣除")]
        public GasParam param3;

        [LabelText("气刃槽溢出时产生的剑气数量")]
        public GasParam param4;

        [LabelText("气刃槽溢出时的剑气追击")]
        public GameActionCfg_Atk_Remote specialEx;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new GhrothEnergyControlSpec(this, owner);
        }
    }


    public class GhrothEnergyControlSpec : GameAbilitySpec
    {
        private GhrothEnergyControl _cfg;

        // 气刃值
        private Attribute _energy1;
        private int _maxEnergy1;

        // 虚拟气刃值
        private Attribute _energy3;

        private int _maxEnergy3;

        // 气刃槽
        private Attribute _energy2;

        // 血量
        private Attribute _nowHp;

        // 每秒检查
        private SecondsCheck _check = new(1f);

        // 溢出
        private int _overNum;
        private SecondsCheck _overCheck = new(0.2f);

        private GhrothEnergyVfxController _vfx;

        public GhrothEnergyControlSpec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
            _cfg = (GhrothEnergyControl)ability;
            _energy1 = owner.GameAttributeComponent.GetAttribute(AttributeId.PersonalEnergy);
            _energy2 = owner.GameAttributeComponent.GetAttribute(AttributeId.PersonalEnergy2);
            var maxEnergy2 = (int)owner.GameAttributeComponent.GetAttribute(AttributeId.MaxPersonalEnergy2).CurrentValue;
            _energy3 = owner.GameAttributeComponent.GetAttribute(AttributeId.PersonalEnergy3);
            _maxEnergy1 = (int)owner.GameAttributeComponent.GetAttribute(AttributeId.MaxPersonalEnergy).CurrentValue;
            _maxEnergy3 = _maxEnergy1 + _maxEnergy1 * maxEnergy2;
            _nowHp = owner.GameAttributeComponent.GetAttribute(AttributeId.NowHp);
        }
        
        protected override void OnAdd()
        {
            AbnormalAccruePipeline.Instance.OnTriggerChaos += OnTriggerChaos;
        }



        protected override void OnRemove()
        {
            AbnormalAccruePipeline.Instance.OnTriggerChaos -= OnTriggerChaos;
        }


        protected override void OnActive()
        {
            _energy2.OnPostCurrentValueChange += Energy2_OnPostCurrentValueChange;
            _energy3.OnPreBaseValueChange += Energy3_OnPreBaseValueChange;
            _nowHp.OnPostBaseValueChange += NowHp_OnPostBaseValueChange;
        }


        protected override void OnDeActive()
        {
            _energy2.OnPostCurrentValueChange -= Energy2_OnPostCurrentValueChange;
            _energy3.OnPreBaseValueChange -= Energy3_OnPreBaseValueChange;
            _nowHp.OnPostBaseValueChange -= NowHp_OnPostBaseValueChange;
        }

        protected override void OnTick(float dt)
        {
            // 初始化顺序不好固定，在这里做一次能量初始化
            if (IsActive && _vfx == null)
            {
                if (GhrothEnergyVfxController.Instance != null)
                {
                    _vfx = GhrothEnergyVfxController.Instance;
                    Energy2_OnPostCurrentValueChange(_energy2.CurrentValue, _energy2.CurrentValue);
                }
            }

            // 非战斗中
            if (!World.Current.GetSystem<BattleTeamSystem>().IsInBattle)
            {
                if (_check.Tick(dt))
                {
                    _energy3.SetBaseValue(_energy3.BaseValue - _cfg.param3.Param1);
                }
            }
            else
            {
                _check.Reset();
            }

            if (_overNum > 0)
            {
                if (_overCheck.Tick(dt))
                {
                    // 前台
                    if (IsActive)
                    {
                        GameActionCfg_Atk_Remote.DoAtkRemote(owner.Entity, _cfg.specialEx.range, _cfg.specialEx.castPos, _cfg.specialEx.offset, _cfg.specialEx.skillId, _cfg.specialEx.skillIdNoTarget);
                        GhrothOverflow.Send();
                    }
                    // 后台，被动触发
                    else
                    {
                        var active = World.Current.GetSystem<BattleTeamSystem>().ActiveRoleEntity;
                        if (active != owner.Entity && World.Current.TryGetEntityComp<UnitGameObjectComp>(active, out var unit))
                        {
                            GameActionCfg_Atk_Remote.DoAtkRemote(owner.Entity,
                                _cfg.specialEx.range, _cfg.specialEx.castPos,
                                _cfg.specialEx.offset, _cfg.specialEx.skillId,
                                _cfg.specialEx.skillIdNoTarget, unit.Root.transform);
                        }
                    }

                    _overNum--;
                    if (_overNum <= 0)
                    {
                        _overCheck.Reset();
                    }
                }
            }
        }
        
        
        private void OnTriggerChaos(GameEffectSpec arg1, Element arg2, EGameTag arg3)
        {
            _overNum++;
        }


        private void Energy2_OnPostCurrentValueChange(float arg1, float arg2)
        {
            var inst = GhrothEnergyVfxController.Instance;
            if (inst == null)
            {
                return;
            }
            var num = (int)arg2;
            inst.energy1.SetActive(num >= 1);
            inst.energy2.SetActive(num >= 2);
            inst.energy3.SetActive(num >= 3);
        }

        /// <summary>
        /// 气刃槽与气刃值的转换
        /// </summary>
        /// <param name="inValue"></param>
        /// <returns></returns>
        private float Energy3_OnPreBaseValueChange(float inValue)
        {
            // 先处理溢出
            if (inValue >= _maxEnergy3)
            {
                var newOverNum = (int)((inValue - _maxEnergy3) / _cfg.param1.Param1) + 1;
                _overNum += newOverNum * (int)_cfg.param4.Param1;
                inValue -= newOverNum * _cfg.param1.Param1;
            }

            // 气刃槽
            var num = (int)(inValue / _cfg.param1.Param1);
            if (num != (int)_energy2.BaseValue)
            {
                _energy2.SetBaseValue(num);
            }
            // 气刃值
            var value = (int)(inValue - num * _cfg.param1.Param1);
            value = Math.Min(value, _maxEnergy1);
            if (value != (int)_energy1.BaseValue)
            {
                _energy1.SetBaseValue(value);
            }
            inValue = Math.Min(inValue, _maxEnergy3);
            return inValue;
        }

        /// <summary>
        /// 受伤时扣除气刃值
        /// </summary>
        /// <param name="oldV"></param>
        /// <param name="newV"></param>
        private void NowHp_OnPostBaseValueChange(float oldV, float newV)
        {
            if (newV < oldV)
            {
                _energy1.SetBaseValue(_energy1.BaseValue - _cfg.param2.Param1);
            }
        }
    }
}