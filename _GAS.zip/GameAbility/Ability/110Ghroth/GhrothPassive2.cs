using System;
using cfg.attribute;
using cfg.gas;
using MemoryPack;
using Sirenix.OdinInspector;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 每个[气刃槽]为格露丝提供x%异常积蓄效率
    /// </summary>
    [MemoryPackable]
    [Serializable]
    public partial class GhrothPassive2 : GameAbility
    {
        [LabelText("每个气刃槽提供x%的异常积蓄")]
        public GasParam param1;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new GhrothPassive2Spec(this, owner);
        }
    }

    public class GhrothPassive2Spec : GameAbilitySpec
    {
        private GhrothPassive2 _cfg;
        private Attribute _energy2;
        private int _num;
        private float _added;
        private SkillComp _skill;

        public GhrothPassive2Spec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
            _cfg = ability as GhrothPassive2;
            _skill = World.Current.GetComp<SkillComp>(owner.Entity);
            _energy2 = owner.GameAttributeComponent.GetAttribute(AttributeId.PersonalEnergy2);
            _num = 0;
        }

        protected override void OnActive()
        {
            _energy2.OnPostCurrentValueChange += Energy2_OnPostCurrentValueChange;
            // 注意初始化顺序
            Energy2_OnPostCurrentValueChange(_energy2.CurrentValue, _energy2.CurrentValue);
        }

        protected override void OnDeActive()
        {
            _energy2.OnPostCurrentValueChange -= Energy2_OnPostCurrentValueChange;
            if (_added > 0) 
            {
                AddValue(-_added);
            }
            _added = 0;
            _num = 0;
        }

        private void Energy2_OnPostCurrentValueChange(float arg1, float arg2)
        {
            var newNum = (int)arg2;
            if (_num != newNum)
            {
                if (_added > 0) 
                {
                    AddValue(-_added);
                }
                _added = _num * _cfg.param1.LvUpValue(owner);
                AddValue(_added);
                _num = newNum;
            }
        }

        private void AddValue(float add)
        {
            var attr = owner.GameAttributeComponent.GetAttribute(AttributeId.AbnormalAccrueMult);
            attr.SetBaseValue(attr.BaseValue + add);
        }
    }
}