using System;
using cfg.attribute;
using cfg.gas;
using MemoryPack;
using Meow.Runtime.AOT;
using Meow.Runtime.HotUpdate.BattleConfig;
using Sirenix.OdinInspector;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 每拥有1个[气刃槽]，造成的追击伤害将无视目标x%的防御力；
    /// 派生技命中异常状态下敌人时，使得全队异常积蓄效率提升x%，效果持续x秒，不可叠加，重复获得时持续时间刷新
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class GhrothStar1 : GameAbility
    {
        [LabelText("每拥有1个[气刃槽]造成的追击伤害将无视目标x%的防御力")]
        public GasParam param1;

        [LabelText("派生技命中异常状态下敌人时使得全队异常积蓄效率提升")]
        public GameEffectObjectField buff;

        [LabelText("派生攻击")]
        [MemoryPackIgnore]
        public SkillConfigWrap skill;

        [NonSerialized]
        [MemoryPackInclude]
        public int skillId;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new GhrothStar1Spec(this, owner);
        }

        public override bool CanAdd(GameAbilitySystem owner)
        {
            return owner.GameTagComponent.HasTag(EGameTag.State_HeroStar1);
        }

        [MemoryPackOnSerializing]
        public void OnSerializing()
        {
            skillId = skill.data.id;
        }
    }

    public class GhrothStar1Spec : GameAbilitySpec
    {
        private GhrothStar1 _cfg;

        private Attribute _energy2;

        private EventGroup _eventGroup = new();

        public GhrothStar1Spec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
            _cfg = ability as GhrothStar1;
            _energy2 = owner.GameAttributeComponent.GetAttribute(AttributeId.PersonalEnergy2);
        }



        protected override void OnActive()
        {
            GameEffectPipeline.Instance.OnPreAddGameEffect += OnPreAddGameEffect;
            _eventGroup.AddListener<SkillStageTrigger>(OnSkillStageTrigger);
        }

        protected override void OnDeActive()
        {
            GameEffectPipeline.Instance.OnPreAddGameEffect -= OnPreAddGameEffect;
            _eventGroup.RemoveAllListener();
        }

        private bool OnPreAddGameEffect(GameEffectSpec spec)
        {
            if (_energy2.CurrentValue <= 0)
            {
                return true;
            }
            if (spec.Source == owner
                && spec.GameEffect.AssetTagsContainer.HasTag(EGameTag.Effect_Damage_Extend))
            {
                var c = spec.Context;
                c.defIgnoreRate += _cfg.param1.Param1 * _energy2.CurrentValue;
                spec.SetContext(c);
            }
            return true;
        }

        private void OnSkillStageTrigger(IEventMessage ie)
        {
            if (ie is not SkillStageTrigger e)
            {
                return;
            }
            if (e.casterId != owner.Entity || e.stage != ESkillStage.Hit || e.skillTid != _cfg.skillId)
            {
                return;
            }
            var team = World.Current.GetSystem<BattleTeamSystem>();
            foreach (var role in team.Roles)
            {
                var t = World.Current.GetComp<GameAbilitySystem>(role.EntityId);
                owner.ApplyGameEffectTo(_cfg.buff, t);
            }
        }
    }
}