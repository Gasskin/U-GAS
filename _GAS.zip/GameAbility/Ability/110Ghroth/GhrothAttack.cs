using System;
using cfg.attribute;
using MemoryPack;
using Meow.Runtime.AOT;
using Meow.Runtime.HotUpdate.BattleConfig;
using Sirenix.OdinInspector;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 释放普通攻击时，如果气刃槽数量＞0，对最近的一个敌人造成伤害
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class GhrothAttack : GameAbility
    {
        [LabelText("普通攻击-追击")]
        public GameEffectObjectField attackEx;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new GhrothAttackSpec(this, owner);
        }
    }

    public class GhrothAttackSpec : GameAbilitySpec
    {
        private EventGroup _eventGroup = new();

        public GhrothAttackSpec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
        }

        protected override void OnActive()
        {
            _eventGroup.AddListener<SkillStageTrigger>(OnSkillStageTrigger);
        }

        protected override void OnDeActive()
        {
            _eventGroup.RemoveAllListener();
        }

        private void OnSkillStageTrigger(IEventMessage ie)
        {
            if (ie is not SkillStageTrigger e || e.stage != ESkillStage.Hit)
            {
                return;
            }
            if (e.casterId != owner.Entity)
            {
                return;
            }
            if (ability is not GhrothAttack cfg)
            {
                return;
            }
            var skillConfig = TbSkillConfig.Instance.GetOrDefault(e.skillTid);
            if (skillConfig.tagsContainer.HasTag(EGameTag.Skill_Ghroth_Attack))
            {
                var num = (int)owner.GameAttributeComponent.GetAttribute(AttributeId.PersonalEnergy2).CurrentValue;
                if (num <= 0) 
                {
                    return;
                }
                for (int i = 0; i < e.targets.Count; i++)
                {
                    var enemy = e.targets[i].target;
                    World.Current.TryGetEntityComp(enemy, out GameAbilitySystem target);
                    World.Current.TryGetEntityComp(enemy, out UnitGameObjectComp unit);
                    while (num-- > 0)
                    {
                        owner.ApplyGameEffectTo(cfg.attackEx, new GameEffectContext()
                        {
                            hitPoint = unit.Root.transform.position
                        }, target);
                    }
                }
            }
        }
    }
}