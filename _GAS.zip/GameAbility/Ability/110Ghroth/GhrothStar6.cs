using System;
using cfg.attribute;
using cfg.gas;
using MemoryPack;
using Meow.Runtime.AOT;
using Sirenix.OdinInspector;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// [气刃槽]满时，派生技能获得x%伤害加成
    /// 在战斗开始时就获取x个[气刃槽]
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class GhrothStar6 : GameAbility
    {
        [LabelText("气刃槽满时派生技能获得x%伤害提升，战斗开始时获取X个气刃槽")]
        public GasParam param1;

        [LabelText("X点气刃值=1气刃槽")]
        public GasParam param3;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new GhrothStar6Spec(this, owner);
        }

        public override bool CanAdd(GameAbilitySystem owner)
        {
            return owner.GameTagComponent.HasTag(EGameTag.State_HeroStar6);
        }
    }

    public class GhrothStar6Spec : GameAbilitySpec
    {
        private GhrothStar6 _cfg;
        private EventGroup _eventGroup = new();
        private Attribute _energy2;
        private Attribute _maxEnergy2;
        
        public GhrothStar6Spec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
            _cfg = ability as GhrothStar6;
            _energy2 = owner.GameAttributeComponent.GetAttribute(AttributeId.PersonalEnergy2);
            _maxEnergy2 = owner.GameAttributeComponent.GetAttribute(AttributeId.MaxPersonalEnergy2);
        }

        protected override void OnActive()
        {
            DamagePipeline.Instance.OnPreProcessDamage += OnPreProcessDamage;
            _eventGroup.AddListener<BattleStateChange>(OnBattleStateChange);
        }


        protected override void OnDeActive()
        {
            DamagePipeline.Instance.OnPreProcessDamage -= OnPreProcessDamage;
            _eventGroup.RemoveAllListener();
        }

        private float OnPreProcessDamage(GameEffectSpec spec, CommonSkillDamageEvent e)
        {
            if (_energy2.CurrentValue >= _maxEnergy2.CurrentValue
                && spec.Source == owner
                && spec.GameEffect.AssetTagsContainer.HasTag(EGameTag.Effect_Damage_Extend))
            {
                return e.originalDamage *= 1f + _cfg.param1.Param1;
            }
            return e.originalDamage;
        }


        private void OnBattleStateChange(IEventMessage ie)
        {
            if (ie is BattleStateChange { isInBattle: true })
            {
                var add = _cfg.param1.Param2 * _cfg.param3.Param1;
                var e3 = owner.GameAttributeComponent.GetAttribute(AttributeId.PersonalEnergy3);
                e3.SetBaseValue(e3.BaseValue + add);
            }
        }
    }
}