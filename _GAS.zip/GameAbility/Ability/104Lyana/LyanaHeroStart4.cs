using System;
using cfg.attribute;
using cfg.gas;
using MemoryPack;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 莉亚娜释放奥义时，回满自身怒气值
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class LyanaHeroStart4 : GameAbility
    {
        public GameEffectObjectField recoveryEnergy;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new LyanaHeroStart4Spec(this, owner);
        }
    }

    public class LyanaHeroStart4Spec : GameAbilitySpec
    {
        public LyanaHeroStart4Spec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
        }

        protected override void OnActive()
        {
            DamagePipeline.Instance.OnPostProcessDamage += OnPostProcessDamage;
        }

        protected override void OnDeActive()
        {
            DamagePipeline.Instance.OnPostProcessDamage -= OnPostProcessDamage;
        }

        protected override void OnTick(float dt)
        {
        }

        private void OnPostProcessDamage(GameEffectSpec spec, CommonSkillDamageEvent e)
        {
            if (spec.Source == owner && spec.GameEffect.AssetTagsContainer.HasTag(EGameTag.Skill_Lyana_Special))
            {
                if (ability is LyanaHeroStart4 a)
                {
                    owner.ApplyGameEffectTo(a.recoveryEnergy, owner);
                }
            }
        }
    }
}