using System;
using cfg.attribute;
using MemoryPack;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 莉亚娜击杀带有死亡印记的目标时增加20%黑暗加成，持续15秒，最多叠加3次
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class LyanaHeroStart6 : GameAbility
    {
        public GameEffectObjectField addDark;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new LyanaHeroStart6Spec(this, owner);
        }
    }

    public class LyanaHeroStart6Spec : GameAbilitySpec
    {
        public LyanaHeroStart6Spec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
        }

        protected override void OnActive()
        {
            DamagePipeline.Instance.OnPostProcessDie += OnPostProcessDie;
        }

        protected override void OnDeActive()
        {
            DamagePipeline.Instance.OnPostProcessDie -= OnPostProcessDie;
        }

        protected override void OnTick(float dt)
        {
        }

        private void OnPostProcessDie(GameEffectSpec spec, CommonSkillDamageEvent e)
        {
            if (ability is not LyanaHeroStart6 cfg)
            {
                return;
            }
            if (spec.Source == owner && spec.Target.GameTagComponent.HasTag(EGameTag.State_DeBuff_Lyana_DeathMark))
            {
                owner.ApplyGameEffectTo(cfg.addDark, owner);
            }
        }
    }
}