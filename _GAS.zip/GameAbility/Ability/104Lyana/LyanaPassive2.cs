﻿using System;
using cfg.attribute;
using cfg.gas;
using MemoryPack;
using Sirenix.OdinInspector;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 绝死印记 引爆时。暴击率额外增加 x%
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial  class LyanaPassive2 : GameAbility
    {
        [LabelText("绝死印记引爆时，暴击率外增加 x%")]
        public GasParam param1;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new LyanaPassive2Spec(this, owner);
        }
    }
    
    public class  LyanaPassive2Spec : GameAbilitySpec
    {
        private LyanaPassive2 _ability;
        private SkillComp _skill;
        
        public LyanaPassive2Spec(LyanaPassive2 ability, GameAbilitySystem o) : base(ability, o)
        {
            _ability = ability;
            _skill = World.Current.GetComp<SkillComp>(owner.Entity);
        }

        protected override void OnActive()
        {
            GameEffectPipeline.Instance.OnPreAddGameEffect += OnPreAddGameEffect;
        }
        
        protected override void OnDeActive()
        {
            GameEffectPipeline.Instance.OnPreAddGameEffect -= OnPreAddGameEffect;
        }
        
        private bool OnPreAddGameEffect(GameEffectSpec spec)
        {
            if (spec.GameEffect.durationPolicy != EDurationPolicy.Instant)
            {
                return true;
            }
            if (spec.Source == owner
                && spec.GameEffect.AssetTagsContainer.HasTag(EGameTag.Effect_Damage)
                && spec.GameEffect.AssetTagsContainer.HasTag(EGameTag.Skill_Lyana_Special)
                && spec.Target.GameTagComponent.HasTag(EGameTag.State_DeBuff_Lyana_DeathMark))
            {
                if (ability is LyanaPassive2 a)
                {
                    // 被动 绝死印记引爆时，暴击率外增加 x%
                    var ctx = spec.Context;
                    ctx.crit +=  a.param1.LvUpValue(owner);
                    spec.SetContext(ctx);
                }
            }
            return true;
        }
    }
    
}