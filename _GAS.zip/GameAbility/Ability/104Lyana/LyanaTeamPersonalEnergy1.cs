using System;
using cfg.attribute;
using cfg.gas;
using MemoryPack;
using Meow.Runtime.AOT;
using Sirenix.OdinInspector;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 队友受到伤害时，莉亚娜增加能量
    /// 除自身以外的队友受伤时，莉亚娜恢复能量（时间窗口内有次数限制）
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class LyanaTeamPersonalEnergy1 : GameAbility
    {
        public GameEffectObjectField addEnergy;

        [LabelText("队友受伤恢复能量限制 GasValue (参数1:时间窗口秒数, 参数2:窗口内最大恢复次数)")]
        public int addEnergyTimeGasValue;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new LyanaTeamPersonalEnergy1Spec(this, owner);
        }
    }

    public class LyanaTeamPersonalEnergy1Spec : GameAbilitySpec
    {
        private readonly LyanaTeamPersonalEnergy1 _config; // 缓存配置引用，避免重复类型转换

        // 常量定义
        private const float k_DefaultParamValue = 9999f; // GasValue 默认参数值
        private const int k_MaxWindowResetIterations = 100; // 时间窗口重置最大迭代次数

        private float _addEnergyCurrentInterval;    // 队友受伤恢复能量限制的当前剩余时间窗口
        private float _addEnergyDefaultInterval;    // 队友受伤恢复能量限制的时间窗口大小（重置周期）
        private float _addEnergyMaxCount;           // 时间窗口内允许的最大队友受伤恢复能量次数
        private int _addEnergyCurrentCount;         // 当前时间窗口内已执行的队友受伤恢复能量次数

        public LyanaTeamPersonalEnergy1Spec(LyanaTeamPersonalEnergy1 ability, GameAbilitySystem o) : base(ability, o)
        {
            _config = ability;
            _addEnergyDefaultInterval = GasValue.GetParam(ability.addEnergyTimeGasValue, 1, k_DefaultParamValue);
            _addEnergyMaxCount = GasValue.GetParam(ability.addEnergyTimeGasValue, 2, k_DefaultParamValue);

            // 配置验证
            ValidateConfig();
        }

        /// <summary>
        /// 验证配置参数的合理性
        /// </summary>
        private void ValidateConfig()
        {
            if (_addEnergyDefaultInterval <= 0)
            {
                GameLog.Error($"[LyanaTeamPersonalEnergy1] 队友受伤恢复时间窗口配置错误: {_addEnergyDefaultInterval}，已重置为默认值5秒");
                _addEnergyDefaultInterval = 5f;
            }

            if (_addEnergyMaxCount <= 0)
            {
                GameLog.Error($"[LyanaTeamPersonalEnergy1] 队友受伤恢复次数配置错误: {_addEnergyMaxCount}，已重置为默认值3次");
                _addEnergyMaxCount = 3;
            }
        }

        protected override void OnActive()
        {
            // 初始化时间窗口
            _addEnergyCurrentInterval = _addEnergyDefaultInterval;
            _addEnergyCurrentCount = 0;

            // 队伍中有Lyana时才激活，这个技能才会被添加后激活，
            // 所以 OnActive激活时，Lyana一定存在
            DamagePipeline.Instance.OnPostProcessDamage += OnPostProcessDamage;
        }

        protected override void OnDeActive()
        {
            DamagePipeline.Instance.OnPostProcessDamage -= OnPostProcessDamage;
        }

        protected override void OnTick(float dt)
        {
            UpdateEnergyRestoreWindow(dt);
        }

        /// <summary>
        /// 更新队友受伤恢复能量的时间窗口
        /// </summary>
        private void UpdateEnergyRestoreWindow(float dt)
        {
            _addEnergyCurrentInterval -= dt;

            // 添加边界保护：防止异常大的 dt 导致死循环
            int iterations = 0;
            while (_addEnergyCurrentInterval <= 0 && iterations < k_MaxWindowResetIterations)
            {
                _addEnergyCurrentInterval += _addEnergyDefaultInterval;
                _addEnergyCurrentCount = 0;
                iterations++;
            }

            if (iterations >= k_MaxWindowResetIterations)
            {
                GameLog.Warning($"[LyanaTeamPersonalEnergy1] 时间窗口重置循环超过最大次数 {k_MaxWindowResetIterations}，可能存在异常大的dt: {dt}");
                _addEnergyCurrentInterval = _addEnergyDefaultInterval;
            }
        }

        private bool CanAddEnergy()
        {
            return _addEnergyCurrentCount < _addEnergyMaxCount;
        }
        
        /// <summary>
        /// 处理伤害事件，当队友受伤时为莉亚娜恢复能量
        /// </summary>
        private void OnPostProcessDamage(GameEffectSpec spec, CommonSkillDamageEvent e)
        {
            // 未造成伤害
            if (e.trueDamage <= 0)
            {
                return;
            }

            // 受伤的是莉亚娜自己
            if (e.target == owner.Entity)
            {
                return;
            }

            // 判断受伤者是否是队友
            if (!IsTeammate(e.target))
            {
                return;
            }

            // 当前时间窗口内已达到队友受伤恢复能量次数上限
            if (!CanAddEnergy())
            {
                return;
            }

            // 为莉亚娜恢复能量
            owner?.ApplyGameEffectTo(_config.addEnergy, owner);
            _addEnergyCurrentCount++;

            GameLog.Warning(
                $"  队友受伤 Lyana 获得能量值 {owner.GameAttributeComponent.GetAttribute(AttributeId.PersonalEnergy).CurrentValue} ");
        }

        /// <summary>
        /// 判断指定实体是否是队友(包含召唤物)
        /// </summary>
        private bool IsTeammate(uint targetEntityId)
        {
            if (World.Current.TryGetEntityComp(owner.Entity, out FeatureComp featureComp))
            {
                return featureComp.IsMate(targetEntityId);
            }
            return false;
        }
    }
}