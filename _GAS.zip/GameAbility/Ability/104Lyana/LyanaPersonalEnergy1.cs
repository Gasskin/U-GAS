using System;
using cfg.attribute;
using cfg.gas;
using MemoryPack;
using Meow.Runtime.AOT;
using Sirenix.OdinInspector;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 莉亚娜能量机制：攻击或受击恢复能量，长时间不战斗则衰减
    /// 自身造成伤害时恢复能量（无次数限制）
    /// 自身受到伤害时恢复能量（时间窗口内有次数限制）
    /// 超过阈值时间未造成伤害或受到伤害时，每秒衰减能量
    /// 角色切换到后台时不会衰减能量
    /// </summary>
    [MemoryPackable]
    [Serializable]
    public partial class LyanaPersonalEnergy1 : GameAbility
    {
        [LabelText("能量衰减配置 GasValue (参数1:超时秒数, 参数2:每秒减少值)")]
        public int reduceEnergyGasValue;

        [LabelText("受伤恢复能量限制 GasValue (参数1:时间窗口秒数, 参数2:窗口内最大恢复次数)")]
        public int addEnergyTimeGasValue;

        public GameEffectObjectField addEnergy;
        public GameEffectObjectField reduceEnergy;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new LyanaPersonalEnergy1Spec(this, owner);
        }
    }

    public class LyanaPersonalEnergy1Spec : GameAbilitySpec
    {
        private readonly LyanaPersonalEnergy1 _config; // 缓存配置引用，避免重复类型转换

        // 常量定义
        private const float k_ReduceInterval = 1f; // 能量衰减触发间隔（每秒触发一次）
        private const float k_DefaultParamValue = 9999f; // GasValue 默认参数值
        private const int k_MaxReduceIterations = 100; // 防止异常大的dt导致死循环

        private float _reduceEnergyDefaultInterval; // 不造成/受到伤害后多久开始衰减能量的时间阈值
        private float _reduceInterval; // 能量衰减计时器（0表示未开始计时，用于累加衰减间隔）

        private float _lastDamageTime; // 最后一次受伤或造成伤害的时间戳
        private bool _hasFirstDamage; // 是否已发生过第一次伤害事件（用于首次进入场景时不立即衰减）

        private float _addEnergyCurrentInterval; // 受伤恢复能量限制的当前剩余时间窗口
        private float _addEnergyDefaultInterval; // 受伤恢复能量限制的时间窗口大小（重置周期）
        private float _addEnergyMaxCount; // 时间窗口内允许的最大受伤恢复能量次数
        private int _addEnergyCurrentCount; // 当前时间窗口内已执行的受伤恢复能量次数



        public LyanaPersonalEnergy1Spec(LyanaPersonalEnergy1 ability, GameAbilitySystem o) : base(ability, o)
        {
            _config = ability;
            _reduceEnergyDefaultInterval = GasValue.GetParam(ability.reduceEnergyGasValue, 1, k_DefaultParamValue);
            _addEnergyDefaultInterval = GasValue.GetParam(ability.addEnergyTimeGasValue, 1, k_DefaultParamValue);
            _addEnergyMaxCount = GasValue.GetParam(ability.addEnergyTimeGasValue, 2, k_DefaultParamValue);

            // 配置验证
            ValidateConfig();
        }

        /// <summary>
        /// 验证配置参数的合理性
        /// </summary>
        private void ValidateConfig()
        {
            if (_reduceEnergyDefaultInterval <= 0)
            {
                GameLog.Error($"[LyanaPersonalEnergy1] 能量衰减超时配置错误: {_reduceEnergyDefaultInterval}，已重置为默认值5秒");
                _reduceEnergyDefaultInterval = 5f;
            }

            if (_addEnergyDefaultInterval <= 0)
            {
                GameLog.Error($"[LyanaPersonalEnergy1] 受伤恢复时间窗口配置错误: {_addEnergyDefaultInterval}，已重置为默认值5秒");
                _addEnergyDefaultInterval = 5f;
            }

            if (_addEnergyMaxCount <= 0)
            {
                GameLog.Error($"[LyanaPersonalEnergy1] 受伤恢复次数配置错误: {_addEnergyMaxCount}，已重置为默认值3次");
                _addEnergyMaxCount = 3;
            }
        }

        protected override void OnActive()
        {
            _lastDamageTime = 0f;
            _reduceInterval = 0f;
            _hasFirstDamage = false;

            _addEnergyCurrentInterval = _addEnergyDefaultInterval;
            _addEnergyCurrentCount = 0;

            DamagePipeline.Instance.OnPostProcessDamage += OnPostProcessDamage;
        }

        protected override void OnDeActive()
        {
            DamagePipeline.Instance.OnPostProcessDamage -= OnPostProcessDamage;
        }

        protected override void OnTick(float dt)
        {
            CheckReduceEnergy(dt);
            UpdateEnergyRestoreWindow(dt);
        }


        private void CheckReduceEnergy(float dt)
        {
            if (!CanReduceEnergy())
            {
                return;
            }

            if (_reduceInterval == 0)
            {
                // 首次进入衰减状态，计算已经超时的时间作为初始值
                _reduceInterval = Time.time - _lastDamageTime;
            }
            else
            {
                _reduceInterval += dt;
            }

            // 添加边界保护：防止异常大的 dt 导致死循环
            int iterations = 0;
            while (_reduceInterval > k_ReduceInterval && iterations < k_MaxReduceIterations)
            {
                TimeoutReduceEnergy();
                _reduceInterval -= k_ReduceInterval;
                iterations++;
            }

            if (iterations >= k_MaxReduceIterations)
            {
                GameLog.Warning($"[LyanaPersonalEnergy1] 能量衰减循环超过最大次数 {k_MaxReduceIterations}，可能存在异常大的dt: {dt}");
                _reduceInterval = 0;
            }
        }


        /// <summary>
        /// 更新受伤恢复能量的时间窗口
        /// </summary>
        private void UpdateEnergyRestoreWindow(float dt)
        {
            _addEnergyCurrentInterval -= dt;

            // 使用 while 处理可能的多次超时，保证时间窗口精度
            while (_addEnergyCurrentInterval <= 0)
            {
                _addEnergyCurrentInterval += _addEnergyDefaultInterval;
                _addEnergyCurrentCount = 0;
            }
        }

        private void OnPostProcessDamage(GameEffectSpec spec, CommonSkillDamageEvent e)
        {
            // 提前过滤无关事件，避免不必要的方法调用
            if (e.trueDamage <= 0)
            {
                return;
            }

            if (spec.Source != owner && spec.Target != owner)
            {
                return;
            }

            TakeDamageAddEnergy(spec, e);
            DealDamageAddEnergy(spec, e);
        }


        private void TakeDamageAddEnergy(GameEffectSpec spec, CommonSkillDamageEvent e)
        {
            if (spec.Target != owner)
            {
                return;
            }

            if (spec.Source == owner)
            {
                return;
            }

            // 当前时间窗口内已达到受伤恢复能量次数上限
            if (!CanAddEnergy())
            {
                return;
            }

            _addEnergyCurrentCount++;
            ApplyEnergyRestore("受伤+");
        }


        private void DealDamageAddEnergy(GameEffectSpec spec, CommonSkillDamageEvent e)
        {
            if (spec.Source != owner)
            {
                return;
            }

            if (spec.Target == owner)
            {
                return;
            }

            ApplyEnergyRestore("造伤+");
        }

        /// <summary>
        /// 应用能量恢复效果（消除重复代码）
        /// </summary>
        private void ApplyEnergyRestore(string logSource)
        {
            owner.ApplyGameEffectTo(_config.addEnergy, owner);
            GameLog.Warning(
                $"  当前角色能量值 ({logSource}) {owner.GameAttributeComponent.GetAttribute(AttributeId.PersonalEnergy).CurrentValue} ");

            ResetReduceTimer();
        }

        /// <summary>
        /// 重置衰减计时器（消除重复代码）
        /// </summary>
        private void ResetReduceTimer()
        {
            _hasFirstDamage = true;
            _lastDamageTime = Time.time;
            _reduceInterval = 0;
        }


        private void TimeoutReduceEnergy()
        {
            owner.ApplyGameEffectTo(_config.reduceEnergy, owner);
            GameLog.Warning(
                $"  当前角色能量值 (衰减-) {owner.GameAttributeComponent.GetAttribute(AttributeId.PersonalEnergy).CurrentValue} ");
        }

        private bool CanReduceEnergy()
        {
            // 首次进入场景，尚未发生任何伤害事件时，不衰减能量
            if (!_hasFirstDamage)
            {
                return false;
            }

            var playerId = World.Current.GetSystem<BattleTeamSystem>().ActiveRoleEntity;
            // 角色在后台时，不会衰减能量
            if (playerId != owner.Entity)
            {
                return false;
            }

            // 距离上次造成伤害或受到伤害未超过阈值时间，不衰减
            if (Time.time - _lastDamageTime < _reduceEnergyDefaultInterval)
            {
                return false;
            }

            return true;
        }

        private bool CanAddEnergy()
        {
            return _addEnergyCurrentCount < _addEnergyMaxCount;
        }

    }
}