﻿using System;
using MemoryPack;
using Meow.Runtime.AOT;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    public struct LyanaTargetChangeEvent : IEventMessage
    {
        public Transform Target;
        public uint EntityId;

        public static void SendMsg(Transform target, uint entityId)
        {
            new LyanaTargetChangeEvent
            {
                Target = target,
                EntityId = entityId,
            }.SendMessage();
        }
    }
    
    public struct LyanaTargetHitEvent : IEventMessage
    {
        public uint EntityId;

        public static void SendMsg(uint entityId)
        {
            new LyanaTargetHitEvent
            {
                EntityId = entityId,
            }.SendMessage();
        }
    }
    
    /// <summary>
    /// 莉亚娜攻击命中敌人时，会对目标施加死亡标记
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial  class LyanaPassive1 : GameAbility
    {
        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new LyanaPassive1Spec(this, owner);
        }
    }
    
    public class  LyanaPassive1Spec : GameAbilitySpec
    {
        private LyanaPassive1 _ability;
        public LyanaPassive1Spec(LyanaPassive1 ability, GameAbilitySystem o) : base(ability, o)
        {
            _ability = ability;
        }

        protected override void OnActive()
        {
            DamagePipeline.Instance.OnPostProcessDamage += OnPostProcessDamage;
        }
        
        protected override void OnDeActive()
        {
            DamagePipeline.Instance.OnPostProcessDamage -= OnPostProcessDamage;
        }

        private void OnPostProcessDamage(GameEffectSpec spec, CommonSkillDamageEvent e)
        {
            if (e.trueDamage <= 0)
            {
                return;
            }
            
            if (spec.Source == owner)
            {
                // 对目标施加死亡标记
                if (!spec.Target.GameTagComponent.HasTag(EGameTag.State_DeBuff_Lyana_DeathMark))
                {
                    spec.Target.GameTagComponent.AddTag(EGameTag.State_DeBuff_Lyana_DeathMark);
                    
                    LockToCharacter( spec.Target.Entity);
                }
                else
                {
                    LyanaTargetHitEvent.SendMsg(spec.Target.Entity);
                }
            }
        }
        
        private void LockToCharacter(uint entityId)
        {
            if (!World.Current.TryGetEntityComp<UnitBoneComp>(entityId, out var unitBoneComp))
            {
                return;
            }

            if (unitBoneComp.boneBehaviour == null || unitBoneComp.boneBehaviour.spine2M == null)
            {
                GameLog.Error($" entityId : {entityId} 未配置骨骼 Spine2M ");
                return;
            }
            
            //追踪点 是角色上的Spine2M 骨骼
            LyanaTargetChangeEvent.SendMsg(unitBoneComp.boneBehaviour.spine2M , entityId);
        
        }
    }
}