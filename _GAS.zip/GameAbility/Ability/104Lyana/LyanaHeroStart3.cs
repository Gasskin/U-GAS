using System;
using MemoryPack;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 莉亚娜增加15%暴击率，引爆死亡印记后，增加15%的暴击率，持续10秒
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class LyanaHeroStart3 : GameAbility
    {
        // public GameEffectObjectField deathMark;
        // public GameEffectObjectField fixedCrit;
        public GameEffectObjectField addCrit;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new LyanaHeroStart3Spec(this, owner);
        }
    }

    public class LyanaHeroStart3Spec : GameAbilitySpec
    {
        private ulong _buffId;

        public LyanaHeroStart3Spec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
        }

        protected override void OnActive()
        {
            // _buffId = 0;
            // if (ability is LyanaHeroStart3 a)
            // {
            //     _buffId = owner.ApplyGameEffectTo(a.fixedCrit, owner);
            // }
            DamagePipeline.Instance.OnPostProcessDamage += OnPostProcessDamage;
        }


        protected override void OnDeActive()
        {
            if (_buffId > 0)
            {
                owner.GameEffectComponent.RemoveGameEffectSpecById(_buffId);
            }
            DamagePipeline.Instance.OnPostProcessDamage -= OnPostProcessDamage;
        }

        protected override void OnTick(float dt)
        {
        }

        private void OnPostProcessDamage(GameEffectSpec spec, CommonSkillDamageEvent e)
        {
            if (spec.Source == owner && spec.GameEffect.AssetTagsContainer.HasTag(EGameTag.Skill_Lyana_Special))
            {
                if (ability is LyanaHeroStart3 cfg)
                {
                    // var stack = spec.Target.GameEffectComponent.GetGameEffectSpecByAssetId(cfg.deathMark);
                    // if (stack != null)
                    // {
                    //     owner.ApplyGameEffectTo(cfg.addCrit, owner);
                    // }
                    
                    owner.ApplyGameEffectTo(cfg.addCrit, owner);
                }
            }
        }
    }
}