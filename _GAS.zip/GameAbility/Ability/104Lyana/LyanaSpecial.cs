using System;
using cfg.attribute;
using cfg.gas;
using MemoryPack;
using Meow.Runtime.AOT;
using Sirenix.OdinInspector;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 莉亚娜的特殊攻击，会引爆身上的所有的死亡印记
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class LyanaSpecial : GameAbility
    {
        [LabelText("绝死印记，充能值上限")] public int maxDeathMarkGasValue;

        [LabelText("立即引爆所有死亡印记，每层印记造成 x% 攻击力的暗黑系伤害，满层时额外造成 x%攻击力的暗黑伤害")]
        public int explosionDamageGasValue;

        [LabelText("一场战斗中，每累计引爆一层绝死印记，全体队友获得x%忽视防御,至多x层")]
        public int explosionCountGasValue;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new LyanaSpecialSpec(this, owner);
        }
    }

    public class LyanaSpecialSpec : GameAbilitySpec
    {
        // 常量定义
        private const float DEFAULT_GAS_PARAM = 9999f;
        private const float FLOAT_PRECISION_EPSILON = 1e-6f;
        private const int MAX_DEATH_MARK_LEVEL = 3;

        private LyanaSpecial _ability;

        private float _maxDeathMark; // 绝死印记最大充能值
        private int _maxDeathMarkLevel = MAX_DEATH_MARK_LEVEL; // 绝死印记最大层数 (固定值)
        private float _markValuePerLayer; // 每层所需的绝死印记
        private float _extraDamage; // 满层绝死印记 造成额外伤害
        private float _damagePerLevel; // 每层绝死印记所对应的伤害

        private int _maxExplosionCount; // 最大累计引爆层数
        private int _currentExplosionCount; // 当前累计引爆层数
        private float _defIgnore; // 引爆死亡印记，全队友获得x%忽视防御
        private float _totalAppliedDefIgnore; // 当前已累计的忽视防御

        private EventGroup _eventGroup = new();

        public LyanaSpecialSpec(LyanaSpecial ability, GameAbilitySystem o) : base(ability, o)
        {
            _ability = ability;
            _maxDeathMark = GasValue.GetParam(ability.maxDeathMarkGasValue, 1, DEFAULT_GAS_PARAM);
            _damagePerLevel = GasValue.GetParam(ability.explosionDamageGasValue, 1, DEFAULT_GAS_PARAM);
            _extraDamage = GasValue.GetParam(ability.explosionDamageGasValue, 2, DEFAULT_GAS_PARAM);

            // 参数有效性验证
            if (_maxDeathMark <= 0)
            {
                GameLog.Error($"[LyanaSpecial] 绝死印记最大充能值无效: {_maxDeathMark}，已设置为默认值1");
                _maxDeathMark = 1;
            }

            _markValuePerLayer = _maxDeathMark / _maxDeathMarkLevel;

            _defIgnore = GasValue.GetParam(ability.explosionCountGasValue, 1, DEFAULT_GAS_PARAM);
            _maxExplosionCount = (int)GasValue.GetParam(ability.explosionCountGasValue, 2, DEFAULT_GAS_PARAM);

            // 参数有效性验证
            if (_maxExplosionCount < 0)
            {
                GameLog.Error($"[LyanaSpecial] 最大累计引爆层数无效: {_maxExplosionCount}，已设置为0");
                _maxExplosionCount = 0;
            }

            _currentExplosionCount = 0;
        }

        protected override void OnAdd()
        {
            _eventGroup.AddListener<BattleStateChange>(OnLeaveBattle);
        }

        protected override void OnRemove()
        {
            _eventGroup.RemoveAllListener();
        }

        protected override void OnActive()
        {
            DamagePipeline.Instance.OnPreProcessDamage += OnPreProcessDamage;
        }

        protected override void OnDeActive()
        {
            DamagePipeline.Instance.OnPreProcessDamage -= OnPreProcessDamage;
        }

        private float OnPreProcessDamage(GameEffectSpec spec, CommonSkillDamageEvent e)
        {
            // 只处理莉亚娜的特殊攻击
            if (spec.Source != owner || !spec.GameEffect.AssetTagsContainer.HasTag(EGameTag.Skill_Lyana_Special))
            {
                return e.originalDamage;
            }

            // 空值检查
            if (spec.Target == null || spec.Target.GameAttributeComponent == null)
            {
                return e.originalDamage;
            }

            var deathMark = spec.Target.GameAttributeComponent.GetAttribute(AttributeId.LyanaDeathMark);
            if (deathMark == null)
            {
                return e.originalDamage;
            }

            float currentDeathMark = deathMark.CurrentValue;

            // 死亡印记层数 = 莉亚娜死亡印记值 / 每层死亡印记值
            int level = (int)(currentDeathMark / _markValuePerLayer + FLOAT_PRECISION_EPSILON);

            // 死亡印记不足1层时，无法引爆, 不造成伤害
            if (level <= 0)
            {
                return 0;
            }

            // 扣除已引爆的印记值
            currentDeathMark -= _markValuePerLayer * level;
            deathMark.SetBaseValue(currentDeathMark);

            // 添加全队忽视防御
            AddTeamDefIgnore(level);

            // 计算伤害：基础伤害 * (每层伤害 * 层数 + 满层额外伤害 + 1)
            float extraDamage = level == _maxDeathMarkLevel ? _extraDamage : 0;
            return e.originalDamage * (_damagePerLevel * level + extraDamage + 1);
        }

        /// <summary>
        /// 一场战斗，莉亚娜累计引爆1层绝死印记，全体队友获得x%忽视防御
        /// </summary>
        private void AddTeamDefIgnore(int level)
        {
            // 已达到最大累计层数
            if (_currentExplosionCount >= _maxExplosionCount)
            {
                return;
            }

            // 计算实际可以应用的层数（避免超过上限）
            int remainingLevels = _maxExplosionCount - _currentExplosionCount;
            int appliedLevels = Math.Min(level, remainingLevels);

            _currentExplosionCount += appliedLevels;
            float defIgnoreToAdd = appliedLevels * _defIgnore;
            _totalAppliedDefIgnore += defIgnoreToAdd;

            // 为全队添加忽视防御
            ModifyTeamDefenseIgnore(defIgnoreToAdd);
        }

        /// <summary>
        /// 脱战清空
        /// </summary>
        private void OnLeaveBattle(IEventMessage message)
        {
            if (message is BattleStateChange battleChange && !battleChange.isInBattle)
            {
                RemoveTeamDefIgnore();
                _currentExplosionCount = 0;
            }
        }

        /// <summary>
        /// 移除全队忽视防御加成
        /// </summary>
        private void RemoveTeamDefIgnore()
        {
            if (_totalAppliedDefIgnore <= 0)
            {
                return;
            }

            // 移除全队忽视防御
            ModifyTeamDefenseIgnore(-_totalAppliedDefIgnore);
            _totalAppliedDefIgnore = 0;
        }

        /// <summary>
        /// 修改全队忽视防御属性
        /// </summary>
        /// <param name="delta">属性变化值，正数为增加，负数为减少</param>
        private void ModifyTeamDefenseIgnore(float delta)
        {
            var team = World.Current.GetSystem<BattleTeamSystem>().Roles;
            if (team == null)
            {
                return;
            }

            foreach (var teamRole in team)
            {
                if (World.Current.TryGetEntityComp(teamRole.EntityId, out GameAbilitySystem gas))
                {
                    var defProb = gas.GameAttributeComponent.GetAttribute(AttributeId.DefIgnoreRate);
                    defProb.SetBaseValue(defProb.CurrentValue + delta);
                }
            }
        }
    }
}