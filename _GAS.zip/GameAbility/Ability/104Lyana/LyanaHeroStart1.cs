using System;
using cfg.gas;
using MemoryPack;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 莉亚娜对有死亡标记的目标忽略x%的防御
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class LyanaHeroStart1 : GameAbility
    {
        public int gasValue;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new LyanaHeroStart1Spec(this, owner);
        }
    }

    public class LyanaHeroStart1Spec : GameAbilitySpec
    {
        public LyanaHeroStart1Spec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
        }

        protected override void OnActive()
        {
            GameEffectPipeline.Instance.OnPreAddGameEffect += OnPreAddGameEffect;
        }

        protected override void OnDeActive()
        {
            GameEffectPipeline.Instance.OnPreAddGameEffect -= OnPreAddGameEffect;
        }

        protected override void OnTick(float dt)
        {
        }

        private bool OnPreAddGameEffect(GameEffectSpec spec)
        {
            if (spec.GameEffect.durationPolicy != EDurationPolicy.Instant)
            {
                return true;
            }
            if (spec.Source == owner
                && spec.GameEffect.AssetTagsContainer.HasTag(EGameTag.Effect_Damage)
                && spec.Target.GameTagComponent.HasTag(EGameTag.State_DeBuff_Lyana_DeathMark))
            {
                if (ability is LyanaHeroStart1 a)
                {
                    var ctx = spec.Context;
                    ctx.defIgnoreRate += GasValue.GetParam(a.gasValue, 1);
                    spec.SetContext(ctx);
                }
            }
            return true;
        }
    }
}