﻿using System;
using cfg.attribute;
using MemoryPack;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    
    /// <summary>
    /// 单位HP小于0，死亡后的处理
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class AfterDeath : GameAbility
    {
        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new AfterDeathSpec(this, owner);
        }


        public class AfterDeathSpec : GameAbilitySpec
        {
            public AfterDeathSpec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
            {

            }


            protected override void OnActive()
            {
                DamagePipeline.Instance.OnPostProcessDie += OnPostProcessDie;
            }

            private void OnPostProcessDie(GameEffectSpec spec, CommonSkillDamageEvent e)
            {
                if (spec.Target != owner)
                {
                    return;
                }
                
                owner.GameTagComponent.AddTag(EGameTag.State_Die);
            }


            protected override void OnDeActive()
            {
                DamagePipeline.Instance.OnPostProcessDie -= OnPostProcessDie;
            }
        }
    }
}