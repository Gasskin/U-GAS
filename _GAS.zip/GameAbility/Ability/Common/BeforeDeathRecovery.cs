﻿using System;
using cfg.attribute;
using MemoryPack;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{

    /// <summary>
    /// 处理伤害计算后HP小于0 ，濒临死亡前，恢复处理能力
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class BeforeDeathRecovery : GameAbility
    {
        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new BeforeDeathRecoverySpec(this, owner);
        }


        public class BeforeDeathRecoverySpec : GameAbilitySpec
        {
            public BeforeDeathRecoverySpec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
            {

            }
        }

    }

}