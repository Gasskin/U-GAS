﻿using System;
using System.Collections.Generic;
using cfg.attribute;
using cfg.skill;
using MemoryPack;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 角色能量自动恢复，前后台都会恢复
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class PersonalEnergyAutoRecovery : GameAbility
    {
        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new PersonalEnergyAutoRecoverySpec(this, owner);
        }

        public override bool CanAdd(GameAbilitySystem owner)
        {
            var hero = World.Current.GetComp<HeroUnitComp>(owner.Entity);
            return hero != null;
        }
    }

    public class PersonalEnergyAutoRecoverySpec : GameAbilitySpec
    {
        private float _coolDown;
        private int _energyId;

        public PersonalEnergyAutoRecoverySpec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
            _coolDown = 1f;
            _energyId = 0;
            var energyIds = World.Current.GetComp<HeroUnitComp>(owner.Entity)?.Config?.HeroEnergy;
            if (energyIds is { Count: > 0 })
            {
                foreach (var eId in energyIds)
                {
                    var energyCfg = TbPersonalEnergy.Instance.GetOrDefault(eId);
                    if (energyCfg is { GroupId: 0, AutoReplay: true })
                    {
                        _energyId = eId;
                    }
                }
            }
        }

        protected override void OnTick(float dt)
        {
            if (_energyId <= 0)
            {
                return;
            }
            _coolDown -= dt;
            if (_coolDown <= 0f)
            {
                _coolDown = 1f;
                RecoverEnergy(owner.Entity, IsActive, _energyId);
            }
        }

        private void RecoverEnergy(uint ent, bool isFront, int id)
        {
            var energyCfg = TbPersonalEnergy.Instance.GetOrDefault(id);
            if (energyCfg is not { GroupId: 0, AutoReplay: true })
            {
                return;
            }
            // 固定恢复
            var fix = energyCfg.Reply;
            // 前台恢复
            var front = energyCfg.ReplyPers;
            // 后台恢复
            var back = energyCfg.ReplyPersBackend;

            // 角色处于前台
            if (isFront)
            {
                fix += front;
            }
            else
            {
                fix += back;
            }

            if (World.Current.TryGetEntityComp(ent, out GameAbilitySystem gas))
            {
                var mult1 = gas.GameAttributeComponent.GetCurrentValue(AttributeId.CommonEnergyRecvMult);
                var mult2 = gas.GameAttributeComponent.GetCurrentValue(AttributeId.CommonEnergyAutoRecvMult);
                fix *= 1 + mult1 + mult2;

                var attr = gas.GameAttributeComponent.GetAttribute(AttributeId.CommonEnergy);
                attr.SetBaseValue(attr.BaseValue + fix, false);
            }
        }
    }
}