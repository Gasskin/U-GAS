using System;
using cfg.attribute;
using MemoryPack;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 奥义能量自动恢复，无加成，和属性直接相关，战斗中才会恢复
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class PowerAutoRecovery : GameAbility
    {
        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new PowerAutoRecoverySpec(this, owner);
        }
    }

    public class PowerAutoRecoverySpec : GameAbilitySpec
    {
        private float _time;
        private BattleTeamSystem _team;

        public PowerAutoRecoverySpec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
            _team = World.Current.GetSystem<BattleTeamSystem>();
        }

        protected override void OnActive()
        {
            _time = 0;
        }

        protected override void OnDeActive()
        {
        }

        protected override void OnTick(float dt)
        {
            if (!IsActive)
            {
                return;
            }
            _team ??= World.Current.GetSystem<BattleTeamSystem>();
            if (_team == null || !_team.IsInBattle)
            {
                return;
            }
            // 战斗中才会恢复
            if (Time.time - _time >= 1)
            {
                _time += 1;
                var power = owner.GameAttributeComponent.GetAttribute(AttributeId.Power);
                var rec = owner.GameAttributeComponent.GetAttribute(AttributeId.PowerAutoRecover);
                power.SetBaseValue(power.BaseValue + rec.CurrentValue, false);
            }
        }
    }
}