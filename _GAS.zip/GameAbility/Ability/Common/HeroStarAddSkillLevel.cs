using System;
using System.Collections.Generic;
using cfg.gas;
using MemoryPack;
using Meow.Runtime.HotUpdate.BattleConfig.skill;
using Sirenix.OdinInspector;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 提升技能等级
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class HeroStarAddSkillLevel : GameAbility
    {
        [InfoBox("Param1: 所需星级\nParam2: 技能Node\nParam3: 增加等级")]
        public List<int> gasValues = new();

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new HeroStarAddSkillLevelSpec(this, owner);
        }
    }

    public class HeroStarAddSkillLevelSpec : GameAbilitySpec
    {
        public HeroStarAddSkillLevelSpec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
        }

        protected override void OnAdd()
        {
            AddOrReduce(true);
        }

        protected override void OnRemove()
        {
            AddOrReduce(false);
        }

        protected override void OnActive()
        {
            
        }

        protected override void OnDeActive()
        {
        }

        protected override void OnTick(float dt)
        {
        }

        private void AddOrReduce(bool isAdd)
        {
            var value = isAdd ? 1 : -1;
            if (ability is HeroStarAddSkillLevel { gasValues: { Count: > 0 } } cfg)
            {
                if (World.Current.TryGetEntityComp(owner.Entity, out SkillComp skillComp))
                {
                    for (int i = 0; i < cfg.gasValues.Count; i++)
                    {
                        var gasValue = cfg.gasValues[i];
                        var needStart = (int)GasValue.GetParam(gasValue, 1);
                        var startTag = needStart switch
                        {
                            1 => EGameTag.State_HeroStar1,
                            2 => EGameTag.State_HeroStar2,
                            3 => EGameTag.State_HeroStar3,
                            4 => EGameTag.State_HeroStar4,
                            5 => EGameTag.State_HeroStar5,
                            6 => EGameTag.State_HeroStar6,
                            _ => EGameTag.None
                        };
                        if (startTag == EGameTag.None || owner.GameTagComponent.HasTag(startTag))
                        {
                            var node = (int)GasValue.GetParam(gasValue, 2);
                            var add = (int)GasValue.GetParam(gasValue, 3);
                            skillComp.AddSkillLevel(node, add * value);
                        }
                    }
                }
            }
        }
    }
}