using System;
using cfg.attribute;
using cfg.gas;
using cfg.hero;
using MemoryPack;
using Meow.Runtime.AOT;
using Meow.Runtime.HotUpdate.BattleConfig;
using Sirenix.OdinInspector;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    public struct LuxcisUltimateState : IEventMessage
    {
        // 进入true 退出false
        public bool isUltimate;
        public GameEffectSpec buff;
    }

    /// <summary>
    /// 光辉大招变身状态
    /// 3命：如果触发了紊乱，持续时间延长X秒最多触发X次
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class LuxcisUltimate : GameAbility
    {
        [Title("进入时加载动画"), HideLabel]
        public AssetLocationField<CustomAnimLibrary> animaLibrary;

        [Title("退出时释放技能"), HideLabel]
        public SkillConfigIdRef skill;

        [Title("光焰伤害"), HideLabel]
        public GameEffectObjectField damage;

        [Title("光焰伤害次数"), HideLabel]
        public GasParam param1;

        [Title("命座1 - 光焰伤害次数增加"), HideLabel]
        public GasParam param2;

        [Title("命座3 - 延长持续时间"), HideLabel]
        public GasParam param3;

        [Title("命座6 - 结束时回复奥义能量"), HideLabel]
        public GasParam param4;

        [Title("命座6 - 变身期间伤害增加"), HideLabel]
        public GasParam param5;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new LuxcisUltimateSpec(this, owner);
        }
    }

    public class LuxcisUltimateSpec : GameAbilitySpec
    {
        private LuxcisUltimate _cfg;
        private EventGroup _eventGroup = new();
        private int _fireNum;
        private int _num;

        public LuxcisUltimateSpec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
            _num = 0;
            _cfg = (LuxcisUltimate)ability;
            _fireNum = (int)_cfg.param1.Param1;
            if (owner.GameTagComponent.HasTag(EGameTag.State_HeroStar1))
            {
                _fireNum += (int)_cfg.param2.Param1;
            }
        }

        protected override void OnAdd()
        {
            // 切换变身
            if (ability is LuxcisUltimate cfg && World.Current.TryGetEntityComp(owner.Entity, out CharacterAnimationComponent anim))
            {
                anim.AddAddonAnimLibrary(cfg.animaLibrary.location);
            }
            _eventGroup.AddListener<SkillStageTrigger>(OnSkillStageTrigger);
            if (owner.GameTagComponent.HasTag(EGameTag.State_HeroStar3))
            {
                AbnormalAccruePipeline.Instance.OnTriggerChaos += OnTriggerChaos;
            }
            if (owner.GameTagComponent.HasTag(EGameTag.State_HeroStar6))
            {
                DamagePipeline.Instance.OnPreProcessDamage += OnPreProcessDamage;
            }
            new LuxcisUltimateState()
            {
                isUltimate = true,
                buff = FromGameEffect,
            }.SendMessage();
        }


        protected override void OnRemove()
        {
            // 退出变身
            if (ability is LuxcisUltimate cfg && World.Current.TryGetEntityComp(owner.Entity, out SkillComp skillComp))
            {
                skillComp.Spell(cfg.skill.configId);
            }
            _eventGroup.RemoveAllListener();
            if (owner.GameTagComponent.HasTag(EGameTag.State_HeroStar3))
            {
                AbnormalAccruePipeline.Instance.OnTriggerChaos -= OnTriggerChaos;
            }
            if (owner.GameTagComponent.HasTag(EGameTag.State_HeroStar6))
            {
                DamagePipeline.Instance.OnPreProcessDamage -= OnPreProcessDamage;

                var add = owner.GameAttributeComponent.GetCurrentValue(AttributeId.PowerRecvMult);
                var power = owner.GameAttributeComponent.GetAttribute(AttributeId.Power);
                power.SetBaseValue(power.BaseValue + _cfg.param4.Param1 * (1 + add));
            }
            new LuxcisUltimateState()
            {
                isUltimate = false
            }.SendMessage();
        }

        private float OnPreProcessDamage(GameEffectSpec spec, CommonSkillDamageEvent e)
        {
            if (spec.Source == owner)
            {
                return e.originalDamage * (1 + _cfg.param5.Param1);
            }
            return e.originalDamage;
        }


        private void OnSkillStageTrigger(IEventMessage ie)
        {
            if (ie is not SkillStageTrigger e
                || e.casterId != owner.Entity
                || e.stage != ESkillStage.PostHit)
            {
                return;
            }
            var skillCfg = TbSkillConfig.Instance.GetOrDefault(e.skillTid);
            if (skillCfg != null && skillCfg.tagsContainer.HasTag(EGameTag.Skill_Luxcis_Attack))
            {
                for (int i = 0; i < e.targets.Count; i++)
                {
                    if (e.targets[i].target == owner.Entity)
                    {
                        continue;
                    }
                    var num = _fireNum;
                    var enemy = e.targets[i].target;
                    World.Current.TryGetEntityComp(enemy, out GameAbilitySystem target);
                    World.Current.TryGetEntityComp(enemy, out UnitGameObjectComp unit);
                    while (num-- > 0)
                    {
                        owner.ApplyGameEffectTo(_cfg.damage, new GameEffectContext()
                        {
                            hitPoint = unit.Root.transform.position
                        }, target);
                    }
                }
            }
        }

        private void OnTriggerChaos(GameEffectSpec spec, Element e, EGameTag abnormal)
        {
            if (spec.Source == owner && _num++ < _cfg.param3.Param2)
            {
                FromGameEffect.AddDuration(_cfg.param3.Param1);
            }
        }
    }
}