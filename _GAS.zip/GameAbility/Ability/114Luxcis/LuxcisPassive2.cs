using System;
using System.Collections.Generic;
using MemoryPack;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 处于光明异常的敌人每秒受到伤害
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class LuxcisPassive2 : GameAbility
    {
        public GameEffectObjectField damage;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new LuxcisPassive2Spec(this, owner);
        }
    }

    public class LuxcisPassive2Spec : GameAbilitySpec
    {
        private SecondsCheck _oneSecond = new(1f);

        private List<GameAbilitySystem> _filter1 = new();
        private List<UnitGameObjectComp> _filter2 = new();

        private LuxcisPassive2 _cfg;

        public LuxcisPassive2Spec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
            _cfg = (LuxcisPassive2)ability;
        }

        protected override void OnActive()
        {
            _oneSecond.Reset();
        }

        protected override void OnDeActive()
        {
        }

        protected override void OnTick(float dt)
        {
            if (IsActive)
            {
                if (_oneSecond.Tick(dt))
                {
                    World.Current.FilterNoAlloc<GameAbilitySystem, UnitGameObjectComp, MonsterUnitComp>(_filter1, _filter2, null);
                    for (int i = 0; i < _filter1.Count; i++)
                    {
                        if (_filter1[i].GameTagComponent.HasTag(EGameTag.State_DeBuff_Abnormal_Light))
                        {
                            owner.ApplyGameEffectTo(_cfg.damage, new GameEffectContext()
                            {
                                hitPoint =  _filter2[i].Root.transform.position
                            }, _filter1[i]);
                        }
                    }
                }
            }
        }
    }
}