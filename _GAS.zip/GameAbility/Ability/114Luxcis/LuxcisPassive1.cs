using System;
using cfg.gas;
using MemoryPack;
using Sirenix.OdinInspector;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 光焰伤害对处于光焰异常的敌人增加x%
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class LuxcisPassive1 : GameAbility
    {
        [LabelText("增伤")]
        public GasParam param;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new LuxcisPassive1Spec(this, owner);
        }
    }

    public class LuxcisPassive1Spec : GameAbilitySpec
    {
        private LuxcisPassive1 _cfg;
        public LuxcisPassive1Spec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
            _cfg = (LuxcisPassive1)ability;
        }

        protected override void OnActive()
        {
            DamagePipeline.Instance.OnPreProcessDamage += OnPreProcessDamage;
        }

        protected override void OnDeActive()
        {
            DamagePipeline.Instance.OnPreProcessDamage -= OnPreProcessDamage;
        }

        private float OnPreProcessDamage(GameEffectSpec spec, CommonSkillDamageEvent e)
        {
            if (spec.Source == owner
                && spec.Target.GameTagComponent.HasTag(EGameTag.State_DeBuff_Abnormal_Light)
                && spec.GameEffect.AssetTagsContainer.HasTag(EGameTag.Skill_Luxcis_UltimateFire))
            {
                return e.originalDamage * (1 + _cfg.param.Param1);
            }
            return e.originalDamage;
        }
    }
}