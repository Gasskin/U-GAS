using System;
using cfg.attribute;
using cfg.gas;
using MemoryPack;
using Meow.Runtime.AOT;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// Sia 被动1 105501
    /// 希娅为当前生命值小于等于50%的我方目标提供治疗时，治疗量最高x%。
    /// 该效果对【汉堡】的持续治疗效果也会生效
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class SiaPassive1 : GameAbility
    {
        public int gasValueId;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new SiaPassive1Spec(this, owner);
        }
    }

    public class SiaPassive1Spec : GameAbilitySpec
    {
        private SiaPassive1 _ability;

        public SiaPassive1Spec(SiaPassive1 ability, GameAbilitySystem o) : base(ability, o)
        {
            _ability = ability;
        }

        protected override void OnAdd()
        {
            // 注册希娅的GAS到FoodBuffSystem
            var foodBuffSystem = World.Current.GetSystem<FoodBuffSystem>();
            if (foodBuffSystem != null)
            {
                foodBuffSystem.RegisterSiaGas(owner);
            }
        }

        protected override void OnRemove()
        {
            // 注销希娅的GAS
            var foodBuffSystem = World.Current.GetSystem<FoodBuffSystem>();
            if (foodBuffSystem != null)
            {
                foodBuffSystem.UnRegisterSiaGas();
            }
        }

        protected override void OnActive()
        {
            // 监听治疗前事件，用于添加临时属性
            HpRecoverPipeline.Instance.OnPreHpRecover += OnPreHpRecover;
        }

        protected override void OnDeActive()
        {
            // 注销治疗事件监听
            HpRecoverPipeline.Instance.OnPreHpRecover -= OnPreHpRecover;
        }

        private float OnPreHpRecover(GameEffectSpec spec, float value)
        {
            // 检查是否是希娅施放的治疗
            if (spec.Source != owner)
            {
                return value;
            }

            // 检查被治疗的目标生命值是否低于阈值
            var targetHpPercent = spec.Target.GameAttributeComponent.GetHpPercentage();
            var threshold = GasValue.GetParam(_ability.gasValueId, 1); // 参数1: 生命值阈值(50%)

            if (targetHpPercent <= threshold && targetHpPercent > 0)
            {
                // 在满足条件时，应用希娅被动加成
                // 注意：属性加成已经在CalculateMagnitude中应用过了
                // 这里直接修改value作为额外的加成
                var healBonus = GasValue.GetParam(_ability.gasValueId, 2); // 参数2: 治疗量加成百分比
                value *= (1f + healBonus);

                GameLog.Info($"[SiaPassive1] 触发低血量治疗加成，目标生命值: {targetHpPercent * 100}%, 治疗加成: {healBonus * 100}%");
            }

            return value;
        }
    }
}
