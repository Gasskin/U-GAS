using System;
using System.Collections.Generic;
using MemoryPack;
using Meow.Runtime.AOT;
using Meow.Runtime.HotUpdate.BattleConfig.skill;
using Sirenix.OdinInspector;
using UnityEngine;
using Meow.Runtime.HotUpdate.BattleConfig;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 红茶治疗特效模式
    /// </summary>
    public enum ERedTeaVfxMode
    {
        [LabelText("常驻特效(跟随Buff生命周期)")]
        Persistent = 0,
        [LabelText("周期特效(每次治疗播放一次)")]
        PerHeal = 1,
    }

    /// <summary>
    /// 希娅特效管理能力
    /// 负责管理红茶治疗特效的两种模式：
    /// 1. 常驻特效：buff存在时播放循环特效，buff移除时停止
    /// 2. 周期特效：每次治疗时播放一次短特效
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class SiaShowVFX : GameAbility
    {
        [LabelText("特效模式")]
        public ERedTeaVfxMode vfxMode = ERedTeaVfxMode.Persistent;

        [LabelText("特效资源")]
        [ShowIf("@vfxMode == ERedTeaVfxMode.Persistent")]
        [MemoryPackAllowSerialize]
        public AssetLocationField<GameObject> persistentVfxPrefab;

        [LabelText("特效资源")]
        [ShowIf("@vfxMode == ERedTeaVfxMode.PerHeal")]
        [MemoryPackAllowSerialize]
        public AssetLocationField<GameObject> perHealVfxPrefab;

        [LabelText("特效冷却时间")]
        [ShowIf("@vfxMode == ERedTeaVfxMode.PerHeal")]
        [Tooltip("同一目标在冷却时间内不重复播放特效，防止多个红茶buff同时触发导致特效过多")]
        public float perHealVfxCooldown = 1f;

        [LabelText("创建点")]
        public E_CharacterBone vfxPoint = E_CharacterBone.Root;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new SiaShowVFXSpec(this, owner);
        }
    }

    public class SiaShowVFXSpec : GameAbilitySpec
    {
        private readonly SiaShowVFX _cfg;
        private readonly Dictionary<uint, int> _persistentVfxIds = new();
        
        // 周期特效冷却控制（按实体记录上次播放时间）
        private readonly Dictionary<uint, float> _perHealVfxLastPlayTime = new();

        public SiaShowVFXSpec(SiaShowVFX ability, GameAbilitySystem o) : base(ability, o)
        {
            _cfg = ability;
        }

        protected override void OnActive()
        {
            // 监听GE添加事件（用于播放常驻特效）
            GameEffectPipeline.Instance.OnPostAddNewGameEffect += OnGameEffectAdded;
            // 监听GE移除事件（用于停止常驻特效）
            GameEffectPipeline.Instance.OnPostRemoveGameEffect += OnGameEffectRemoved;
            // 监听周期GE执行事件（用于播放周期特效）
            GameEffectPipeline.Instance.OnPeriodExecute += OnPeriodExecute;
        }

        protected override void OnDeActive()
        {
            GameEffectPipeline.Instance.OnPostAddNewGameEffect -= OnGameEffectAdded;
            GameEffectPipeline.Instance.OnPostRemoveGameEffect -= OnGameEffectRemoved;
            GameEffectPipeline.Instance.OnPeriodExecute -= OnPeriodExecute;

            // 清理所有常驻特效
            foreach (var kvp in _persistentVfxIds)
            {
                InGameDomain.VfxService.StopVfx(kvp.Value);
            }
            _persistentVfxIds.Clear();
            _perHealVfxLastPlayTime.Clear();
        }

        /// <summary>
        /// GE添加事件 - 播放常驻特效或首次周期特效
        /// </summary>
        private void OnGameEffectAdded(GameEffectSpec spec)
        {
            if (spec?.GameEffect == null)
            {
                return;
            }
            if (!spec.GameEffect.GrantedTagsContainer.HasTag(EGameTag.State_Buff_Sia_RedTea))
            {
                return;
            }

            var targetEntity = spec.Target.Entity;

            if (_cfg.vfxMode == ERedTeaVfxMode.Persistent)
            {
                // 用字典检查：这个目标已经有特效了就不重复创建
                if (_persistentVfxIds.ContainsKey(targetEntity))
                {
                    return;
                }
                PlayPersistentVfx(targetEntity);
            }
            else if (_cfg.vfxMode == ERedTeaVfxMode.PerHeal)
            {
                // 首次应用时也播放一次
                PlayPerHealVfx(targetEntity);
            }
        }

        /// <summary>
        /// GE移除事件 - 停止常驻特效
        /// </summary>
        private void OnGameEffectRemoved(GameEffectSpec spec)
        {
            if (spec?.GameEffect == null)
            {
                return;
            }
            if (!spec.GameEffect.GrantedTagsContainer.HasTag(EGameTag.State_Buff_Sia_RedTea))
            {
                return;
            }

            // 只有当目标身上没有红茶buff时才停止特效
            if (!spec.Target.GameTagComponent.HasTag(EGameTag.State_Buff_Sia_RedTea))
            {
                StopPersistentVfx(spec.Target.Entity);
                _perHealVfxLastPlayTime.Remove(spec.Target.Entity);
            }
        }

        /// <summary>
        /// 周期GE执行事件 - 播放周期特效
        /// </summary>
        private void OnPeriodExecute(GameEffectSpec parentSpec, GameEffectSpec periodSpec)
        {
            if (parentSpec?.GameEffect == null)
            {
                return;
            }
            if (!parentSpec.GameEffect.GrantedTagsContainer.HasTag(EGameTag.State_Buff_Sia_RedTea))
            {
                return;
            }

            if (_cfg.vfxMode == ERedTeaVfxMode.PerHeal)
            {
                PlayPerHealVfx(parentSpec.Target.Entity);
            }
        }

        private void PlayPersistentVfx(uint targetEntity)
        {
            if (_cfg.persistentVfxPrefab == null)
            {
                return;
            }
            if (_persistentVfxIds.ContainsKey(targetEntity))
            {
                GameLog.Info($"[SiaShowVFX] 目标 {targetEntity} 已有常驻特效，跳过");
                return;
            }

            if (!World.Current.TryGetEntityComp<CharacterVfxComp>(targetEntity, out var vfxComp))
            {
                return;
            }

            // 常驻特效传一个很大的时间，让它不会自动结束，由我们手动Stop
            vfxComp.PlayVfx(
                _cfg.persistentVfxPrefab,
                _cfg.vfxPoint,
                true,
                Vector3.zero,
                Vector3.zero,
                1f,
                9999f,  // 很长的生命周期，手动控制结束
                out var vfxId
            );

            GameLog.Info($"[SiaShowVFX] 播放常驻特效，目标: {targetEntity}, vfxId: {vfxId}");

            if (vfxId != 0)
            {
                _persistentVfxIds[targetEntity] = vfxId;
            }
        }

        private void StopPersistentVfx(uint targetEntity)
        {
            if (!_persistentVfxIds.TryGetValue(targetEntity, out var vfxId))
            {
                return;
            }

            _persistentVfxIds.Remove(targetEntity);
            InGameDomain.VfxService.StopVfx(vfxId);
        }

        private void PlayPerHealVfx(uint targetEntity)
        {
            if (_cfg.perHealVfxPrefab == null)
            {
                return;
            }

            // 冷却检查：同一目标在冷却时间内不重复播放
            var currentTime = Time.time;
            if (_perHealVfxLastPlayTime.TryGetValue(targetEntity, out var lastTime))
            {
                if (currentTime - lastTime < _cfg.perHealVfxCooldown)
                {
                    return;
                }
            }

            if (!World.Current.TryGetEntityComp<CharacterVfxComp>(targetEntity, out var vfxComp))
            {
                return;
            }

            vfxComp.PlayVfx(
                _cfg.perHealVfxPrefab,
                _cfg.vfxPoint,
                true,
                Vector3.zero,
                Vector3.zero,
                1f,
                out _
            );

            _perHealVfxLastPlayTime[targetEntity] = currentTime;
        }
    }
}
