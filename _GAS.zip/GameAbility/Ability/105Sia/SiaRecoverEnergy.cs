using System;
using cfg.attribute;
using MemoryPack;
using Meow.Runtime.AOT;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// Sia 破韧/击杀恢复能量
    /// 当队伍击破怪物韧性时产生个人能量
    /// 队伍完成击杀时产生个人能量
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class SiaRecoverEnergy : GameAbility
    {
        /// <summary>
        /// GAS数值ID
        /// 参数1: 破韧时恢复的个人能量点数
        /// 参数2: 击杀时恢复的个人能量点数
        /// </summary>
        public int gasValueId;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new SiaRecoverEnergySpec(this, owner);
        }
    }

    public class SiaRecoverEnergySpec : GameAbilitySpec
    {
        private readonly SiaRecoverEnergy _ability;
        private readonly EventGroup _eventGroup = new();

        public SiaRecoverEnergySpec(SiaRecoverEnergy ability, GameAbilitySystem o) : base(ability, o)
        {
            _ability = ability;
        }

        protected override void OnActive()
        {
            // 监听韧性破坏事件
            _eventGroup.AddListener<ToughnessReduceEvent>(OnToughnessReduce);
            // 监听击杀事件
            _eventGroup.AddListener<EntityDieEvent>(OnEntityDie);

            GameLog.Info("[SiaRecoverEnergy] 激活：破韧/击杀恢复希娅个人能量");
        }

        protected override void OnDeActive()
        {
            _eventGroup.RemoveAllListener();
        }

        /// <summary>
        /// 韧性破坏事件回调
        /// </summary>
        private void OnToughnessReduce(IEventMessage message)
        {
            if (message is not ToughnessReduceEvent e)
            {
                return;
            }

            // 只处理破韧触发的情况
            if (!e.isBreakTriggered)
            {
                return;
            }

            // 获取希娅的阵营
            if (!World.Current.TryGetEntityComp<FeatureComp>(owner.Entity, out var siaFeature))
            {
                return;
            }

            // 检查破韧来源是否是队友
            if (e.sourceSpec?.Source == null)
            {
                return;
            }

            if (!siaFeature.IsMate(e.sourceSpec.Source.Entity))
            {
                return;
            }

            // 获取破韧时恢复的能量值
            var energyOnBreak = cfg.gas.GasValue.GetParam(_ability.gasValueId, 1);

            if (energyOnBreak <= 0)
            {
                return;
            }

            AddPersonalEnergy(energyOnBreak, "破韧");
        }

        /// <summary>
        /// 击杀事件回调
        /// </summary>
        private void OnEntityDie(IEventMessage message)
        {
            if (message is not EntityDieEvent e)
            {
                return;
            }

            // 检查死亡的是否是怪物
            if (!World.Current.TryGetEntityComp<MonsterUnitComp>(e.entityId, out _))
            {
                return;
            }

            // 获取希娅的阵营
            if (!World.Current.TryGetEntityComp<FeatureComp>(owner.Entity, out var siaFeature))
            {
                return;
            }

            // 检查死亡的怪物是否是敌人（不是队友）
            if (siaFeature.IsMate(e.entityId))
            {
                return;
            }

            // 获取击杀时恢复的能量值
            var energyOnKill = cfg.gas.GasValue.GetParam(_ability.gasValueId, 2);

            if (energyOnKill <= 0)
            {
                return;
            }

            AddPersonalEnergy(energyOnKill, "击杀");
        }

        /// <summary>
        /// 增加个人能量
        /// </summary>
        private void AddPersonalEnergy(float amount, string source)
        {
            var currentEnergy = owner.GameAttributeComponent.GetCurrentValue(AttributeId.CommonEnergy);
            var newEnergy = currentEnergy + amount;
            owner.GameAttributeComponent.GetAttribute(AttributeId.CommonEnergy).SetBaseValue(newEnergy, false);
            GameLog.Info($"[SiaRecoverEnergy] {source}恢复个人能量: {amount}, 当前能量: {newEnergy}");
        }
    }
}
