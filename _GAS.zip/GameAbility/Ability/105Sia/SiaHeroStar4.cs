using System;
using cfg.attribute;
using cfg.gas;
using MemoryPack;
using Meow.Runtime.AOT;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// Sia 命座4 105704
    /// 希娅生命值首次低于30%时立即回复x%生命值上限，一场战斗可触发1次
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class SiaHeroStar4 : GameAbility
    {
        public int gasValueId;
        public GameEffectObjectField emergencyHeal; // 紧急治疗GE

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new SiaHeroStar4Spec(this, owner);
        }

        public override bool CanAdd(GameAbilitySystem owner)
        {
            return owner.GameTagComponent.HasTag(EGameTag.State_HeroStar4);
        }
    }

    public class SiaHeroStar4Spec : GameAbilitySpec
    {
        private readonly SiaHeroStar4 _ability;
        private bool _hasTriggered; // 是否已触发过

        public SiaHeroStar4Spec(SiaHeroStar4 ability, GameAbilitySystem o) : base(ability, o)
        {
            _ability = ability;
        }

        protected override void OnActive()
        {
            _hasTriggered = false;
            // 监听希娅自己的生命值变化
            owner.GameAttributeComponent.GetAttribute(AttributeId.NowHp).OnPostCurrentValueChange += OnHpChanged;
        }

        protected override void OnDeActive()
        {
            // 注销生命值监听
            owner.GameAttributeComponent.GetAttribute(AttributeId.NowHp).OnPostCurrentValueChange -= OnHpChanged;
        }

        /// <summary>
        /// 希娅生命值变化回调
        /// </summary>
        private void OnHpChanged(float oldValue, float newValue)
        {
            // 已触发过则不再触发
            if (_hasTriggered)
            {
                return;
            }

            // 只有血量降低时才检查
            if (newValue >= oldValue)
            {
                return;
            }

            // 检查当前血量百分比
            var hpPercent = owner.GameAttributeComponent.GetHpPercentage();
            var threshold = GasValue.GetParam(_ability.gasValueId, 1); // 参数1: 生命值阈值(30%)

            // 血量低于阈值且还活着
            if (hpPercent <= threshold && hpPercent > 0)
            {
                // 触发紧急治疗（给自己）
                owner.ApplyGameEffectTo(_ability.emergencyHeal, owner);
                _hasTriggered = true;
                GameLog.Info($"[SiaHeroStar4] 触发紧急治疗，生命值: {hpPercent * 100:F1}%");
            }
        }
    }
}

