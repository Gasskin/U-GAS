using System;
using cfg.attribute;
using MemoryPack;
using Meow.Runtime.AOT;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// Sia 被动2 105502
    /// 队友吃x个食物，希娅恢复奥义能量x点
    ///
    /// 监听所有队友的食物消耗事件，每次队友消耗食物时，希娅恢复奥义能量
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class SiaPassive2 : GameAbility
    {
        /// <summary>
        /// GAS数值ID
        /// 参数1: 每个食物恢复的奥义能量点数
        /// </summary>
        public int gasValueId;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new SiaPassive2Spec(this, owner);
        }
    }

    public class SiaPassive2Spec : GameAbilitySpec
    {
        private readonly SiaPassive2 _ability;
        private readonly EventGroup _eventGroup = new();

        public SiaPassive2Spec(SiaPassive2 ability, GameAbilitySystem o) : base(ability, o)
        {
            _ability = ability;
        }

        protected override void OnActive()
        {
            // 监听食物消耗事件
            _eventGroup.AddListener<FoodConsumedEvent>(OnFoodConsumed);

            GameLog.Info("[SiaPassive2] 被动激活：队友吃食物恢复希娅奥义能量");
        }

        protected override void OnDeActive()
        {
            _eventGroup.RemoveAllListener();
        }

        /// <summary>
        /// 食物消耗事件回调
        /// </summary>
        private void OnFoodConsumed(IEventMessage message)
        {
            if (message is not FoodConsumedEvent e)
            {
                return;
            }

            // 获取希娅的阵营
            if (!World.Current.TryGetEntityComp<FeatureComp>(owner.Entity, out var siaFeature))
            {
                return;
            }

            // 检查消耗者是否是队友（包括希娅自己）
            if (!siaFeature.IsMate(e.consumerId))
            {
                return;
            }

            // 获取每个食物恢复的能量值
            var energyPerFood = cfg.gas.GasValue.GetParam(_ability.gasValueId, 1);

            if (energyPerFood <= 0)
            {
                GameLog.Warning($"[SiaPassive2] 食物能量恢复值配置错误: {energyPerFood}");
                return;
            }

            var currentEnergy = owner.GameAttributeComponent.GetCurrentValue(AttributeId.Power);
            var newEnergy = currentEnergy + energyPerFood;
            owner.GameAttributeComponent.GetAttribute(AttributeId.Power).SetBaseValue(newEnergy, false);
            GameLog.Info($"[SiaPassive2] 食物消耗恢复奥义能量: {energyPerFood}, 当前能量: {newEnergy}");
        }
    }
}
