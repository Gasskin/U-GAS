using System;
using cfg.gas;
using Meow.Runtime.AOT;
using Meow.Runtime.HotUpdate.BattleConfig;
using Meow.Runtime.HotUpdate.BattleConfig.skill;
using MemoryPack;
using cfg.attribute;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 希娅奥义技能 (105401)
    /// 立即为我方全体回复等同于希娅生命上限x%+x点的生命值，并爆出x个随机食物
    ///
    /// 命座1效果：奥义对当前生命值≤50%的我方目标额外附加一段治疗
    /// 命座3效果：奥义为全体队员额外提供伤害减免
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class SiaUltimateSkill : GameAbility
    {
        /// <summary>
        /// 命座1：额外治疗GE（对血量≤50%的目标）
        /// </summary>
        public GameEffectObjectField star1ExtraHealEffect;

        /// <summary>
        /// 命座1：GAS参数ID（Param1=血量阈值）
        /// </summary>
        public int star1GasValueId;

        /// <summary>
        /// 命座3：伤害减免Buff
        /// </summary>
        public GameEffectObjectField star3DamageReduceEffect;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new SiaUltimateSkillSpec(this, owner);
        }
    }

    /// <summary>
    /// 希娅奥义技能的Spec实现
    /// </summary>
    public class SiaUltimateSkillSpec : GameAbilitySpec
    {
        private readonly SiaUltimateSkill _ability;
        private readonly EventGroup _eventGroup;

        // 命座1：每次奥义只触发一次额外治疗
        private bool _star1CanTrigger;

        public SiaUltimateSkillSpec(SiaUltimateSkill ability, GameAbilitySystem o) : base(ability, o)
        {
            _ability = ability;
            _eventGroup = new EventGroup();
        }

        protected override void OnActive()
        {
            // 监听奥义释放事件（Start阶段重置命座1标志，PostHit阶段触发命座3）
            _eventGroup.AddListener<SkillStageTrigger>(OnSkillStageTrigger);

            // 监听治疗事件（命座1：低血量额外治疗）
            HpRecoverPipeline.Instance.OnPreHpRecover += OnPreHpRecover;
        }

        protected override void OnDeActive()
        {
            _eventGroup.RemoveAllListener();
            HpRecoverPipeline.Instance.OnPreHpRecover -= OnPreHpRecover;
        }

        /// <summary>
        /// 命座1：治疗前回调，检查目标血量是否≤阈值，施加额外治疗（每次奥义只触发一次）
        /// </summary>
        private float OnPreHpRecover(GameEffectSpec spec, float value)
        {
            // 必须有命座1且本次奥义还未触发过
            if (!_star1CanTrigger)
            {
                return value;
            }

            // 必须有命座1
            if (!owner.GameTagComponent.HasTag(EGameTag.State_HeroStar1))
            {
                return value;
            }

            // 必须是希娅施放的治疗
            if (spec.Source != owner)
            {
                return value;
            }

            // 检查是否是奥义治疗（通过专用Tag判断，避免命座1额外治疗再次触发）
            if (!spec.GameEffect.AssetTagsContainer.HasTag(EGameTag.State_Buff_Sia_Ultimate))
            {
                return value;
            }

            // 检查目标生命值是否≤阈值
            var targetHpPercent = spec.Target.GameAttributeComponent.GetHpPercentage();
            var threshold = GasValue.GetParam(_ability.star1GasValueId, 1); // 参数1: 生命值阈值

            if (targetHpPercent <= threshold && targetHpPercent > 0)
            {
                // 标记本次奥义已触发命座1
                _star1CanTrigger = false;

                // 施加额外治疗
                owner.ApplyGameEffectTo(_ability.star1ExtraHealEffect, spec.Target);
                GameLog.Info($"[SiaUltimateSkill] 命座1触发额外治疗，目标血量: {targetHpPercent * 100:F1}%");
            }

            return value;
        }

        /// <summary>
        /// 技能阶段事件回调
        /// - Start阶段：重置命座1触发标志
        /// - 命座3效果
        /// </summary>
        private void OnSkillStageTrigger(IEventMessage message)
        {
            if (message is not SkillStageTrigger e)
            {
                return;
            }

            // 必须是希娅自己释放的技能
            if (e.casterId != owner.Entity)
            {
                return;
            }

            // 检查是否是奥义技能
            var skillConfig = TbSkillConfig.Instance.GetOrDefault(e.skillTid);
            if (skillConfig == null || skillConfig.type != ESkillType.Ultimate)
            {
                return;
            }

            // // 临时添加测试希娅能量恢复
            // if (e.stage == ESkillStage.Start)
            // {
            //     var specialEnergy = owner.GameAttributeComponent.GetCurrentValue(AttributeId.PersonalEnergy);
            //     var specialNewEnergy = specialEnergy + 1;
            //     owner.GameAttributeComponent.GetAttribute(AttributeId.PersonalEnergy).SetBaseValue(specialNewEnergy);
            // }

            // Start阶段：重置命座1触发标志
            if (e.stage == ESkillStage.Start && owner.GameTagComponent.HasTag(EGameTag.State_HeroStar1))
            {
                _star1CanTrigger = true;
                GameLog.Info("[SiaUltimateSkill] 奥义开始，重置命座1触发标志");
            }

            // 命座3：给全体队员添加伤害减免Buff（可以在Start或其他阶段触发，根据需求调整）
            if (e.stage == ESkillStage.Start && owner.GameTagComponent.HasTag(EGameTag.State_HeroStar3))
            {
                var roles = World.Current.GetSystem<BattleTeamSystem>().Roles;
                foreach (var role in roles)
                {
                    if (World.Current.TryGetEntityComp<GameAbilitySystem>(role.EntityId, out var heroGas))
                    {
                        owner.ApplyGameEffectTo(_ability.star3DamageReduceEffect, heroGas);
                    }
                }

                GameLog.Info("[SiaUltimateSkill] 命座3触发，给全体队员添加伤害减免Buff");
            }
        }
    }
}

