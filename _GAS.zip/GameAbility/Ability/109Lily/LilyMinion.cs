using System;
using System.Collections.Generic;
using cfg.attribute;
using cfg.gas;
using MemoryPack;
using Meow.Runtime.AOT;
using Meow.Runtime.HotUpdate.BattleConfig;
using Meow.Runtime.HotUpdate.BattleConfig.gameAction;
using Sirenix.OdinInspector;

namespace Meow.Runtime.HotUpdate
{
    [Serializable]
    [MemoryPackable]
    public partial class LilyMinion : GameAbility
    {
        [Title("召唤物配置")]
        public CharacterConfigIdRef minionIdRef;

        [Title("莉莉攻击3 恢复宝宝能量")]
        public SkillConfigIdRef attack3;

        public GameEffectObjectField attack3AddMinionEnergy;

        [Title("奥义添加通灵buff")]
        public SkillConfigIdRef ultimate;

        public GameEffectObjectField ultimateCritRateBuff;

        [Title("宝宝属性继承")]
        // 比例
        public GasParam attrInheritanceRatio;

        // 宝宝额外生命值
        public GasParam minionExHpAdd;

        [Title("通过奥义召唤的宝宝获得能量")]
        public GasParam minionE1FromUltimate;

        [Title("释放奥义时如果宝宝在场")]
        // 额外恢复能量
        public GasParam minionExE1FromUltimate;

        // 获得霸体
        public GameEffectObjectField armorBuff;

        // 恢复所有生命
        public GameEffectObjectField hpRecover;

        [Title("每次召唤都会上祝福")]
        public GameEffectObjectField blessBuff;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new LilyMinionSpec(this, owner);
        }
    }

    public class LilyMinionSpec : GameAbilitySpec
    {
        private LilyMinion _cfg;

        private EventGroup _eventGroup = new();

        private uint _minionId;

        public LilyMinionSpec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
            _cfg = (LilyMinion)ability;
        }

        protected override void OnActive()
        {
            _eventGroup.AddListener<GameActionEvent>(OnSpawnLilyMinion);
            _eventGroup.AddListener<GameActionEvent>(OnFlashLilyMinion);
            _eventGroup.AddListener<EntityDieEvent>(OnEntityDieEvent);
            _eventGroup.AddListener<SkillStageTrigger>(OnSkillStageTrigger);
        }


        protected override void OnDeActive()
        {
            _eventGroup.RemoveAllListener();
        }


        private void OnSkillStageTrigger(IEventMessage ie)
        {
            if (ie is not SkillStageTrigger e)
            {
                return;
            }
            if (_minionId <= 0)
            {
                return;
            }

            Ultimate();
            Attack3();
            return;

            // 奥义添加通灵BUFF
            void Ultimate()
            {
                if (!e.Is(owner.Entity, ESkillStage.Start, _cfg.ultimate.configId))
                {
                    return;
                }
                if (World.Current.TryGetEntityComp(_minionId, out GameAbilitySystem minion))
                {
                    var e1 = minion.GameAttributeComponent.GetAttribute(AttributeId.PersonalEnergy);
                    e1.SetBaseValue(e1.BaseValue + _cfg.minionExE1FromUltimate.Param1);
                    owner.ApplyGameEffectTo(_cfg.ultimateCritRateBuff, minion);
                    owner.ApplyGameEffectTo(_cfg.armorBuff, minion);
                    owner.ApplyGameEffectTo(_cfg.hpRecover, minion);
                }
            }

            // 普通工攻击3恢复宝宝能量
            void Attack3()
            {
                if (!e.Is(owner.Entity, ESkillStage.PostHit, _cfg.attack3.configId))
                {
                    return;
                }
                if (World.Current.TryGetEntityComp(_minionId, out GameAbilitySystem minion))
                {
                    owner.ApplyGameEffectTo(_cfg.attack3AddMinionEnergy, minion);
                }
            }
        }

        private void OnSpawnLilyMinion(IEventMessage ie)
        {
            if (ie is not GameActionEvent { eventId: EGameActionEvent.SpawnLilyMinion } e)
            {
                return;
            }
            if (_minionId <= 0)
            {
                var initAttrs = new Dictionary<AttributeId, float>();
                owner.GameAttributeComponent.CaptureAttr(initAttrs);
                initAttrs[AttributeId.HpBase] *= _cfg.attrInheritanceRatio.LvUpValue(owner);
                initAttrs[AttributeId.HpMult] *= _cfg.attrInheritanceRatio.LvUpValue(owner);
                initAttrs[AttributeId.HpAdd] *= _cfg.attrInheritanceRatio.LvUpValue(owner);
                initAttrs[AttributeId.HpAdd] += _cfg.minionExHpAdd.LvUpValue(owner);
                initAttrs[AttributeId.PersonalEnergy] = 0;
                if (e.floatParams.Length > 0 && e.floatParams[0] > 0)
                {
                    initAttrs[AttributeId.PersonalEnergy] = _cfg.minionE1FromUltimate.Param1;
                }
                var info = new BattleMinionEntitySpawnInfo(_cfg.minionIdRef.id, owner.Entity, initAttrs, Camp.PlayerMinion);
                BattleUnitHelper.CreateMinion(info, out _minionId);

                owner.ApplyGameEffectTo(_cfg.blessBuff, owner);
                if (World.Current.TryGetEntityComp(_minionId, out GameAbilitySystem minion))
                {
                    owner.ApplyGameEffectTo(_cfg.blessBuff, minion);
                }
            }
        }

        private void OnFlashLilyMinion(IEventMessage ie)
        {
            if (ie is not GameActionEvent { eventId: EGameActionEvent.FlashLilyMinion })
            {
                return;
            }
            if (_minionId > 0)
            {
                var m = World.Current.GetComp<AIComp>(_minionId);
                m?.SetBool("flash", true);
            }
        }

        private void OnEntityDieEvent(IEventMessage ie)
        {
            if (ie is not EntityDieEvent e)
            {
                return;
            }
            if (e.entityId == _minionId)
            {
                _minionId = 0;
            }
        }
    }
}