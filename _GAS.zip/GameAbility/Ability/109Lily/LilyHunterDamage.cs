using System;
using cfg.gas;
using MemoryPack;
using Meow.Runtime.HotUpdate.BattleConfig;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 存在猎人印记的目标受到莉莉和宝宝的伤害增加
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class LilyHunterDamage : GameAbility
    {
        public GameEffectAssetIdRef hunterMarkIdRef;
        public GasParam hunterDmgMult;
        
        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new LilyHunterDamageSpec(this, owner);
        }
    }

    public class LilyHunterDamageSpec : GameAbilitySpec
    {
        private LilyHunterDamage _cfg;

        public LilyHunterDamageSpec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
            _cfg = (LilyHunterDamage)ability;
        }

        protected override void OnActive()
        {
            DamagePipeline.Instance.OnPreProcessDamage += OnPreProcessDamage;
        }

        protected override void OnDeActive()
        {
            DamagePipeline.Instance.OnPreProcessDamage -= OnPreProcessDamage;
        }
        
        private float OnPreProcessDamage(GameEffectSpec spec, CommonSkillDamageEvent e)
        {
            if (spec.Source == owner)
            {
                if (spec.Target.GameTagComponent.HasTag(EGameTag.State_DeBuff_Lily_HunterMark))
                {
                    var deBuff = spec.Target.GameEffectComponent.GetGameEffectSpecByAssetId(_cfg.hunterMarkIdRef.assetId);
                    if (deBuff is { StackCount: > 0 }) 
                    {
                        var mult = _cfg.hunterDmgMult.LvUpValue(owner);
                        return e.originalDamage * (1 + mult * deBuff.StackCount);
                    }
                }
            }
            return e.originalDamage;
        }
    }
}