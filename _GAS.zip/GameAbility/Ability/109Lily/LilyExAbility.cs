using System;
using cfg.gas;
using cfg.hero;
using MemoryPack;
using Meow.Runtime.AOT;
using Meow.Runtime.HotUpdate.BattleConfig;
using Sirenix.OdinInspector;

namespace Meow.Runtime.HotUpdate
{
    [Serializable]
    [MemoryPackable]
    public partial class LilyExAbility : GameAbility
    {
        [Title("额外增加属性")]
        public GameEffectObjectField attrBuff;

        [Title("对标记目标异常积蓄增加")]
        public GameEffectAssetIdRef hunterBuffIdRef;

        public GasParam accrueMult;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new LilyExAbilitySpec(this, owner);
        }
    }

    public class LilyExAbilitySpec : GameAbilitySpec
    {
        private LilyExAbility _cfg;
        private EventGroup _eventGroup = new();
        private ulong _buffId;

        public LilyExAbilitySpec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
            _cfg = (LilyExAbility)ability;
        }

        protected override void OnActive()
        {
            _buffId = owner.ApplyGameEffectTo(_cfg.attrBuff, owner);
            AbnormalAccruePipeline.Instance.OnPreProcessAbnormalAccrue += InstanceOnOnPreProcessAbnormalAccrue;
        }

        private float InstanceOnOnPreProcessAbnormalAccrue(GameEffectSpec spec, Element e, float add)
        {
            if (spec.Source == owner &&
                e == Element.Void)
            {
                if (spec.Target.GameTagComponent.HasTag(EGameTag.State_DeBuff_Lily_HunterMark))
                {
                    var buff = spec.Target.GameEffectComponent.GetGameEffectSpecByAssetId(_cfg.hunterBuffIdRef.assetId);
                    if (buff != null)
                    {
                        if (buff.StackCount >= 3)
                        {
                            return add * (1 + _cfg.accrueMult.Param2);
                        }
                        return add * (1 + _cfg.accrueMult.Param1);
                    }
                }
            }
            return add;
        }

        protected override void OnDeActive()
        {
            AbnormalAccruePipeline.Instance.OnPreProcessAbnormalAccrue -= InstanceOnOnPreProcessAbnormalAccrue;
            if (_buffId != 0)
            {
                owner.GameEffectComponent.RemoveGameEffectSpecById(_buffId);
            }
            _buffId = 0;
        }
    }
}