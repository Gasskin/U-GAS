using System;
using cfg.gas;
using MemoryPack;
using Meow.Runtime.AOT;
using Meow.Runtime.HotUpdate.BattleConfig;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 普通攻击3
    /// 为目标添加猎人印记，最高y层，只能有一个目标，切换时清空
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class LilyAttack3 : GameAbility
    {
        public SkillConfigIdRef attack3IdRef;
        public GameEffectObjectField hunterMark;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new LilyAttack3Spec(this, owner);
        }
    }

    public class LilyAttack3Spec : GameAbilitySpec
    {
        private LilyAttack3 _cfg;

        private EventGroup _eventGroup;

        // 上一次的猎人印记目标
        private uint _prevHunterMark;

        private PlayerTargetService _targetService;


        public LilyAttack3Spec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
            _cfg = (LilyAttack3)ability;
            _eventGroup = new();
            _targetService = World.Current.GetSystem<PlayerTargetService>();
        }

        protected override void OnActive()
        {
            _eventGroup.AddListener<SkillStageTrigger>(OnSkillStageTrigger);
        }

        protected override void OnDeActive()
        {
            _eventGroup.RemoveAllListener();
            TryRemoveHunterMark(_prevHunterMark);
            _prevHunterMark = 0;
        }

        private void OnSkillStageTrigger(IEventMessage ie)
        {
            if (ie is not SkillStageTrigger e)
            {
                return;
            }
            if (e.casterId != owner.Entity || e.stage != ESkillStage.PostHit || e.targets.Count <= 0)
            {
                return;
            }
            if (e.skillTid != _cfg.attack3IdRef.configId)
            {
                return;
            }
            // 猎人标记
            if (e.targets.Count == 1)
            {
                if (e.targets[0].target != _prevHunterMark)
                {
                    TryRemoveHunterMark(_prevHunterMark);
                }
                TryAddHunterMark(e.targets[0].target);
            }
            else
            {
                var lockTarget = _targetService.LockTarget;
                if (lockTarget <= 0)
                {
                    return;
                }
                for (int i = 0; i < e.targets.Count; i++)
                {
                    var t = e.targets[i].target;
                    if (t == lockTarget)
                    {
                        if (t != _prevHunterMark)
                        {
                            TryRemoveHunterMark(_prevHunterMark);
                        }
                        TryAddHunterMark(t);
                        break;
                    }
                }
            }
        }


        private void TryRemoveHunterMark(uint target)
        {
            if (World.Current.HasEntity(target)
                && World.Current.TryGetEntityComp(_prevHunterMark, out GameAbilitySystem gas))
            {
                gas.GameEffectComponent.RemoveGameEffectSpecByAssetId(_cfg.hunterMark.effect.assetId);
            }
        }

        private void TryAddHunterMark(uint target)
        {
            if (World.Current.HasEntity(target)
                && World.Current.TryGetEntityComp(target, out GameAbilitySystem gas))
            {
                owner.ApplyGameEffectTo(_cfg.hunterMark, gas);
                _prevHunterMark = target;
            }
        }
    }
}