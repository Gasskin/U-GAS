using System;
using MemoryPack;
using Meow.Runtime.AOT;
using Meow.Runtime.HotUpdate.BattleConfig;
using Sirenix.OdinInspector;

namespace Meow.Runtime.HotUpdate
{
    [Serializable]
    [MemoryPackable]
    public partial class LilyUltimate : GameAbility
    {
        // 奥义添加通灵buff
        public SkillConfigIdRef ultimate;
        public GameEffectObjectField ultimateCritRateBuff;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new LilyUltimateSpec(this, owner);
        }
    }

    public class LilyUltimateSpec : GameAbilitySpec
    {
        private LilyUltimate _cfg;
        private EventGroup _eventGroup = new();

        public LilyUltimateSpec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
            _cfg = (LilyUltimate)ability;
        }

        protected override void OnActive()
        {
            _eventGroup.AddListener<SkillStageTrigger>(OnSkillStageTrigger);
        }
        
        protected override void OnDeActive()
        {
            _eventGroup.RemoveAllListener();
        }
        
        private void OnSkillStageTrigger(IEventMessage ie)
        {
            if (ie is not SkillStageTrigger e)
            {
                return;
            }
            
            Ultimate();
            return;

            // 奥义添加通灵BUFF
            void Ultimate()
            {
                if (!e.Is(owner.Entity, ESkillStage.Start, _cfg.ultimate.configId))
                {
                    return;
                }
                owner.ApplyGameEffectTo(_cfg.ultimateCritRateBuff, owner);
            }
        }
    }
}