using System;
using MemoryPack;

namespace Meow.Runtime.HotUpdate
{
    [Serializable]
    [MemoryPackable]
    public partial class NvZhuHeroStar6 : GameAbility
    {
        public GameEffectObjectField addHarm;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new NvZhuHeroStar6Spec(this, owner);
        }
        
        public override bool CanAdd(GameAbilitySystem owner)
        {
            return owner.GameTagComponent.HasTag(EGameTag.State_HeroStar6);
        }
    }

    public class NvZhuHeroStar6Spec : GameAbilitySpec
    {
        private NvZhuHeroStar6 _ability;

        public NvZhuHeroStar6Spec(NvZhuHeroStar6 ability, GameAbilitySystem o) : base(ability, o)
        {
            _ability = ability;
        }

        protected override void OnActive()
        {
            DamagePipeline.Instance.OnPostProcessDamage += OnPostProcessDamage;
        }

        protected override void OnDeActive()
        {
            DamagePipeline.Instance.OnPostProcessDamage -= OnPostProcessDamage;
        }

        private void OnPostProcessDamage(GameEffectSpec spec, CommonSkillDamageEvent e)
        {
            if (spec.Source != owner)
            {
                return;
            }
            if (spec.GameEffect.AssetTagsContainer.HasTag(EGameTag.Skill_NvZhu_SuperAttack))
            {
                owner.ApplyGameEffectTo(_ability.addHarm, owner);
            }
        }
    }
}