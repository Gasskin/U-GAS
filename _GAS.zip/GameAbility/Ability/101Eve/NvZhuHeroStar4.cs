using System;
using cfg.attribute;
using MemoryPack;
using Sirenix.OdinInspector;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 每消耗1个能量1提升x%的攻击力，持续x秒，最多叠加x层
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class NvZhuHeroStar4 : GameAbility
    {
        [LabelText("攻击力提升")]
        public GameEffectObjectField buff;
        
        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new NvZhuHeroStar4Spec(this, owner);
        }

        public override bool CanAdd(GameAbilitySystem owner)
        {
            return owner.GameTagComponent.HasTag(EGameTag.State_HeroStar4);
        }
    }

    public class NvZhuHeroStar4Spec : GameAbilitySpec
    {
        public NvZhuHeroStar4Spec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
        }

        protected override void OnActive()
        {
            owner.GameAttributeComponent.GetAttribute(AttributeId.PersonalEnergy).OnPostCurrentValueChange += Energy1_OnPostCurrentValueChange;
        }


        protected override void OnDeActive()
        {
            owner.GameAttributeComponent.GetAttribute(AttributeId.PersonalEnergy).OnPostCurrentValueChange -= Energy1_OnPostCurrentValueChange;
        }

        private void Energy1_OnPostCurrentValueChange(float oldV, float newV)
        {
            if (ability is not NvZhuHeroStar4 cfg)
            {
                return;
            }
            var reduce = (int)(oldV - newV);
            if (reduce > 0)
            {
                while (reduce-- > 0)
                {
                    owner.ApplyGameEffectTo(cfg.buff, owner);
                }
            }
        }
    }
}