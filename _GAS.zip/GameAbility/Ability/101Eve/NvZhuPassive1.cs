using System;
using cfg.hero;
using MemoryPack;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 队伍中所有成员施加异常状态时，攻击力提高x%，持续x秒，至多叠加2次
    /// </summary>
    [MemoryPackable]
    [Serializable]
    public partial class NvZhuPassive1 : GameAbility
    {
        public GameEffectObjectField buff;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new NvZhuPassive1Spec(this, owner);
        }
    }

    public class NvZhuPassive1Spec : GameAbilitySpec
    {
        public NvZhuPassive1Spec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
        }

        protected override void OnAdd()
        {
            AbnormalAccruePipeline.Instance.OnPostTriggerAbnormal += OnPostTriggerAbnormal;
        }

        protected override void OnRemove()
        {
            AbnormalAccruePipeline.Instance.OnPostTriggerAbnormal -= OnPostTriggerAbnormal;
        }

        protected override void OnActive()
        {
        }

        protected override void OnDeActive()
        {
        }

        protected override void OnTick(float dt)
        {
        }
        
        private void OnPostTriggerAbnormal(GameEffectSpec spec, Element e)
        {
            if (ability is not NvZhuPassive1 cfg)
            {
                return;
            }
            spec.Source.ApplyGameEffectTo(cfg.buff, spec.Source);
        }
    }
}