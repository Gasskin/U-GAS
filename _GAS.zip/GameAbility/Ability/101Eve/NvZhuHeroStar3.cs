using System;
using MemoryPack;

namespace Meow.Runtime.HotUpdate
{
    [Serializable]
    [MemoryPackable]
    public partial class NvZhuHeroStar3 : GameAbility
    {
        public GameEffectObjectField addEnergy;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new NvZhuHeroStar3Spec(this, owner);
        }
        
        public override bool CanAdd(GameAbilitySystem owner)
        {
            return owner.GameTagComponent.HasTag(EGameTag.State_HeroStar3);
        }
    }

    public class NvZhuHeroStar3Spec : GameAbilitySpec
    {
        private NvZhuHeroStar3 _ability;

        public NvZhuHeroStar3Spec(NvZhuHeroStar3 ability, GameAbilitySystem o) : base(ability, o)
        {
            _ability = ability;
        }

        protected override void OnActive()
        {
            ToughnessPipeline.Instance.OnToughnessBreak += OnToughnessBreak;

        }

        protected override void OnDeActive()
        {
            ToughnessPipeline.Instance.OnToughnessBreak -= OnToughnessBreak;
        }

        private void OnToughnessBreak(GameEffectSpec spec, ToughnessReduceEvent e)
        {
            if (spec.Source == owner)
            {
                owner.ApplyGameEffectTo(_ability.addEnergy, owner);
            }
        }
    }
}