﻿using System;
using cfg.gas;
using MemoryPack;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 命座1
    /// 强化普攻的伤害增加x%
    /// 强化普攻3命中后恢复x%的生命值，x秒内最多生效1次
    /// </summary>
    /// 
    [Serializable]
    [MemoryPackable]
    public partial class NvZhuHeroStar1 : GameAbility
    {
        public int gasValueId;
        public GameEffectObjectField hpRecover;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new NvZhuHeroStar1Spec(this, owner);
        }

        public override bool CanAdd(GameAbilitySystem owner)
        {
            return owner.GameTagComponent.HasTag(EGameTag.State_HeroStar1);
        }
    }

    public class NvZhuHeroStar1Spec : GameAbilitySpec
    {
        private NvZhuHeroStar1 _ability;
        private float _lastTime;

        public NvZhuHeroStar1Spec(NvZhuHeroStar1 a, GameAbilitySystem o) : base(a, o)
        {
            _ability = a;
        }

        protected override void OnActive()
        {
            DamagePipeline.Instance.OnPreProcessDamage += OnPreProcessDamage;
            DamagePipeline.Instance.OnPostProcessDamage += OnPostProcessDamage;
        }

        protected override void OnDeActive()
        {
            DamagePipeline.Instance.OnPreProcessDamage -= OnPreProcessDamage;
            DamagePipeline.Instance.OnPostProcessDamage -= OnPostProcessDamage;
        }

        private float OnPreProcessDamage(GameEffectSpec spec, CommonSkillDamageEvent e)
        {
            if (spec.Source == owner)
            {
                if (spec.GameEffect.AssetTagsContainer.HasTag(EGameTag.Skill_NvZhu_SuperAttack))
                {
                    return e.originalDamage * (1f + GasValue.GetParam(_ability.gasValueId, 1));
                }
            }
            return e.originalDamage;
        }

        private void OnPostProcessDamage(GameEffectSpec spec, CommonSkillDamageEvent e)
        {
            if (spec.Source != owner)
            {
                return;
            }
            if (_ability.hpRecover == null)
            {
                return;
            }

            if (spec.GameEffect.AssetTagsContainer.HasTag(EGameTag.Skill_NvZhu_SuperAttack_Attack3))
            {
                var now = Time.time;
                if (now - _lastTime >= GasValue.GetParam(_ability.gasValueId, 3))
                {
                    _lastTime = now;
                    owner.ApplyGameEffectTo(_ability.hpRecover, owner);
                }
            }
        }
    }
}