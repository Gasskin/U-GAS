using System;
using System.Collections.Generic;
using cfg.attribute;
using cfg.hero;
using MemoryPack;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 时间异常状态触发入口
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class AbnormalTime : GameAbility
    {
        public GameEffect damage;
        public GameEffect buff;
        
        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new AbnormalTimeSpec(this, owner);
        }
    }

    public class AbnormalTimeSpec : GameAbilitySpec
    {
        private AbnormalTime _cfg;

        private uint _virtualEntId;
        private GameAbilitySystem _virtualGas;

        public AbnormalTimeSpec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
            _cfg = ability as AbnormalTime;
        }
        
        protected override void OnActive()
        {
            var ent = World.Current.CreateEntity();
            _virtualEntId = ent.Entity;
            _virtualGas = new GameAbilitySystem(0, null);
            ent.AddComp(_virtualGas);
            ent.AddComp(new FeatureComp());
            ent.Start();
            AbnormalAccruePipeline.Instance.OnTriggerAbnormal += OnTriggerAbnormal;
        }

        protected override void OnDeActive()
        {
            World.Current.DestroyEntity(_virtualEntId);
            AbnormalAccruePipeline.Instance.OnTriggerAbnormal -= OnTriggerAbnormal;
        }

        protected override void OnTick(float dt)
        {
        }

        private void OnTriggerAbnormal(GameEffectSpec spec, Element e)
        {
            if (e != Element.Time)
            {
                return;
            }
            if (spec.Target != owner)
            {
                return;
            }
            if (!World.Current.TryGetEntityComp(spec.Target.Entity, out AbnormalAccrueStatisticComp aap))
            {
                return;
            }
            // 异常紊乱

            // 属性切片
            aap.CaptureAttr(e, _virtualEntId);
            _virtualGas.ApplyGameEffectTo(_cfg.damage, spec.Target);
            _virtualGas.ApplyGameEffectTo(_cfg.buff, spec.Target);
        }
    }
}