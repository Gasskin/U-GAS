using cfg.hero;
using MemoryPack;
using Meow.Runtime.AOT;
using Sirenix.OdinInspector;
using System;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// Nina 命座1
    /// </summary>
    [MemoryPackable]
    [Serializable]
    public partial class NinaStar1 : GameAbility
    {
        [LabelText("普通系添加的buff")]
        public GameEffectObjectField normalBuff;

        [LabelText("空间系添加的buff")]
        public GameEffectObjectField spaceBuff;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new NinaStar1Spec(this, owner);
        }

        public override bool CanAdd(GameAbilitySystem owner)
        {
            return owner.GameTagComponent.HasTag(EGameTag.State_HeroStar1);
        }
    }

    public class NinaStar1Spec : GameAbilitySpec
    {
        private NinaStar1 _ninaStar1Config;

        public NinaStar1Spec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
            _ninaStar1Config = ability as NinaStar1;
        }

        protected override void OnAdd()
        {

            GameEffectPipeline.Instance.OnPreAddGameEffect += OnPreAddGameEffect;
        }

        private bool OnPreAddGameEffect(GameEffectSpec spec)
        {
            if (spec.GameEffect.AssetTagsContainer.HasTag(EGameTag.Effect_Buff) && spec.GameEffect.AssetTagsContainer.HasTag(EGameTag.State_Buff_Nina_NinaBlessing))
            {
                if(World.Current.TryGetEntityComp<HeroUnitComp>(spec.Target.Entity, out var hero))
                {
                    var heroCfg = TbHero.Instance.GetOrDefault(hero.HeroTid);
                    if(heroCfg.Element == Element.Space)
                    {
                        spec.Source.ApplyGameEffectTo(_ninaStar1Config.spaceBuff, spec.Target);
                    }
                    else
                    {
                        spec.Source.ApplyGameEffectTo(_ninaStar1Config.normalBuff, spec.Target);
                    }
                }
            }
            return true;
        }

        protected override void OnRemove()
        {
            GameEffectPipeline.Instance.OnPreAddGameEffect -= OnPreAddGameEffect;
        }

    }
}