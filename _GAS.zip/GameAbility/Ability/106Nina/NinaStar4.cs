using MemoryPack;
using Meow.Runtime.AOT;
using Sirenix.OdinInspector;
using System;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// Nina 被动，怪物在领域内受到伤害时给她回能
    /// </summary>
    [MemoryPackable]
    [Serializable]
    public partial class NinaStar4 : GameAbility
    {
        [LabelText("恢复队友能量buff")]
        public GameEffectObjectField oterRecoverbuff;

        [LabelText("恢复自身能量buff")]
        public GameEffectObjectField ninaRecoverbuff;

        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new NinaStar4Spec(this, owner);
        }

        public override bool CanAdd(GameAbilitySystem owner)
        {
            return owner.GameTagComponent.HasTag(EGameTag.State_HeroStar4);
        }
    }

    public class NinaStar4Spec : GameAbilitySpec
    {
        private NinaStar4 _ninaStar4Cfg;

        public NinaStar4Spec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
            _ninaStar4Cfg = ability as NinaStar4;
        }

        protected override void OnAdd()
        {
            DamagePipeline.Instance.OnPostProcessDie += OnEntityDie;
        }

        protected override void OnRemove()
        {
            DamagePipeline.Instance.OnPostProcessDie -= OnEntityDie;
        }

        private void OnEntityDie(GameEffectSpec spec, CommonSkillDamageEvent e)
        {
            if (spec.Target.GameTagComponent.HasTag(EGameTag.State_Buff_Nina_NinaBlessing))
            {
                if (spec.Source.Entity == owner.Entity)
                {
                    owner.ApplyGameEffectTo(_ninaStar4Cfg.ninaRecoverbuff, owner);
                }
                else
                {
                    owner.ApplyGameEffectTo(_ninaStar4Cfg.oterRecoverbuff, spec.Source);
                }
            }           
        }
    }
}