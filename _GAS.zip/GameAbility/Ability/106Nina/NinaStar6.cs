using MemoryPack;
using Meow.Runtime.AOT;
using Sirenix.OdinInspector;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// Nina 被动，怪物在领域内受到伤害时给她回能
    /// </summary>
    [MemoryPackable]
    [Serializable]
    public partial class NinaStar6 : GameAbility
    {
        [LabelText("召唤物销毁时间替换")]
        public float summonDestroyTime;
        [LabelText("要替换的召唤物Tid")]
        public List<int> summonTids;


        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new NinaStar6Spec(this, owner);
        }

        public override bool CanAdd(GameAbilitySystem owner)
        {
            return owner.GameTagComponent.HasTag(EGameTag.State_HeroStar6);
        }
    }

    public class NinaStar6Spec : GameAbilitySpec
    {
        private EventGroup _eventGroup = new();
        private NinaStar6 _ninaStar6Cfg;

        public NinaStar6Spec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
            _ninaStar6Cfg = ability as NinaStar6;
        }

        protected override void OnAdd()
        {
            _eventGroup.AddListener<OnAddSummonEvent>(OnAddSummon);

        }

        protected override void OnRemove()
        {
            _eventGroup.RemoveAllListener();
        }

        private void OnAddSummon(IEventMessage message)
        {
            if (message is OnAddSummonEvent e && World.Current.TryGetEntityComp<SummonComp>(e.summonEntityId, out var summonComp))
            {
                if (_ninaStar6Cfg.summonTids.Contains(summonComp.SummonTid))
                {
                    summonComp.ReAddLifeTimer(_ninaStar6Cfg.summonDestroyTime);
                }
            }
        }

    }
}
