using MemoryPack;
using Meow.Runtime.AOT;
using System;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// Nina 被动，怪物在领域内受到伤害时给她回能
    /// </summary>
    [MemoryPackable]
    [Serializable]
    public partial class NinaPassive1 : GameAbility
    {
        public float buffInternalTime;
        public GameEffectObjectField buff;


        public override GameAbilitySpec CreateSpec(GameAbilitySystem owner)
        {
            return new NinaPassive1Spec(this, owner);
        }
    }

    public class NinaPassive1Spec : GameAbilitySpec
    {
        private ulong _buffId;
        private EventGroup _eventGroup = new();
        private NinaPassive1 _ninaPassiveConfig;
        private float _lastAddbuffTime = 0;

        public NinaPassive1Spec(GameAbility ability, GameAbilitySystem o) : base(ability, o)
        {
            _ninaPassiveConfig = ability as NinaPassive1;
        }

        protected override void OnAdd()
        {
            _eventGroup.AddListener<RefreshHpAttributeEvent>(OnHpRefresh);
            
        }

        protected override void OnRemove()
        {
            _eventGroup.RemoveAllListener();
        }

        private void OnHpRefresh(IEventMessage message)
        {
            if(InGameDomain.TimeService.UpdateUpdater.ElapsedTime - _lastAddbuffTime < _ninaPassiveConfig.buffInternalTime)
            {
                return;
            }
            if (message is RefreshHpAttributeEvent e && World.Current.TryGetEntityComp<MonsterUnitComp>(e.entityId, out var monsterComp))
            {
                if (World.Current.TryGetEntityComp<GameAbilitySystem>(e.entityId, out var gas))
                {
                    if(gas.GameTagComponent.HasTag(EGameTag.State_Buff_Nina_NinaBlessing))
                    {
                        owner.ApplyGameEffectTo(_ninaPassiveConfig.buff, owner);
                    }
                }
            }
        }

    }
}
