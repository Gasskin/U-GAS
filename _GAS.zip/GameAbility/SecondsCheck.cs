namespace Meow.Runtime.HotUpdate
{
    public class SecondsCheck
    {
        private float _seconds;
        private float _now;

        public SecondsCheck(float seconds)
        {
            _seconds = seconds;
            _now = seconds;
        }

        public bool Tick(float dt)
        {
            _now -= dt;
            if (_now <= 0)
            {
                _now += _seconds;
                return true;
            }
            return false;
        }

        public void Reset()
        {
            _now = _seconds;
        }
    }
}