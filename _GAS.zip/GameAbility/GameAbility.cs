﻿using System;
using MemoryPack;

namespace Meow.Runtime.HotUpdate
{
    [Serializable]
    [MemoryPackable]
    // ------ 通用 ------
    [MemoryPackUnion(1, typeof(ToughnessBreakStateAbility))]
    [MemoryPackUnion(2, typeof(BreakBladeAbility))]
    [MemoryPackUnion(3, typeof(HeroStarAddSkillLevel))]
    [MemoryPackUnion(4, typeof(PersonalEnergyAutoRecovery))]
    [MemoryPackUnion(5, typeof(PowerAutoRecovery))]
    [MemoryPackUnion(6, typeof(AfterDeath))]
    [MemoryPackUnion(7, typeof(BeforeDeathRecovery))]
    // ------ 异常状态 ------
    [MemoryPackUnion(101, typeof(AbnormalTime))]
    // ------ 101女主 ------
    [MemoryPackUnion(10102, typeof(NvZhuHeroStar1))]
    [MemoryPackUnion(10103, typeof(NvZhuHeroStar3))]
    [MemoryPackUnion(10104, typeof(NvZhuHeroStar6))]
    [MemoryPackUnion(10105, typeof(NvZhuPassive2))]
    [MemoryPackUnion(10106, typeof(NvZhuPassive1))]
    [MemoryPackUnion(10107, typeof(NvZhuHeroStar4))]
    // ------ 103菊 ------
    [MemoryPackUnion(10301, typeof(JuPassive1))]
    [MemoryPackUnion(10302, typeof(JuStar1))]
    [MemoryPackUnion(10303, typeof(JuStar4))]
    [MemoryPackUnion(10304, typeof(JuStar6))]
    [MemoryPackUnion(10305, typeof(JuPassive2))]
    // ------ 110格露丝 ------
    [MemoryPackUnion(11001, typeof(GhrothEnergyControl))]
    [MemoryPackUnion(11002, typeof(GhrothAttack))]
    [MemoryPackUnion(11003, typeof(GhrothPassive2))]
    [MemoryPackUnion(11004, typeof(GhrothStar1))]
    [MemoryPackUnion(11005, typeof(GhrothStar3))]
    [MemoryPackUnion(11006, typeof(GhrothStar6))]
    [MemoryPackUnion(11007, typeof(GhrothPassive1))]
    // ------ 114光辉 ------
    [MemoryPackUnion(11401, typeof(LuxcisUltimate))]
    [MemoryPackUnion(11402, typeof(LuxcisPassive1))]
    [MemoryPackUnion(11403, typeof(LuxcisPassive2))]
    // ------ 莉亚娜 ------
    [MemoryPackUnion(21201, typeof(LyanaPersonalEnergy1))]
    [MemoryPackUnion(21202, typeof(LyanaTeamPersonalEnergy1))]
    [MemoryPackUnion(21203, typeof(LyanaSpecial))]
    [MemoryPackUnion(21204, typeof(LyanaHeroStart1))]
    [MemoryPackUnion(21205, typeof(LyanaHeroStart3))]
    [MemoryPackUnion(21206, typeof(LyanaHeroStart4))]
    [MemoryPackUnion(21207, typeof(LyanaHeroStart6))]
    [MemoryPackUnion(21208, typeof(LyanaPassive1))]
    [MemoryPackUnion(21209, typeof(LyanaPassive2))]
    // ------ 105希娅 ------
    [MemoryPackUnion(10501, typeof(SiaUltimateSkill))]
    [MemoryPackUnion(10502, typeof(SiaPassive1))]
    [MemoryPackUnion(10503, typeof(SiaPassive2))]
    [MemoryPackUnion(10504, typeof(SiaHeroStar4))]
    [MemoryPackUnion(10505, typeof(SiaRecoverEnergy))]
    [MemoryPackUnion(10506, typeof(SiaShowVFX))]
    // ------ 106Nina ------
    [MemoryPackUnion(10601, typeof(NinaPassive1))]
    [MemoryPackUnion(10602, typeof(NinaStar1))]
    [MemoryPackUnion(10603, typeof(NinaStar4))]
    [MemoryPackUnion(10604, typeof(NinaStar6))]
    // ------ 109Lily ------
    [MemoryPackUnion(10901, typeof(LilyAttack3))]
    [MemoryPackUnion(10903, typeof(LilyMinion))]
    [MemoryPackUnion(10904, typeof(LilyHunterDamage))]
    [MemoryPackUnion(10905, typeof(LilyUltimate))]
    public abstract partial class GameAbility
    {
        public abstract GameAbilitySpec CreateSpec(GameAbilitySystem owner);

        public virtual bool CanAdd(GameAbilitySystem owner)
        {
            return true;
        }
    }

    public abstract class GameAbilitySpec
    {
        public int Id { get; private set; }

        // 只有通过GE添加的技能才有这个属性
        protected GameEffectSpec FromGameEffect { get; private set; }

        protected GameAbilitySystem owner;
        protected GameAbility ability;

        protected bool IsActive { get; private set; }

        public void Add(int id, GameEffectSpec fromGameEffect)
        {
            Id = id;
            FromGameEffect = fromGameEffect;
            OnAdd();
        }

        public void Remove()
        {
            FromGameEffect = null;
            OnRemove();
        }

        public void Active()
        {
            if (!IsActive)
            {
                IsActive = true;
                OnActive();
            }
        }

        public void DeActive()
        {
            if (IsActive)
            {
                IsActive = false;
                OnDeActive();
            }
        }

        public void Tick(float dt)
        {
            OnTick(dt);
        }

        protected virtual void OnAdd()
        {
        }

        protected virtual void OnRemove()
        {
        }

        // 技能激活时
        protected virtual void OnActive()
        {
        }

        // 技能失活时
        protected virtual void OnDeActive()
        {
        }

        // 激活中 每帧调用
        protected virtual void OnTick(float dt)
        {
        }

        protected GameAbilitySpec(GameAbility ability, GameAbilitySystem o)
        {
            this.ability = ability;
            owner = o;
        }

        // public virtual bool CheckCost(IEnumerable<GameEffectObjectField> costs)
        // {
        //     return owner.GameAbilityComponent.CheckCosts(costs);
        // }
        //
        // public virtual void ApplyCost(SkillConfig config, IEnumerable<GameEffectObjectField> costs)
        // {
        //     foreach (var cost in costs)
        //     {
        //         owner.ApplyGameEffectTo(cost, owner);
        //     }
        // }
    }
}