using System;
using System.Collections.Generic;
using MemoryPack;
using Meow.Runtime.HotUpdate.BattleConfig.skill;

namespace Meow.Runtime.HotUpdate
{
    [MemoryPackUnion(1, typeof(ForwardSprint))]
    [MemoryPackUnion(2, typeof(NvZhuSuperAttack))]
    [MemoryPackUnion(3, typeof(JuStar3))]
    [MemoryPackUnion(4, typeof(LuxcisSSpecialLoop))]
    // 109 Lily
    // [MemoryPackUnion(10901, typeof(LilySpecialSkill))]
    // [MemoryPackUnion(10902, typeof(LilySSpecialSkill))]
    [Serializable]
    [MemoryPackable]
    public abstract partial class SkillAbility
    {
        public virtual bool CheckCost(GameAbilitySystem owner, IEnumerable<GameEffectObjectField> costs)
        {
            return owner.GameAbilityComponent.CheckCosts(costs);
        }

        public virtual void ApplyCost(GameAbilitySystem owner, SkillConfig config, IEnumerable<GameEffectObjectField> costs)
        {
            foreach (var cost in costs)
            {
                owner.ApplyGameEffectTo(cost, owner);
            }
        }
    }
}