using System;
using System.Collections.Generic;
namespace Meow.Runtime.HotUpdate
{
	public static class TagRegister
	{
		public static readonly int Size = 74;
		public static readonly int[] Tree =
		{
			0,	// 0 Null
			0,	// 1 Combo
			1,	// 2 Combo_NA_2
			1,	// 3 Combo_NA_3
			1,	// 4 Combo_NA_4
			1,	// 5 Combo_NA_5
			1,	// 6 Combo_SA_2
			1,	// 7 Combo_SA_3
			1,	// 8 Combo_SS_1
			1,	// 9 Combo_S_1
			0,	// 10 Effect
			10,	// 11 Effect_Buff
			10,	// 12 Effect_Cost
			10,	// 13 Effect_Damage
			13,	// 14 Effect_Damage_Extend
			10,	// 15 Effect_DeBuff
			10,	// 16 Effect_Recover
			0,	// 17 PreInput
			0,	// 18 Skill
			18,	// 19 Skill_Ghroth
			19,	// 20 Skill_Ghroth_Attack
			18,	// 21 Skill_Luxcis
			21,	// 22 Skill_Luxcis_Attack
			21,	// 23 Skill_Luxcis_UltimateFire
			18,	// 24 Skill_Lyana
			24,	// 25 Skill_Lyana_Special
			18,	// 26 Skill_NvZhu
			26,	// 27 Skill_NvZhu_Attack
			26,	// 28 Skill_NvZhu_SuperAttack
			28,	// 29 Skill_NvZhu_SuperAttack_Attack3
			0,	// 30 Startup
			0,	// 31 State
			31,	// 32 State_Buff
			32,	// 33 State_Buff_Armor
			32,	// 34 State_Buff_Eve
			34,	// 35 State_Buff_Eve_Ultimate
			32,	// 36 State_Buff_Invincible
			32,	// 37 State_Buff_Ju
			37,	// 38 State_Buff_Ju_Special
			37,	// 39 State_Buff_Ju_SpecialMagicalBlessing
			32,	// 40 State_Buff_Luxcis
			40,	// 41 State_Buff_Luxcis_Ultimate
			32,	// 42 State_Buff_Nina
			42,	// 43 State_Buff_Nina_NinaBlessing
			42,	// 44 State_Buff_Nina_NinaClearBlessing
			42,	// 45 State_Buff_Nina_NinaStar1Blessing
			42,	// 46 State_Buff_Nina_NinaUltimateBlessing
			32,	// 47 State_Buff_Sia
			47,	// 48 State_Buff_Sia_Bread
			47,	// 49 State_Buff_Sia_Jelly
			47,	// 50 State_Buff_Sia_RedTea
			47,	// 51 State_Buff_Sia_SpecialDef
			47,	// 52 State_Buff_Sia_Ultimate
			31,	// 53 State_DeBuff
			53,	// 54 State_DeBuff_Abnormal
			54,	// 55 State_DeBuff_Abnormal_Create
			54,	// 56 State_DeBuff_Abnormal_Dart
			54,	// 57 State_DeBuff_Abnormal_Energy
			54,	// 58 State_DeBuff_Abnormal_Light
			54,	// 59 State_DeBuff_Abnormal_Space
			54,	// 60 State_DeBuff_Abnormal_Time
			54,	// 61 State_DeBuff_Abnormal_Void
			53,	// 62 State_DeBuff_BreakTough
			53,	// 63 State_DeBuff_Lily
			63,	// 64 State_DeBuff_Lily_HunterMark
			53,	// 65 State_DeBuff_Lyana
			65,	// 66 State_DeBuff_Lyana_DeathMark
			31,	// 67 State_Die
			31,	// 68 State_HeroStar1
			31,	// 69 State_HeroStar2
			31,	// 70 State_HeroStar3
			31,	// 71 State_HeroStar4
			31,	// 72 State_HeroStar5
			31,	// 73 State_HeroStar6
		};
		public static readonly Dictionary<string, EGameTag> StringToEnum = new()
		{
			{ "Combo", EGameTag.Combo },
			{ "Effect", EGameTag.Effect },
			{ "PreInput", EGameTag.PreInput },
			{ "Skill", EGameTag.Skill },
			{ "Startup", EGameTag.Startup },
			{ "State", EGameTag.State },
			{ "Combo_NA_2", EGameTag.Combo_NA_2 },
			{ "Combo_NA_3", EGameTag.Combo_NA_3 },
			{ "Combo_NA_4", EGameTag.Combo_NA_4 },
			{ "Combo_NA_5", EGameTag.Combo_NA_5 },
			{ "Combo_SA_2", EGameTag.Combo_SA_2 },
			{ "Combo_SA_3", EGameTag.Combo_SA_3 },
			{ "Combo_SS_1", EGameTag.Combo_SS_1 },
			{ "Combo_S_1", EGameTag.Combo_S_1 },
			{ "Effect_Buff", EGameTag.Effect_Buff },
			{ "Effect_Cost", EGameTag.Effect_Cost },
			{ "Effect_Damage", EGameTag.Effect_Damage },
			{ "Effect_DeBuff", EGameTag.Effect_DeBuff },
			{ "Effect_Recover", EGameTag.Effect_Recover },
			{ "Skill_Ghroth", EGameTag.Skill_Ghroth },
			{ "Skill_Luxcis", EGameTag.Skill_Luxcis },
			{ "Skill_Lyana", EGameTag.Skill_Lyana },
			{ "Skill_NvZhu", EGameTag.Skill_NvZhu },
			{ "State_Buff", EGameTag.State_Buff },
			{ "State_DeBuff", EGameTag.State_DeBuff },
			{ "State_Die", EGameTag.State_Die },
			{ "State_HeroStar1", EGameTag.State_HeroStar1 },
			{ "State_HeroStar2", EGameTag.State_HeroStar2 },
			{ "State_HeroStar3", EGameTag.State_HeroStar3 },
			{ "State_HeroStar4", EGameTag.State_HeroStar4 },
			{ "State_HeroStar5", EGameTag.State_HeroStar5 },
			{ "State_HeroStar6", EGameTag.State_HeroStar6 },
			{ "Effect_Damage_Extend", EGameTag.Effect_Damage_Extend },
			{ "Skill_Ghroth_Attack", EGameTag.Skill_Ghroth_Attack },
			{ "Skill_Luxcis_Attack", EGameTag.Skill_Luxcis_Attack },
			{ "Skill_Luxcis_UltimateFire", EGameTag.Skill_Luxcis_UltimateFire },
			{ "Skill_Lyana_Special", EGameTag.Skill_Lyana_Special },
			{ "Skill_NvZhu_Attack", EGameTag.Skill_NvZhu_Attack },
			{ "Skill_NvZhu_SuperAttack", EGameTag.Skill_NvZhu_SuperAttack },
			{ "State_Buff_Armor", EGameTag.State_Buff_Armor },
			{ "State_Buff_Eve", EGameTag.State_Buff_Eve },
			{ "State_Buff_Invincible", EGameTag.State_Buff_Invincible },
			{ "State_Buff_Ju", EGameTag.State_Buff_Ju },
			{ "State_Buff_Luxcis", EGameTag.State_Buff_Luxcis },
			{ "State_Buff_Nina", EGameTag.State_Buff_Nina },
			{ "State_Buff_Sia", EGameTag.State_Buff_Sia },
			{ "State_DeBuff_Abnormal", EGameTag.State_DeBuff_Abnormal },
			{ "State_DeBuff_BreakTough", EGameTag.State_DeBuff_BreakTough },
			{ "State_DeBuff_Lily", EGameTag.State_DeBuff_Lily },
			{ "State_DeBuff_Lyana", EGameTag.State_DeBuff_Lyana },
			{ "Skill_NvZhu_SuperAttack_Attack3", EGameTag.Skill_NvZhu_SuperAttack_Attack3 },
			{ "State_Buff_Eve_Ultimate", EGameTag.State_Buff_Eve_Ultimate },
			{ "State_Buff_Ju_Special", EGameTag.State_Buff_Ju_Special },
			{ "State_Buff_Ju_SpecialMagicalBlessing", EGameTag.State_Buff_Ju_SpecialMagicalBlessing },
			{ "State_Buff_Luxcis_Ultimate", EGameTag.State_Buff_Luxcis_Ultimate },
			{ "State_Buff_Nina_NinaBlessing", EGameTag.State_Buff_Nina_NinaBlessing },
			{ "State_Buff_Nina_NinaClearBlessing", EGameTag.State_Buff_Nina_NinaClearBlessing },
			{ "State_Buff_Nina_NinaStar1Blessing", EGameTag.State_Buff_Nina_NinaStar1Blessing },
			{ "State_Buff_Nina_NinaUltimateBlessing", EGameTag.State_Buff_Nina_NinaUltimateBlessing },
			{ "State_Buff_Sia_Bread", EGameTag.State_Buff_Sia_Bread },
			{ "State_Buff_Sia_Jelly", EGameTag.State_Buff_Sia_Jelly },
			{ "State_Buff_Sia_RedTea", EGameTag.State_Buff_Sia_RedTea },
			{ "State_Buff_Sia_SpecialDef", EGameTag.State_Buff_Sia_SpecialDef },
			{ "State_Buff_Sia_Ultimate", EGameTag.State_Buff_Sia_Ultimate },
			{ "State_DeBuff_Abnormal_Create", EGameTag.State_DeBuff_Abnormal_Create },
			{ "State_DeBuff_Abnormal_Dart", EGameTag.State_DeBuff_Abnormal_Dart },
			{ "State_DeBuff_Abnormal_Energy", EGameTag.State_DeBuff_Abnormal_Energy },
			{ "State_DeBuff_Abnormal_Light", EGameTag.State_DeBuff_Abnormal_Light },
			{ "State_DeBuff_Abnormal_Space", EGameTag.State_DeBuff_Abnormal_Space },
			{ "State_DeBuff_Abnormal_Time", EGameTag.State_DeBuff_Abnormal_Time },
			{ "State_DeBuff_Abnormal_Void", EGameTag.State_DeBuff_Abnormal_Void },
			{ "State_DeBuff_Lily_HunterMark", EGameTag.State_DeBuff_Lily_HunterMark },
			{ "State_DeBuff_Lyana_DeathMark", EGameTag.State_DeBuff_Lyana_DeathMark },
		};

#if UNITY_EDITOR
        static TagRegister()
        {
            if (Tree == null || Tree.Length != Size)
            {
                throw new Exception($"Tree.Length({Tree?.Length}) != Size({Size})");
            }
            for (int i = 0; i < Tree.Length; i++)
            {
                int p = Tree[i];
                if (p < -1 || p >= Size)
                {
                    throw new Exception($"Illegal parent index: {i} -> {p}");
                }
            }

            // 简单环检测
            var seen = new bool[Size];
            for (int i = 0; i < Size; i++)
            {
                Array.Clear(seen, 0, seen.Length);
                int cur = i;
                while (cur > 0)
                {
                    if (seen[cur])
                    {
                        throw new Exception($"Cycle detected at {i} (via {cur})");
                    }
                    seen[cur] = true;
                    cur = Tree[cur];
                }
            }
        }
#endif
	}
}
