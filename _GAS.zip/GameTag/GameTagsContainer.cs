using System;
using System.Collections.Generic;
using Meow.Runtime.AOT;

namespace Meow.Runtime.HotUpdate
{
    public class GameTagsContainer
    {
        private int[] _tags = new int[TagRegister.Size];

        public void InitTags(List<string> tags)
        {
            Array.Clear(_tags, 0, _tags.Length);
            if (tags == null)
            {
                return;
            }
            foreach (var tag in tags)
            {
                var tagIdx = (int)tag.ToGameTag();
                if (tagIdx >= _tags.Length)
                {
                    throw new IndexOutOfRangeException("[AssetTags] tagIdx out of range]");
                }
                while (tagIdx != 0)
                {
                    _tags[tagIdx] = 1;
                    tagIdx = TagRegister.Tree[tagIdx];
                }
            }
        }

        public bool HasTag(string tagName)
        {
            return HasTag(tagName.ToGameTag());
        }

        public bool HasAnyTags(List<string> tags)
        {
            for (int i = 0; i < tags.Count; i++)
            {
                var tag = tags[i].ToGameTag();
                if (HasTag(tag))
                {
                    return true;
                }
            }
            return false;
        }

        public bool HasTag(EGameTag tag)
        {
            var tagIdx = (int)tag;
            if (tagIdx >= _tags.Length)
            {
                throw new IndexOutOfRangeException("[AssetTags] tagIdx out of range]");
            }
            return _tags[tagIdx] > 0;
        }
    }
}