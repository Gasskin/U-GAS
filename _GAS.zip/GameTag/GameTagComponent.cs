using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Meow.Runtime.AOT;
using Sirenix.OdinInspector;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    public static class UnitTagHelper
    {
        public static EGameTag ToGameTag(this string tag)
        {
            var t = TagRegister.StringToEnum.GetValueOrDefault(tag, EGameTag.None);
            if (t == EGameTag.None)
            {
                throw new ArgumentOutOfRangeException($"不存在GameTag: {tag}");
            }
            return t;
        }
    }

    [Serializable]
    public class GameTagComponent
    {
        public IEnumerable<(EGameTag tag, int count)> Tags => _tags.Select((count, index) => ((EGameTag)index, count));


        private bool _isDirty;

        private int[] _tags = new int[TagRegister.Size];

        private GameAbilitySystem _owner;

        public void OnStart(GameAbilitySystem owner)
        {
            _owner = owner;
        }

        public void OnStop()
        {
        }

        [Conditional("UNITY_EDITOR")]
        private void Print(string content)
        {
            var stackTrace = Environment.StackTrace;
            GameLog.Info($"{content}\n{stackTrace}");
        }

        public void AddTag(EGameTag eTag)
        {
            TravelAdd((int)eTag, 1);
            Print($"[UnitTagComponent]<color=#0F0>AddTag: {eTag}</color>");
        }

        public void AddTagsWithDirty(List<string> grantedTags)
        {
            if (grantedTags == null)
            {
                return;
            }
            _isDirty = false;
            foreach (var tag in grantedTags)
            {
                AddTag(tag.ToGameTag());
            }
            if (_isDirty)
            {
                _owner.GameEffectComponent.OnTagDirty();
            }
        }

        public void RemoveTagsWithDirty(List<string> grantedTags)
        {
            if (grantedTags == null)
            {
                return;
            }
            _isDirty = false;
            foreach (var tag in grantedTags)
            {
                RemoveTag(tag.ToGameTag());
            }
            if (_isDirty)
            {
                _owner.GameEffectComponent.OnTagDirty();
            }
        }

        public void RemoveTag(EGameTag eTag)
        {
            TravelAdd((int)eTag, -1);
            Print($"[UnitTagComponent]<color=#F00>RemoveTag: {eTag}</color>");
        }

        public bool HasTag(EGameTag eTag)
        {
            if ((int)eTag >= _tags.Length)
            {
                GameLog.Error("Tag index out of range");
                return false;
            }
            return _tags[(int)eTag] > 0;
        }

        public bool HasTag(string tag)
        {
            return HasTag(tag.ToGameTag());
        }

        public bool HasAllTag(List<string> eTags)
        {
            if (eTags == null)
            {
                GameLog.Error("Tag list is null");
                return false;
            }
            for (var i = 0; i < eTags.Count; i++)
            {
                if (!HasTag(eTags[i]))
                {
                    return false;
                }
            }
            return true;
        }

        public bool HasAnyTag(List<string> eTags)
        {
            if (eTags == null)
            {
                GameLog.Error("Tag list is null");
                return false;
            }
            for (var i = 0; i < eTags.Count; i++)
            {
                if (HasTag(eTags[i]))
                {
                    return true;
                }
            }
            return false;
        }

        public bool HasAnyTag(List<EGameTag> eTags)
        {
            if (eTags == null)
            {
                GameLog.Error("Tag list is null");
                return false;
            }
            for (var i = 0; i < eTags.Count; i++)
            {
                if (HasTag(eTags[i]))
                {
                    return true;
                }
            }
            return false;
        }

        public bool HasNoTag(List<EGameTag> eTags)
        {
            if (eTags == null)
            {
                GameLog.Error("Tag list is null");
                return false;
            }
            for (var i = 0; i < eTags.Count; i++)
            {
                if (HasTag(eTags[i]))
                {
                    return false;
                }
            }
            return true;
        }

        public bool HasNoTag(List<string> eTags)
        {
            if (eTags == null)
            {
                GameLog.Error("Tag list is null");
                return false;
            }
            for (var i = 0; i < eTags.Count; i++)
            {
                if (HasTag(eTags[i]))
                {
                    return false;
                }
            }
            return true;
        }

        private void TravelAdd(int idx, int value)
        {
            while (idx > 0)
            {
                if (idx >= _tags.Length)
                {
                    GameLog.Error("Tag index out of range");
                    break;
                }
                var oldValue = _tags[idx];
                _tags[idx] += value;
                _tags[idx] = Math.Max(_tags[idx], 0);
                var newValue = _tags[idx];
                _isDirty = _isDirty || ((oldValue == 0) != (newValue == 0));
                idx = TagRegister.Tree[idx];
            }
        }
    }
}