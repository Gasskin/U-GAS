using System.Collections.Generic;

namespace Meow.Runtime.HotUpdate
{
    public static class GameTagUtil
    {
        /// <summary>
        /// 完全匹配某个tag
        /// </summary>
        /// <param name="tags"></param>
        /// <param name="tag"></param>
        /// <returns></returns>
        public static bool HasTag(List<string> tags, EGameTag tag)
        {
            if (tags == null)
            {
                return false;
            }
            for (int i = 0; i < tags.Count; i++)
            {
                if (tags[i].ToGameTag() == tag)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 存在某个Tag路径
        /// 目标路径是：Skill.A
        /// 则Skill.A.1存在目标路径
        /// </summary>
        /// <param name="tags"></param>
        /// <param name="tag"></param>
        /// <returns></returns>
        public static bool HasTagPath(List<string> tags, EGameTag tag)
        {
            if (tags == null)
            {
                return false;
            }
            for (int i = 0; i < tags.Count; i++)
            {
                var t = tags[i].ToGameTag();
                if (IsInPath(tag, t))
                {
                    return true;
                }
            }
            return false;
        }

        private static bool IsInPath(EGameTag parent, EGameTag child)
        {
            if (parent == child)
            {
                return true;
            }
            var parentIdx = (int)parent;
            var idx = (int)child;
            while (idx > 0)
            {
                var p = TagRegister.Tree[idx];
                if (p == parentIdx)
                {
                    return true;
                }
                idx = p;
            }
            return false;
        }
    }
}