using Sirenix.OdinInspector;
namespace Meow.Runtime.HotUpdate
{
	public enum EGameTag
	{
		None = 0,
		/// <summary>
		/// "连招"
		/// </summary>
		[LabelText("连招")]
		Combo = 1,
		/// <summary>
		/// "连招/普攻2"
		/// </summary>
		[LabelText("连招/普攻2")]
		Combo_NA_2 = 2,
		/// <summary>
		/// "连招/普攻3"
		/// </summary>
		[LabelText("连招/普攻3")]
		Combo_NA_3 = 3,
		/// <summary>
		/// "连招/普攻4"
		/// </summary>
		[LabelText("连招/普攻4")]
		Combo_NA_4 = 4,
		/// <summary>
		/// "连招/普攻5"
		/// </summary>
		[LabelText("连招/普攻5")]
		Combo_NA_5 = 5,
		/// <summary>
		/// "连招/强特2"
		/// </summary>
		[LabelText("连招/强特2")]
		Combo_SA_2 = 6,
		/// <summary>
		/// "连招/强特3"
		/// </summary>
		[LabelText("连招/强特3")]
		Combo_SA_3 = 7,
		/// <summary>
		/// "连招/强化闪避1"
		/// </summary>
		[LabelText("连招/强化闪避1")]
		Combo_SS_1 = 8,
		/// <summary>
		/// "连招/闪避1"
		/// </summary>
		[LabelText("连招/闪避1")]
		Combo_S_1 = 9,
		/// <summary>
		/// "效果"
		/// </summary>
		[LabelText("效果")]
		Effect = 10,
		/// <summary>
		/// "效果/增益"
		/// </summary>
		[LabelText("效果/增益")]
		Effect_Buff = 11,
		/// <summary>
		/// "效果/消耗"
		/// </summary>
		[LabelText("效果/消耗")]
		Effect_Cost = 12,
		/// <summary>
		/// "效果/伤害"
		/// </summary>
		[LabelText("效果/伤害")]
		Effect_Damage = 13,
		/// <summary>
		/// "效果/伤害/追击伤害"
		/// </summary>
		[LabelText("效果/伤害/追击伤害")]
		Effect_Damage_Extend = 14,
		/// <summary>
		/// "效果/减益"
		/// </summary>
		[LabelText("效果/减益")]
		Effect_DeBuff = 15,
		/// <summary>
		/// "效果/恢复"
		/// </summary>
		[LabelText("效果/恢复")]
		Effect_Recover = 16,
		/// <summary>
		/// "预输入"
		/// </summary>
		[LabelText("预输入")]
		PreInput = 17,
		/// <summary>
		/// "技能"
		/// </summary>
		[LabelText("技能")]
		Skill = 18,
		/// <summary>
		/// "技能/格露丝"
		/// </summary>
		[LabelText("技能/格露丝")]
		Skill_Ghroth = 19,
		/// <summary>
		/// "技能/格露丝/普通攻击"
		/// </summary>
		[LabelText("技能/格露丝/普通攻击")]
		Skill_Ghroth_Attack = 20,
		/// <summary>
		/// "技能/光辉"
		/// </summary>
		[LabelText("技能/光辉")]
		Skill_Luxcis = 21,
		/// <summary>
		/// "技能/光辉/攻击"
		/// </summary>
		[LabelText("技能/光辉/攻击")]
		Skill_Luxcis_Attack = 22,
		/// <summary>
		/// "技能/光辉/奥义光焰"
		/// </summary>
		[LabelText("技能/光辉/奥义光焰")]
		Skill_Luxcis_UltimateFire = 23,
		/// <summary>
		/// "技能/莉亚娜"
		/// </summary>
		[LabelText("技能/莉亚娜")]
		Skill_Lyana = 24,
		/// <summary>
		/// "技能/莉亚娜/特殊攻击"
		/// </summary>
		[LabelText("技能/莉亚娜/特殊攻击")]
		Skill_Lyana_Special = 25,
		/// <summary>
		/// "技能/女主"
		/// </summary>
		[LabelText("技能/女主")]
		Skill_NvZhu = 26,
		/// <summary>
		/// "技能/女主/普通攻击"
		/// </summary>
		[LabelText("技能/女主/普通攻击")]
		Skill_NvZhu_Attack = 27,
		/// <summary>
		/// "技能/女主/强化攻击"
		/// </summary>
		[LabelText("技能/女主/强化攻击")]
		Skill_NvZhu_SuperAttack = 28,
		/// <summary>
		/// "技能/女主/强化攻击/强化攻击3"
		/// </summary>
		[LabelText("技能/女主/强化攻击/强化攻击3")]
		Skill_NvZhu_SuperAttack_Attack3 = 29,
		/// <summary>
		/// "前摇"
		/// </summary>
		[LabelText("前摇")]
		Startup = 30,
		/// <summary>
		/// "状态"
		/// </summary>
		[LabelText("状态")]
		State = 31,
		/// <summary>
		/// "状态/增益状态"
		/// </summary>
		[LabelText("状态/增益状态")]
		State_Buff = 32,
		/// <summary>
		/// "状态/增益状态/霸体"
		/// </summary>
		[LabelText("状态/增益状态/霸体")]
		State_Buff_Armor = 33,
		/// <summary>
		/// "状态/增益状态/女主"
		/// </summary>
		[LabelText("状态/增益状态/女主")]
		State_Buff_Eve = 34,
		/// <summary>
		/// "状态/增益状态/女主/奥义"
		/// </summary>
		[LabelText("状态/增益状态/女主/奥义")]
		State_Buff_Eve_Ultimate = 35,
		/// <summary>
		/// "状态/增益状态/无敌"
		/// </summary>
		[LabelText("状态/增益状态/无敌")]
		State_Buff_Invincible = 36,
		/// <summary>
		/// "状态/增益状态/菊"
		/// </summary>
		[LabelText("状态/增益状态/菊")]
		State_Buff_Ju = 37,
		/// <summary>
		/// "状态/增益状态/菊/增加攻击"
		/// </summary>
		[LabelText("状态/增益状态/菊/增加攻击")]
		State_Buff_Ju_Special = 38,
		/// <summary>
		/// "状态/增益状态/菊/魔力加持"
		/// </summary>
		[LabelText("状态/增益状态/菊/魔力加持")]
		State_Buff_Ju_SpecialMagicalBlessing = 39,
		/// <summary>
		/// "状态/增益状态/光辉"
		/// </summary>
		[LabelText("状态/增益状态/光辉")]
		State_Buff_Luxcis = 40,
		/// <summary>
		/// "状态/增益状态/光辉/奥义状态"
		/// </summary>
		[LabelText("状态/增益状态/光辉/奥义状态")]
		State_Buff_Luxcis_Ultimate = 41,
		/// <summary>
		/// "状态/增益状态/妮娜"
		/// </summary>
		[LabelText("状态/增益状态/妮娜")]
		State_Buff_Nina = 42,
		/// <summary>
		/// "状态/增益状态/妮娜/祝福"
		/// </summary>
		[LabelText("状态/增益状态/妮娜/祝福")]
		State_Buff_Nina_NinaBlessing = 43,
		/// <summary>
		/// "状态/增益状态/妮娜/延时清除祝福"
		/// </summary>
		[LabelText("状态/增益状态/妮娜/延时清除祝福")]
		State_Buff_Nina_NinaClearBlessing = 44,
		/// <summary>
		/// "状态/增益状态/妮娜/一命额外祝福"
		/// </summary>
		[LabelText("状态/增益状态/妮娜/一命额外祝福")]
		State_Buff_Nina_NinaStar1Blessing = 45,
		/// <summary>
		/// "状态/增益状态/妮娜/奥义加强祝福"
		/// </summary>
		[LabelText("状态/增益状态/妮娜/奥义加强祝福")]
		State_Buff_Nina_NinaUltimateBlessing = 46,
		/// <summary>
		/// "状态/增益状态/希娅"
		/// </summary>
		[LabelText("状态/增益状态/希娅")]
		State_Buff_Sia = 47,
		/// <summary>
		/// "状态/增益状态/希娅/面包"
		/// </summary>
		[LabelText("状态/增益状态/希娅/面包")]
		State_Buff_Sia_Bread = 48,
		/// <summary>
		/// "状态/增益状态/希娅/果冻"
		/// </summary>
		[LabelText("状态/增益状态/希娅/果冻")]
		State_Buff_Sia_Jelly = 49,
		/// <summary>
		/// "状态/增益状态/希娅/红茶"
		/// </summary>
		[LabelText("状态/增益状态/希娅/红茶")]
		State_Buff_Sia_RedTea = 50,
		/// <summary>
		/// "状态/增益状态/希娅/特殊技防御"
		/// </summary>
		[LabelText("状态/增益状态/希娅/特殊技防御")]
		State_Buff_Sia_SpecialDef = 51,
		/// <summary>
		/// "状态/增益状态/希娅/奥义治疗"
		/// </summary>
		[LabelText("状态/增益状态/希娅/奥义治疗")]
		State_Buff_Sia_Ultimate = 52,
		/// <summary>
		/// "状态/减益状态"
		/// </summary>
		[LabelText("状态/减益状态")]
		State_DeBuff = 53,
		/// <summary>
		/// "状态/减益状态/异常状态"
		/// </summary>
		[LabelText("状态/减益状态/异常状态")]
		State_DeBuff_Abnormal = 54,
		/// <summary>
		/// "状态/减益状态/异常状态/创造"
		/// </summary>
		[LabelText("状态/减益状态/异常状态/创造")]
		State_DeBuff_Abnormal_Create = 55,
		/// <summary>
		/// "状态/减益状态/异常状态/黑暗"
		/// </summary>
		[LabelText("状态/减益状态/异常状态/黑暗")]
		State_DeBuff_Abnormal_Dart = 56,
		/// <summary>
		/// "状态/减益状态/异常状态/能量"
		/// </summary>
		[LabelText("状态/减益状态/异常状态/能量")]
		State_DeBuff_Abnormal_Energy = 57,
		/// <summary>
		/// "状态/减益状态/异常状态/光明"
		/// </summary>
		[LabelText("状态/减益状态/异常状态/光明")]
		State_DeBuff_Abnormal_Light = 58,
		/// <summary>
		/// "状态/减益状态/异常状态/空间"
		/// </summary>
		[LabelText("状态/减益状态/异常状态/空间")]
		State_DeBuff_Abnormal_Space = 59,
		/// <summary>
		/// "状态/减益状态/异常状态/时间"
		/// </summary>
		[LabelText("状态/减益状态/异常状态/时间")]
		State_DeBuff_Abnormal_Time = 60,
		/// <summary>
		/// "状态/减益状态/异常状态/虚无"
		/// </summary>
		[LabelText("状态/减益状态/异常状态/虚无")]
		State_DeBuff_Abnormal_Void = 61,
		/// <summary>
		/// "状态/减益状态/破韧状态"
		/// </summary>
		[LabelText("状态/减益状态/破韧状态")]
		State_DeBuff_BreakTough = 62,
		/// <summary>
		/// "状态/减益状态/莉莉"
		/// </summary>
		[LabelText("状态/减益状态/莉莉")]
		State_DeBuff_Lily = 63,
		/// <summary>
		/// "状态/减益状态/莉莉/猎人印记"
		/// </summary>
		[LabelText("状态/减益状态/莉莉/猎人印记")]
		State_DeBuff_Lily_HunterMark = 64,
		/// <summary>
		/// "状态/减益状态/空"
		/// </summary>
		[LabelText("状态/减益状态/空")]
		State_DeBuff_Lyana = 65,
		/// <summary>
		/// "状态/减益状态/空/莉亚娜死亡印记"
		/// </summary>
		[LabelText("状态/减益状态/空/莉亚娜死亡印记")]
		State_DeBuff_Lyana_DeathMark = 66,
		/// <summary>
		/// "状态/死亡"
		/// </summary>
		[LabelText("状态/死亡")]
		State_Die = 67,
		/// <summary>
		/// "状态/命座1"
		/// </summary>
		[LabelText("状态/命座1")]
		State_HeroStar1 = 68,
		/// <summary>
		/// "状态/命座2"
		/// </summary>
		[LabelText("状态/命座2")]
		State_HeroStar2 = 69,
		/// <summary>
		/// "状态/命座3"
		/// </summary>
		[LabelText("状态/命座3")]
		State_HeroStar3 = 70,
		/// <summary>
		/// "状态/命座4"
		/// </summary>
		[LabelText("状态/命座4")]
		State_HeroStar4 = 71,
		/// <summary>
		/// "状态/命座5"
		/// </summary>
		[LabelText("状态/命座5")]
		State_HeroStar5 = 72,
		/// <summary>
		/// "状态/命座6"
		/// </summary>
		[LabelText("状态/命座6")]
		State_HeroStar6 = 73,
	}
}
