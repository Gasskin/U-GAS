﻿using System.Collections.Generic;
using MemoryPack;
using Sirenix.OdinInspector;

namespace Meow.Runtime.HotUpdate
{
    [MemoryPackable]
    [InlineProperty]
    [System.Serializable]
    public partial struct SerializableGameTag
    {
        [ValueDropdown("@GameTagDropdownHelper.GetTagDropdown()", IsUniqueList = true)]
        [HideLabel]
        public string tag;

        // 重载转换操作符
        public static implicit operator EGameTag(SerializableGameTag value)
        {
            return TagRegister.StringToEnum.GetValueOrDefault(value.tag, EGameTag.None);
        }
        public static implicit operator SerializableGameTag(EGameTag value)
        {
            return new SerializableGameTag { tag = value.ToString() };
        }
        // 重载转换操作符
        public static implicit operator string(SerializableGameTag value)
        {
            return value.tag;
        }
        public static implicit operator SerializableGameTag(string value)
        {
            return new SerializableGameTag { tag = value };
        }
    }
}