using System;
using System.Collections.Generic;
using cfg.attribute;
using cfg.hero;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 属性快照
    /// </summary>
    public struct AttrCapture
    {
        // 攻击力
        public float atk;

        // 防御忽略
        public float defIgnore;

        // 额外增伤
        public float dmgAdd;
    }

    /// <summary>
    /// 异常贡献
    /// </summary>
    public class AccrueContribution
    {
        private List<uint> _from = new();
        private List<float> _contribution = new();
        private List<float> _priority = new();

        public void InitPriority()
        {
            _priority.Clear();
            var total = 0f;
            for (int i = 0; i < _contribution.Count; i++)
            {
                total += _contribution[i];
            }
            for (int i = 0; i < _contribution.Count; i++)
            {
                _priority.Add(_contribution[i] / total);
            }
        }

        public int GetPriorityLevel()
        {
            var level = 0f;
            for (int i = 0; i < _priority.Count; i++)
            {
                var feature = World.Current.GetComp<FeatureComp>(_from[i]);
                level += feature.Level * _priority[i];
            }
            return (int)Math.Ceiling(level);
        }

        public float GetPriorityAttr(AttributeId attrId)
        {
            var pAttr = 0f;
            for (int i = 0; i < _priority.Count; i++)
            {
                var gas = World.Current.GetComp<GameAbilitySystem>(_from[i]);
                pAttr += gas.GameAttributeComponent.GetCurrentValue(attrId) * _priority[i];
            }
            return pAttr;
        }

        public void AddContribution(uint from, float accrue)
        {
            for (int i = 0; i < _from.Count; i++)
            {
                if (_from[i] == from)
                {
                    _contribution[i] += accrue;
                    return;
                }
            }
            _from.Add(from);
            _contribution.Add(accrue);
        }

        public void Clear()
        {
            _from.Clear();
            _contribution.Clear();
        }
    }

    /// <summary>
    /// 异常状态积蓄统计
    /// </summary>
    public class AbnormalAccrueStatisticComp : EntityComp
    {
        // 角色ID：造成的积蓄值
        private Dictionary<Element, AccrueContribution> _contribution = new();

        // 异常类型：属性切片
        private Dictionary<Element, AttrCapture> _attrCaptures = new();

        public void AddContribution(Element e, uint ent, float accrue)
        {
            if (!_contribution.TryGetValue(e, out var c))
            {
                c = new AccrueContribution();
                _contribution[e] = c;
            }
            c.AddContribution(ent, accrue);
        }

        public void ClearContribution(Element e)
        {
            if (_contribution.TryGetValue(e, out var c))
            {
                c.Clear();
            }
        }

        public void CaptureAttr(Element element, uint entId)
        {
            if (!_contribution.TryGetValue(element, out var c))
            {
                return;
            }
            if (!World.Current.TryGetEntityComp(entId, out GameAbilitySystem virtualSource))
            {
                throw new ArgumentOutOfRangeException($"CaptureAttr: Entity不存在GameAbilitySystem");
            }
            if (!World.Current.TryGetEntityComp(entId, out FeatureComp feature))
            {
                throw new ArgumentOutOfRangeException($"CaptureAttr: Entity不存在FeatureComp");
            }

            var attr = virtualSource.GameAttributeComponent;
            c.InitPriority();

            feature.Level = c.GetPriorityLevel();

            attr.GetAttribute(AttributeId.AtkBase).SetBaseValue(c.GetPriorityAttr(AttributeId.AtkFinal));
            
            attr.GetAttribute(AttributeId.DefIgnoreRate).SetBaseValue(c.GetPriorityAttr(AttributeId.DefIgnoreRate));
            attr.GetAttribute(AttributeId.DefIgnore).SetBaseValue(c.GetPriorityAttr(AttributeId.DefIgnore));
            
            attr.GetAttribute(AttributeId.DamageInc).SetBaseValue(c.GetPriorityAttr(AttributeId.DamageInc));
            
            attr.GetAttribute(AttributeId.LightDefIgnore).SetBaseValue(c.GetPriorityAttr(AttributeId.LightDefIgnore));
            attr.GetAttribute(AttributeId.VoidDefIgnore).SetBaseValue(c.GetPriorityAttr(AttributeId.VoidDefIgnore));
            attr.GetAttribute(AttributeId.TimeDefIgnore).SetBaseValue(c.GetPriorityAttr(AttributeId.TimeDefIgnore));
            attr.GetAttribute(AttributeId.EnergyDefIgnore).SetBaseValue(c.GetPriorityAttr(AttributeId.EnergyDefIgnore));
            attr.GetAttribute(AttributeId.CreateDefIgnore).SetBaseValue(c.GetPriorityAttr(AttributeId.CreateDefIgnore));
            attr.GetAttribute(AttributeId.DarkDefIgnore).SetBaseValue(c.GetPriorityAttr(AttributeId.DarkDefIgnore));
            attr.GetAttribute(AttributeId.SpaceDefIgnore).SetBaseValue(c.GetPriorityAttr(AttributeId.SpaceDefIgnore));
            attr.GetAttribute(AttributeId.AllElementDefIgnore).SetBaseValue(c.GetPriorityAttr(AttributeId.AllElementDefIgnore));
            
            attr.GetAttribute(AttributeId.BreakDoneMult).SetBaseValue(c.GetPriorityAttr(AttributeId.BreakDoneMult));
            
            attr.GetAttribute(AttributeId.AbnormalDamageMult).SetBaseValue(c.GetPriorityAttr(AttributeId.AbnormalDamageMult));
        }
    }
}