using System;
using System.Diagnostics;
using System.Text;
using FixMath.NET;
using MemoryPack;
using Sirenix.OdinInspector;

namespace Meow.Runtime.HotUpdate
{


    [MemoryPackable]
    [MemoryPackUnion(1, typeof(CommonSkillDamageMagnitude))]
    [MemoryPackUnion(2, typeof(SimpleFloatMagnitude))]
    [MemoryPackUnion(3, typeof(AttributeBasedMagnitude))]
    [MemoryPackUnion(4, typeof(ToughBladeDamage))]
    [MemoryPackUnion(5, typeof(ToughnessReduceMagnitude))]
    [MemoryPackUnion(6, typeof(BreakBladeDamageMagnitude))]
    [MemoryPackUnion(7, typeof(AbnormalAccrueMagnitude))]
    [MemoryPackUnion(8, typeof(AbnormalDamageMagnitude))]
    [MemoryPackUnion(9, typeof(EnergyRecoverMagnitude))]
    [MemoryPackUnion(10, typeof(AddPowerMagnitude))]
    [MemoryPackUnion(11, typeof(HpRecoverMagnitude))]
    [Serializable]
    public abstract partial class ModifierMagnitude
    {
        protected StringBuilder debugLogger = new();
        public abstract float CalculateMagnitude(GameEffectSpec spec);

        [Conditional("UNITY_EDITOR")]
        protected void AddDebugLog(string s)
        {
            debugLogger.AppendLine(s);
        }
    }
}