using System;
using cfg.hero;
using cfg.skill;
using cfg.attribute;
using MemoryPack;
using Meow.Runtime.AOT;
using Sirenix.OdinInspector;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    public struct CommonSkillDamageEvent : IEventMessage
    {
        // 目标
        public uint target;

        // 原始伤害
        public float originalDamage;

        // 结算伤害（扣除护盾等
        public float trueDamage;

        // hit次数，没有太多意义，用于UI表现和暴击计算
        public int hitNum;

        // 暴击次数，多hit的伤害，每段hit的暴击率是单独计算的
        public int critNum;

        // 暴击伤害倍率
        public float critB;

        // 伤害类型
        public Element element;

        // 受击坐标
        public Vector3 hitPoint;

        // 没有暴击的次数 = 总次数 - 暴击次数
        public readonly int NoCritNum => hitNum - critNum;

        // 每一次的基础伤害
        public readonly float BaseDmg
        {
            get
            {
                float t = NoCritNum + critNum * critB;
                if (t <= 0f)
                {
                    t = 1f; //防止分母为0
                }
                return originalDamage / t;
            }
        }

        // 每一次的暴击伤害
        public readonly float CritDmg => BaseDmg * critB;

        // 发事件
        public void Send()
        {
            this.SendMessage();
        }
    }

    /// <summary>
    /// 通用技能伤害计算器
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public sealed partial class CommonSkillDamageMagnitude : ModifierMagnitude
    {
        [LabelWidth(100)]
        public int skillDbId;

#if UNITY_EDITOR
        public static bool Debug;
#endif

        public override float CalculateMagnitude(GameEffectSpec spec)
        {
            if (!TbSkillDB.Instance.DataMap.TryGetValue(skillDbId, out var skillDB))
            {
                GameLog.Error($"[CommonSkillDamageMagnitude] 不存在TbSkillDB: {skillDbId}");
                return 0;
            }

            if (!World.Current.TryGetEntityComp(spec.Source.Entity, out SkillComp skillComp))
            {
                GameLog.Error($"[CommonSkillDamageMagnitude] 不存在SkillComp: {spec.Source.Entity}");
                return 0;
            }

#if UNITY_EDITOR
            debugLogger.Clear();
            if (Debug)
            {
                debugLogger.AppendLine($"[CommonSkillDamageMagnitude] skillDbId: {skillDbId}");
            }
#endif

            var e = new CommonSkillDamageEvent();
            e.element = skillDB.ElementType;
            e.target = spec.Target.Entity;
            e.hitNum = skillDB.Hit;
            e.hitPoint = spec.Context.hitPoint;

            // 基础值 = 攻击力 * 技能倍率 + 公式计算值
            var baseAttr = spec.Source.GameAttributeComponent.GetCurrentValue(skillDB.ValueAttr);
            var level = skillComp.GetSkillLevel(skillDB.Node);
            var value = skillDB.Value / 10000f + skillDB.ValueLv / 10000f * (level - 1);
            var damage = baseAttr * value;

            AddDebugLog("【基础值】");
            AddDebugLog($"damage[{damage}] = baseAttr[{skillDB.ValueAttr}][{baseAttr}] * value[{value}]");

            // 防御
            damage = DefenceArea.Process(damage, spec, debugLogger);

            // 额外增减伤
            damage = ExtraAddArea.Process(damage, spec, debugLogger);

            // 易伤
            damage = DamageFixArea.Process(damage, spec, debugLogger);

            // 元素抗性
            damage = ElementArea.Process(damage, spec, skillDB.ElementType, debugLogger);

            // 破韧增伤
            damage = BreakArea.Process(damage, spec, debugLogger);

            // 伤害修正（只有怪物存在这个属性）
            var mod = spec.Source.GameAttributeComponent.GetAttribute(AttributeId.DamageMod).CurrentValue;
            damage *= 1 + mod;
#if UNITY_EDITOR
            debugLogger?.AppendLine("【伤害修正】");
            debugLogger?.AppendLine($"damage[{damage}] *= 1 + damageMod[{mod}]");
#endif

            if (skillDB.DamageType == DamageType.Abnormal)
            {
                // 属性精通
                damage = AbnormalArea.Process(damage, spec, debugLogger);
            }
            else
            {
                // 暴击
                var (d, c, cb) = CriticalArea.Process(damage, spec, skillDB.Hit, debugLogger);
                damage = d;
                e.critNum = c;
                e.critB = cb;
            }

#if UNITY_EDITOR
            if (Debug)
            {
                GameLog.Info(debugLogger?.ToString());
            }
#endif
            e.originalDamage = damage;
            DamagePipeline.Instance.Process(spec, e);

            return 0;
        }

    }
}