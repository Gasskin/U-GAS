using System;
using cfg.attribute;
using cfg.gas;
using MemoryPack;
using Sirenix.OdinInspector;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 获得奥义能量
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class AddPowerMagnitude  : ModifierMagnitude
    {
        [LabelWidth(100)]
        public int gasValueId;
        [LabelWidth(100)]
        public int gasParamIndex;
        
        public override float CalculateMagnitude(GameEffectSpec spec)
        {
            var add = spec.Target.GameAttributeComponent.GetCurrentValue(AttributeId.PowerRecvMult);
            return GasValue.GetParam(gasValueId, gasParamIndex) * (1f + add);
        }
    }
}