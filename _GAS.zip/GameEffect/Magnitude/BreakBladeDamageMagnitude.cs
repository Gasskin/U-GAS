using System;
using System.Diagnostics;
using System.Text;
using MemoryPack;
using Sirenix.OdinInspector;
using cfg.attribute;
using cfg.hero;
using cfg.monster;
using cfg.skill;
using global::cfg.global;
using Meow.Runtime.AOT;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 击破伤害计算器 
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public sealed partial class BreakBladeDamageMagnitude : ModifierMagnitude
    {
        [LabelWidth(100)]
        public bool debug;

        public override float CalculateMagnitude(GameEffectSpec spec)
        {
            // 获取技能数据
            var skillDbId = spec.Context.skillDbId;
            if (skillDbId == 0)
            {
                GameLog.Warning("[BreakBladeDamageMagnitude] 技能ID为0，无法获取技能数据");
                return 0;
            }

            if (!TbSkillDB.Instance.DataMap.TryGetValue(skillDbId, out var skillDB))
            {
                GameLog.Error($"[BreakBladeDamageMagnitude] 不存在TbSkillDB: {skillDbId}");
                return 0;
            }

            // if (!TbSkillEffect.Instance.DataMap.TryGetValue(skillDB.EffectId, out var skillEffect))
            // {
            //     GameLog.Error($"[BreakBladeDamageMagnitude] 不存在TbSkillEffect: {skillDB.EffectId}");
            //     return 0;
            // }

            var e = new CommonSkillDamageEvent();
            e.element = skillDB.ElementType;
            e.target = spec.Target.Entity;
            e.hitPoint = spec.Context.hitPoint;
            e.hitNum = 1;

#if UNITY_EDITOR
            debugLogger.Clear();
            if (debug)
            {
                debugLogger.AppendLine($"[BreakBladeDamageMagnitude] skillDbId: {skillDbId}");
            }
#endif

            #region 基础值
            /// ====================================================
            /// 基础值 = 攻击力 * 技能倍率 + 公式计算值
            /// ====================================================

            var roleLv = 1;
            if (World.Current.TryGetEntityComp(spec.Source.Entity, out FeatureComp featureComp))
            {
                roleLv = featureComp.Level;
            }
            var baseDamage = 0f;
            if (!TbHeroLevelTough.Instance.DataMap.TryGetValue(roleLv, out var levelTough))
            {
                return baseDamage;
            }

            baseDamage = levelTough.LvToughParm;
            if (World.Current.TryGetEntityComp(spec.Source.Entity, out HeroUnitComp heroUnitComp))
            {
                var ratio = TbGlobal.Instance.ToughBasedamRatioMap[heroUnitComp.Config.Element];
                baseDamage *= ratio;
            }
      
            debugLogger.AppendLine("【基础值】");
            debugLogger.AppendLine($"damage[{baseDamage}] ");
            #endregion

            #region 韧性条系数
            if (!World.Current.TryGetEntityComp<MonsterUnitComp>(spec.Target.Entity, out var monsterComp))
            {
                return baseDamage;
            }

            baseDamage = baseDamage * monsterComp.Config.ToughBarRatio;
            #endregion

            // 防御
            baseDamage = DefenceArea.Process(baseDamage, spec, debugLogger);

            // 额外增减伤
            baseDamage = ExtraAddArea.Process(baseDamage, spec, debugLogger);

            // 易伤
            baseDamage = DamageFixArea.Process(baseDamage, spec, debugLogger);

            // 元素抗性
            baseDamage = ElementArea.Process(baseDamage, spec, skillDB.ElementType, debugLogger);

#if UNITY_EDITOR
            if (debug)
            {
                GameLog.Info(debugLogger.ToString());
            }
#endif
            e.originalDamage = baseDamage;
            DamagePipeline.Instance.Process(spec, e);
            return 0;
        }
    }
}