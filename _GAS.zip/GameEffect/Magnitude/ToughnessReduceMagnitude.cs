using System;
using MemoryPack;
using Sirenix.OdinInspector;
using cfg.attribute;
using cfg.skill;
using Meow.Runtime.AOT;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 韧性值扣除计算器 - 计算对目标韧性值的扣除量
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public sealed partial class ToughnessReduceMagnitude : ModifierMagnitude
    {
        
        [LabelWidth(100)]
        public int skillDbId;
        
        [Title("韧性值扣除配置")]
        

        public override float CalculateMagnitude(GameEffectSpec spec)
        {
            if (spec?.Source?.GameAttributeComponent == null)
            {
                return 0;
            }
            if (!TbSkillDB.Instance.DataMap.TryGetValue(skillDbId, out var skillDB))
            {
                GameLog.Error($"[CommonSkillDamageMagnitude] 不存在的SkillDB: {skillDbId}");
                return 0;
            }
            // 创建韧性值减少事件
            var toughnessEvent = new ToughnessReduceEvent
            {
                skillDbId = skillDbId,
                target = spec.Target.Entity,
                hitPoint = spec.Context.hitPoint,
                sourceSpec = spec
            };
            

            //获取角色断刃力
            var heroForce = spec.Source.GameAttributeComponent.GetAttribute(AttributeId.BreakForce);
            // if (!TbSkillEffect.Instance.DataMap.TryGetValue(skillDB.EffectId, out var skillEffect))
            // {
            //     GameLog.Error($"[CommonSkillDamageMagnitude] 不存在SkillEffect: {skillDB.EffectId}");
            //     return 0;
            // }
          
            var skillTough_break = skillDB.ToughBreak;
            //获取破刃加成
            var heroTough_Add = spec.Source.GameAttributeComponent.GetAttribute(AttributeId.BreakAccrueMult);

            float baseTouch = heroForce.CurrentValue * skillTough_break * (1 + heroTough_Add.CurrentValue);
            

            GameLog.Info($"[ToughnessReduce] 计算韧性值扣除: baseTouch  {baseTouch}");

            toughnessEvent.toughnessReduce =  baseTouch;
            // 调用韧性值处理管道
            ToughnessPipeline.Instance.Process(spec, toughnessEvent);

            return 0; // 返回0，因为韧性值的实际修改已经在Pipeline中处理
        }
    }
}
