using System;
using cfg.attribute;
using cfg.skill;
using MemoryPack;
using Meow.Runtime.AOT;
using Sirenix.OdinInspector;

namespace Meow.Runtime.HotUpdate
{

    /// <summary>
    /// 能量恢复
    /// 此计算器会忽略modifier的目标属性
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class EnergyRecoverMagnitude : ModifierMagnitude
    {
        [LabelWidth(100)]
        public Time timing = Time.Hit;

        [LabelWidth(100)]
        public int skillDbId;
        
#if UNITY_EDITOR
        public static bool Debug;
#endif

        public override float CalculateMagnitude(GameEffectSpec spec)
        {
            if (!TbSkillDB.Instance.DataMap.TryGetValue(skillDbId, out var skillDB))
            {
                throw new ArgumentOutOfRangeException($"不存在SkillDbId: {skillDbId}");
            }
            
#if UNITY_EDITOR
            debugLogger.Clear();
            AddDebugLog($"【EnergyRecoverMagnitude】skillDbId: {skillDbId}");
#endif
            
            for (int i = 0; i < skillDB.AddEnergy.Count; i++)
            {
                var add = skillDB.AddEnergy[i];
                if (add.Timing != timing)
                {
                    continue;
                }
                var attr = spec.Target.GameAttributeComponent.GetAttribute(add.Type);
                float value = add.Value;
#if UNITY_EDITOR
                debugLogger.Clear();
                AddDebugLog($"【基础值】");
                AddDebugLog($"value = {value}");
#endif
                if (add.Type == AttributeId.CommonEnergy)
                {
                    var mult1 = spec.Target.GameAttributeComponent.GetCurrentValue(AttributeId.CommonEnergyRecvMult);
                    var mult2 = spec.Target.GameAttributeComponent.GetCurrentValue(AttributeId.CommonEnergySkillRecvMult);
                    value *= 1 + mult1 + mult2;
#if UNITY_EDITOR
                    debugLogger.Clear();
                    AddDebugLog($"【通用个人能量】");
                    AddDebugLog($"value[{value}] *= 1 + recvMult[{mult1}] + skillRecvMult[{mult2}]");
#endif
                }
                else if (add.Type == AttributeId.Power)
                {
                    var powerAdd = spec.Target.GameAttributeComponent.GetCurrentValue(AttributeId.PowerRecvMult);
                    value *= 1 + powerAdd;
#if UNITY_EDITOR
                    debugLogger.Clear();
                    AddDebugLog($"【奥义能量】");
                    AddDebugLog($"value[{value}] *= 1 + powerAdd[{powerAdd}]");
#endif
                }

                attr.SetBaseValue(attr.BaseValue + value,false);
                
#if UNITY_EDITOR
                if (Debug)
                {
                    GameLog.Info(debugLogger?.ToString());
                }
#endif
            }

            return 0;
        }

    }
}