﻿using System;
using cfg.attribute;
using cfg.gas;
using MemoryPack;
using Sirenix.OdinInspector;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    [MemoryPackable]
    [Serializable]
    public partial class AttributeBasedMagnitude : ModifierMagnitude
    {
        [InfoBox("out = attr * k + b\n存在gasValueId时，根据k、b读取配置中的数值，否则直接代入k、b进行计算")]
        [Tooltip("默认是从Source身上取属性，勾选则从Target身上取属性")]
        [LabelWidth(100)]
        public bool fromTarget;

        [LabelWidth(100)]
        public AttributeId attributeId;

        [LabelWidth(100)]
        public int gasValueId;

        [LabelWidth(100)]
        public float k;

        [LabelWidth(100)]
        public float b;
        
        public override float CalculateMagnitude(GameEffectSpec spec)
        {
            var from = fromTarget ? spec.Target.GameAttributeComponent : spec.Source.GameAttributeComponent;
            var value = from.GetCurrentValue(attributeId);
            if (gasValueId <= 0)
            {
                return value * k + b;
            }
            return value * GasValue.GetParam(gasValueId, (int)k) + GasValue.GetParam(gasValueId, (int)b);
        }
    }
}