using System;
using cfg.attribute;
using cfg.gas;
using cfg.hero;
using MemoryPack;
using Meow.Runtime.AOT;
using Sirenix.OdinInspector;

namespace Meow.Runtime.HotUpdate
{
    [Serializable]
    [MemoryPackable]
    public partial class AbnormalDamageMagnitude : ModifierMagnitude
    {
        [InfoBox("Parma1 = 倍率")]
        [LabelWidth(100)]
        public int gasValueId;
        [LabelWidth(100)]
        public Element element;

        public bool debug;
        
        public override float CalculateMagnitude(GameEffectSpec spec) 
        {
#if UNITY_EDITOR
            debugLogger.Clear();
#endif
            var ugoComp = World.Current.GetComp<UnitGameObjectComp>(spec.Target.Entity);
            
            var e = new CommonSkillDamageEvent();
            e.target = spec.Target.Entity;
            e.hitNum = 1;
            e.critNum = 0;
            e.critB = 1;
            e.element = element;
            e.hitPoint = ugoComp.Root.transform.position;

            // 基础值
            var ratio = GasValue.GetParam(gasValueId, 1);
            var atk = spec.Source.GameAttributeComponent.GetCurrentValue(AttributeId.AtkFinal);
            var damage = atk * ratio;
            
            AddDebugLog("【基础值】");
            AddDebugLog($"damage[{damage}] = atk[{atk}] * ratio[{ratio}]");

            // 防御乘区
            damage = DefenceArea.Process(damage, spec, debugLogger);

            // 额外增减伤
            damage = ExtraAddArea.Process(damage, spec, debugLogger);

            // 易伤
            damage = DamageFixArea.Process(damage, spec, debugLogger);

            // 元素抗性
            damage = ElementArea.Process(damage, spec, element, debugLogger);

            // 破韧增伤
            damage = BreakArea.Process(damage, spec, debugLogger);
            
            // 属性精通
            damage = AbnormalArea.Process(damage, spec, debugLogger);
            
#if UNITY_EDITOR
            if (debug)
            {
                GameLog.Info(debugLogger.ToString());
            }
#endif
            
            e.originalDamage = damage;
            DamagePipeline.Instance.Process(spec, e);
            
            return 0;
        }
    }
}