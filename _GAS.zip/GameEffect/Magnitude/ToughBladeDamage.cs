﻿using System;
using MemoryPack;
using Sirenix.OdinInspector;
using cfg.attribute;
using cfg.hero;
using cfg.global;
using cfg.skill;
using Meow.Runtime.AOT;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 最终破刃增伤计算器 - 计算破刃状态下的伤害加成
    /// 计算公式: Damage = Damage * (1 + 玩家破韧增伤 + (目标破韧易伤 + 固定易伤值))
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public sealed partial class ToughBladeDamage : ModifierMagnitude
    {
        [LabelWidth(100)]
        public bool debug;

        public override float CalculateMagnitude(GameEffectSpec spec)
        {
            if (spec?.Source?.GameAttributeComponent == null || spec?.Target?.GameAttributeComponent == null)
            {
                GameLog.Warning("[ToughBladeDamage] GameAttributeComponent为空，无法计算破刃增伤");
                return 1f; // 返回1表示无加成
            }

#if UNITY_EDITOR
            debugLogger.Clear();
#endif

            // 检查目标是否处于破韧状态
            var targetToughness = spec.Target.GameAttributeComponent.GetCurrentValue(AttributeId.NowTough);
            if (targetToughness > 0)
            {
                AddDebugLog("[ToughBladeDamage] 目标未处于破韧状态，无破刃增伤");
                return 1f; // 目标未破韧，无增伤
            }

            AddDebugLog("=== 破刃增伤计算 ===");

            // 1. 获取破韧增伤（玩家身上的属性 Break_Dmg_Add）
            var breakDamageAdd = spec.Source.GameAttributeComponent.GetCurrentValue(AttributeId.BreakDoneMult);
            AddDebugLog($"破韧增伤(Break_Dmg_Add): {breakDamageAdd}");

            // 2. 获取破韧易伤（怪物身上的属性 Break_Dmg_Fix，）
            var toughWeakness = spec.Target.GameAttributeComponent.GetCurrentValue(AttributeId.BreakRecvMult);
            AddDebugLog($"破韧易伤(Dmg_Fix): {toughWeakness}");

            // 3. 获取固定易伤值（从全局表tough_dam_weakness_map获取）
            var fixedWeakness = 0f;

            // 获取技能元素类型
            var skillDbId = spec.Context.skillDbId;
            if (skillDbId != 0 && TbSkillDB.Instance.DataMap.TryGetValue(skillDbId, out var skillDB))
            {
                var elementType = skillDB.ElementType;
                if (TbGlobal.Instance.ToughDamWeaknessMap.TryGetValue(elementType, out var weaknessValue))
                {
                    fixedWeakness = weaknessValue / 10000f; // 转换为万分比
                    AddDebugLog($"固定易伤值({elementType}): {weaknessValue} -> {fixedWeakness}");
                }
                else
                {
                    AddDebugLog($"未找到元素类型 {elementType} 对应的固定易伤值");
                }
                // if (TbSkillEffect.Instance.DataMap.TryGetValue(skillDB.EffectId, out var skillEffect))
                // {
                //     var elementType = skillEffect.ElementType;
                //     if (TbGlobal.Instance.ToughDamWeaknessMap.TryGetValue(elementType, out var weaknessValue))
                //     {
                //         fixedWeakness = weaknessValue / 10000f; // 转换为万分比
                //         AddDebugLog($"固定易伤值({elementType}): {weaknessValue} -> {fixedWeakness}");
                //     }
                //     else
                //     {
                //         AddDebugLog($"未找到元素类型 {elementType} 对应的固定易伤值");
                //     }
                // }
                // else
                // {
                //     GameLog.Warning($"[ToughBladeDamage] 未找到SkillEffect: {skillDB.EffectId}");
                // }
            }
            else
            {
                GameLog.Warning($"[ToughBladeDamage] 未找到SkillDB: {skillDbId}");
            }

            // 4. 计算最终倍率
            // 公式: Damage = Damage * (1 + 破韧增伤 + (破韧易伤 + 固定易伤值))
            var totalWeakness = toughWeakness + fixedWeakness;
            var finalMultiplier = breakDamageAdd + totalWeakness;

            AddDebugLog($"总易伤: {totalWeakness} = {toughWeakness} + {fixedWeakness}");
            AddDebugLog($"最终倍率: {finalMultiplier} = 1 + {breakDamageAdd} + {totalWeakness}");

#if UNITY_EDITOR
            if (debug)
            {
                GameLog.Info(debugLogger.ToString());
            }
#endif

            return finalMultiplier;
        }
    }
}