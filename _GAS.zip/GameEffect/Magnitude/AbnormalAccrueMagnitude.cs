using System;
using cfg.attribute;
using cfg.monster;
using cfg.skill;
using MemoryPack;
using Meow.Runtime.AOT;
using Sirenix.OdinInspector;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 通用异常状态积蓄计算器
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class AbnormalAccrueMagnitude : ModifierMagnitude
    {
        [LabelWidth(100)]
        public int skillDbId;

        [LabelWidth(100)]
        public bool debug;

        public override float CalculateMagnitude(GameEffectSpec spec)
        {
            if (!TbSkillDB.Instance.DataMap.TryGetValue(skillDbId, out var skillDB))
            {
                throw new ArgumentOutOfRangeException($"[AbnormalAccrueMagnitude] 不存在TbSkillDB: {skillDbId}");
            }
            if (!World.Current.TryGetEntityComp(spec.Target.Entity, out MonsterUnitComp monster))
            {
                throw new ArgumentOutOfRangeException($"Entity:{spec.Target.Entity}, 不存在MonsterUnit组件");
            }

            // 对于积蓄值配置<=0的怪物，不生效
            if (!TbMonster.Instance.DataMap.TryGetValue(monster.MonsterTid, out var cfg)
                || cfg.AbnormalAccrueMax <= 0)
            {
                return 0;
            }

            var baseValue = (float)skillDB.ElementAdd;

            baseValue *= 1 + spec.Source.GameAttributeComponent.GetCurrentValue(AttributeId.AbnormalAccrueMult);
            
            AbnormalAccruePipeline.Instance.Process(spec, skillDB.ElementType, baseValue);

            return 0;
        }
    }
}