﻿using System;
using cfg.gas;
using cfg.skill;
using global::cfg.global;
using MemoryPack;
using Meow.Runtime.AOT;
using Sirenix.OdinInspector;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    public enum EValueFrom
    {
        GasValue,
        Float,
        Global_SuperSkillMax,
        SkillDb,
        GasValueLvUp,
    }

    public enum EMagnitudeTarget
    {
        Source,
        Target
    }

    [MemoryPackable]
    [Serializable]
    public sealed partial class SimpleFloatMagnitude : ModifierMagnitude
    {
        [InfoBox(@"1.GasValue: 从GasValue配置中直接读取数据
2.Float: 直接填写浮点数
3.Global_SuperSkillMax: 读取全局配置中的大招最大值
4.GasValueLvUp: 可升级GasValue")]
        [LabelWidth(100)]
        public EValueFrom from = EValueFrom.GasValue;

        // gasValue
        [LabelWidth(100)]
        [ShowIf("@from == EValueFrom.GasValue || from == EValueFrom.GasValueLvUp")]
        public int gasValueId;

        [LabelWidth(100)]
        [ShowIf("@from == EValueFrom.GasValue")]
        public int paramIndex;

        [LabelWidth(100), LabelText("等级来源")]
        [ShowIf("@from == EValueFrom.GasValueLvUp")]
        public EMagnitudeTarget levelFrom = EMagnitudeTarget.Source;

        // float
        [LabelWidth(100)]
        [ShowIf("@from == EValueFrom.Float")]
        public float floatValue;

        [LabelText("乘GE层数")]
        [LabelWidth(100)]
        public bool mulStackCount;

        public override float CalculateMagnitude(GameEffectSpec spec)
        {
            float value;
            switch (from)
            {
                case EValueFrom.GasValue:
                    value = GasValue.GetParam(gasValueId, paramIndex);
                    break;
                case EValueFrom.GasValueLvUp:
                    switch (levelFrom)
                    {
                        case EMagnitudeTarget.Source:
                            value = GasValue.GetLvUpValue(spec.Source.Entity, gasValueId);
                            break;
                        default:
                            value = GasValue.GetLvUpValue(spec.Target.Entity, gasValueId);
                            break;
                    }
                    break;
                case EValueFrom.Global_SuperSkillMax:
                    value = TbGlobal.Instance.SuperSkillMax;
                    break;
                case EValueFrom.SkillDb:
                    GameLog.Error($"[SimpleFloatMagnitude] EValueFrom.SkillDb 已经废弃，改用GasValue");
                    value = 0;
                    break;
                case EValueFrom.Float:
                default:
                    value = floatValue;
                    break;
            }
            var mul = mulStackCount ? spec.StackCount : 1;
            return value * mul;
        }
    }
}