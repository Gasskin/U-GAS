using System;
using cfg.attribute;
using cfg.gas;
using MemoryPack;
using Meow.Runtime.AOT;
using Sirenix.OdinInspector;

namespace Meow.Runtime.HotUpdate
{
    public enum EHpRecoverType
    {
        [LabelText("固定值")]
        FixedValue,

        [LabelText("相对血量")]
        Composite,
    }

    /// <summary>
    /// 血量恢复
    /// </summary>
    [Serializable]
    [MemoryPackable]
    public partial class HpRecoverMagnitude : ModifierMagnitude
    {
        [InfoBox(@"血量恢复
1.如果是固定数值，则直接恢复配置中的数值
2.如果是相对血量，则会恢复目标最大血量的一定比例
此时配置值是最大血量百分比
最大血量可以取自Source或者Target，默认是Target")]
        [LabelWidth(100)]
        public EHpRecoverType type;

        [LabelWidth(100)]
        [ShowIf("@this.type == EHpRecoverType.Composite")]
        public bool fromSource;

        [LabelWidth(100)]
        public bool useFloat;

        [LabelWidth(100)]
        [ShowIf("useFloat")]
        public float floatValue;

        [LabelWidth(100)]
        [HideIf("useFloat")]
        public int gasValueId;

        [LabelWidth(100)]
        [HideIf("useFloat")]
        public int paramIndex;

#if UNITY_EDITOR
        public static bool Debug;
#endif

        public override float CalculateMagnitude(GameEffectSpec spec)
        {
            var value = 0f;
            switch (type)
            {
                case EHpRecoverType.FixedValue:
                    if (useFloat)
                    {
                        value = floatValue;
                    }
                    else
                    {
                        value = GasValue.GetParam(gasValueId, paramIndex);
                    }
                    break;
                case EHpRecoverType.Composite:
                    var from = fromSource ? spec.Source : spec.Target;
                    var ratio = floatValue;
                    if (!useFloat)
                    {
                        ratio = GasValue.GetParam(gasValueId, paramIndex);
                    }
                    value = from.GameAttributeComponent.GetCurrentValue(AttributeId.HpMax)
                            * ratio;
                    break;
            }

#if UNITY_EDITOR
            debugLogger.Clear();
            if (Debug)
            {
                debugLogger.AppendLine($"[HpRecoverMagnitude]");
                debugLogger.AppendLine($"[基础值]");
                debugLogger.AppendLine($"value = {value}");
            }
#endif

            var healAdd = spec.Source.GameAttributeComponent.GetCurrentValue(AttributeId.HealDoneMult);
            value *= healAdd + 1;
#if UNITY_EDITOR
            if (Debug)
            {
                debugLogger.AppendLine($"[治疗加成]");
                debugLogger.AppendLine($"value[{value}] *= 1 + healAdd[{healAdd}]");
            }
#endif

            var beHealAdd = spec.Target.GameAttributeComponent.GetCurrentValue(AttributeId.HealRecvMult);
            value *= beHealAdd + 1;
#if UNITY_EDITOR
            if (Debug)
            {
                debugLogger.AppendLine($"[受治疗加成]");
                debugLogger.AppendLine($"value[{value}] *= 1 + beHealAdd[{beHealAdd}]");
            }
#endif

#if UNITY_EDITOR
            if (Debug)
            {
                GameLog.Info(debugLogger?.ToString());
            }
#endif

            HpRecoverPipeline.Instance.Process(spec, value);

            return 0;
        }

    }
}