using System;
using System.Collections.Generic;
using UnityEngine.Pool;

namespace Meow.Runtime.HotUpdate
{
    public class GameEffectComponent
    {
        // public event Action<EGameEffectDirtyType, GameEffectSpec> OnGameEffectDirty;

        private GameAbilitySystem _owner;
        private readonly List<GameEffectSpec> _gameEffectSpecs = new();

        public void OnStart(GameAbilitySystem owner)
        {
            _owner = owner;
        }

        public void OnStop()
        {
            _owner = null;
        }

        public void Update(float dt)
        {
            var list = ListPool<GameEffectSpec>.Get();
            list.AddRange(_gameEffectSpecs);
            foreach (var spec in list)
            {
                if (spec.IsActive)
                {
                    spec.OnTick(dt);
                }
            }
            ListPool<GameEffectSpec>.Release(list);
        }

        public void GetGameEffectSpecs(List<GameEffectSpec> gameEffectSpecs)
        {
            gameEffectSpecs.Clear();
            gameEffectSpecs.AddRange(_gameEffectSpecs);
        }

        public ulong AddGameEffectSpec(GameEffectSpec spec)
        {
            if (!spec.CanApply())
            {
                AOT.GenericPool<GameEffectSpec>.Release(spec);
                return 0;
            }

            if (spec.IsImmune())
            {
                AOT.GenericPool<GameEffectSpec>.Release(spec);
                return 0;
            }

            if (!GameEffectPipeline.Instance.ProcessOnPreAddGameEffect(spec))
            {
                AOT.GenericPool<GameEffectSpec>.Release(spec);
                return 0;
            }

            spec.Start();
            // 瞬时GE
            if (spec.GameEffect.durationPolicy == EDurationPolicy.Instant)
            {
                spec.OnExecute();
                AOT.GenericPool<GameEffectSpec>.Release(spec);
                return 0;
            }

            if (spec.GameEffect.stack == null)
            {
                throw new ArgumentOutOfRangeException($"GE的Stack为null，AssetId:{spec.GameEffect.assetId}");
            }

            // 不堆叠
            if (spec.GameEffect.stack.stackPolicy == EGameEffectStackPolicy.None)
            {
                // 是否进行总数限制，-1代表不限制
                var limit = spec.GameEffect.stack.totalLimit ? spec.GameEffect.stack.maxCount : -1;
                if (AddNewGameEffectSpec(limit))
                {
                    return spec.Id;
                }
                AOT.GenericPool<GameEffectSpec>.Release(spec);
                return 0;
            }

            GameEffectSpec stackSpec = null;
            foreach (var tSpec in _gameEffectSpecs)
            {
                // 按照来源堆叠，要求ge的来源是同一个人
                // 否则按照目标堆叠，只要ge相同就堆起来就行
                if (spec.GameEffect.stack.stackPolicy == EGameEffectStackPolicy.Source && tSpec.Source != spec.Source)
                {
                    continue;
                }
                if (tSpec.IsValid && tSpec.GameEffect.assetId == spec.GameEffect.assetId)
                {
                    stackSpec = tSpec;
                    break;
                }
            }
            // 不存在，直接新增
            if (stackSpec == null)
            {
                AddNewGameEffectSpec(-1);
                return spec.Id;
            }
            stackSpec.AddStack(1);
            // 堆叠后可以直接释放
            AOT.GenericPool<GameEffectSpec>.Release(spec);
            return stackSpec.Id;

            bool AddNewGameEffectSpec(int totalLimit)
            {
                // 总数检查
                if (totalLimit > 0)
                {
                    var has = 0;
                    for (int i = 0; i < _gameEffectSpecs.Count; i++)
                    {
                        if (_gameEffectSpecs[i].GameEffect.assetId == spec.GameEffect.assetId)
                        {
                            has++;
                            if (has >= totalLimit)
                            {
                                return false;
                            }
                        }
                    }
                }
                _gameEffectSpecs.Add(spec);
                spec.OnAdd();
                GameEffectPipeline.Instance.ProcessOnPostAddNewGameEffect(spec);
                if (spec.CanRunning())
                {
                    spec.OnActive();
                }
                return true;
            }
        }

        public void RemoveGameEffectWithAnyTags(List<string> withTags)
        {
            if (withTags == null || withTags.Count <= 0)
            {
                return;
            }
            var list = ListPool<GameEffectSpec>.Get();
            foreach (var spec in _gameEffectSpecs)
            {
                foreach (var tag in withTags)
                {
                    if (spec.GameEffect.AssetTagsContainer.HasTag(tag))
                    {
                        list.Add(spec);
                    }
                    else if (spec.GameEffect.GrantedTagsContainer.HasTag(tag))
                    {
                        list.Add(spec);
                    }
                }
            }
            foreach (var spec in list)
            {
                InternalRemoveGameEffectSpec(spec);
            }

            ListPool<GameEffectSpec>.Release(list);
        }

        public void InternalRemoveGameEffectSpec(GameEffectSpec spec)
        {
            // 必须先删除，DeActive可能触发TagDirty
            _gameEffectSpecs.Remove(spec);
            spec.OnDeActive();
            spec.OnRemove();
            GameEffectPipeline.Instance.ProcessOnPostRemoveGameEffect(spec);
            AOT.GenericPool<GameEffectSpec>.Release(spec);
        }


        public void OnTagDirty()
        {
            // var dirty = false;
            foreach (var spec in _gameEffectSpecs)
            {
                if (spec.IsActive)
                {
                    if (!spec.CanRunning())
                    {
                        // dirty = true;
                        spec.OnDeActive();
                    }
                }
                else
                {
                    if (spec.CanRunning())
                    {
                        // dirty = true;
                        spec.OnActive();
                    }
                }
            }

            // if (dirty)
            // {
            //     _owner.GameAttributeComponent.OnGameEffectDirty();
            // }
        }

    #region 业务接口
        public GameEffectSpec GetGameEffectSpecByAssetId(ulong id)
        {
            for (int i = 0; i < _gameEffectSpecs.Count; i++)
            {
                var spec = _gameEffectSpecs[i];
                if (spec.GameEffect.assetId == id)
                {
                    return spec;
                }
            }
            return null;
        }

        public void GetGameEffectSpecByAssetId(List<GameEffectSpec> result, GameEffect gameEffect)
        {
            result.Clear();
            for (int i = 0; i < _gameEffectSpecs.Count; i++)
            {
                var spec = _gameEffectSpecs[i];
                if (spec.GameEffect.assetId == gameEffect.assetId)
                {
                    result.Add(spec);
                }
            }
        }

        public void RemoveGameEffectSpecById(ulong id)
        {
            for (int i = 0; i < _gameEffectSpecs.Count; i++)
            {
                var spec = _gameEffectSpecs[i];
                if (spec.Id == id)
                {
                    InternalRemoveGameEffectSpec(spec);
                    break;
                }
            }
        }
        
        public void RemoveGameEffectSpecByAssetId(ulong assetId)
        {
            var list = ListPool<GameEffectSpec>.Get();
            foreach (var spec in _gameEffectSpecs)
            {
                if (spec.GameEffect.assetId == assetId)
                {
                    list.Add(spec);
                }
            }
            foreach (var spec in list)
            {
                InternalRemoveGameEffectSpec(spec);
            }
            ListPool<GameEffectSpec>.Release(list);
        }
        
        public void RemoveStackedGameEffectByAssetId(ulong assetId, int count)
        {
            var list = ListPool<GameEffectSpec>.Get();
            list.AddRange(_gameEffectSpecs);
            for (int i = 0; i < list.Count; i++)
            {
                var spec = list[i];
                if (!spec.GameEffect.IsStackedGameEffect())
                {
                    continue;
                }
                if (spec.GameEffect.assetId == assetId)
                {
                    spec.RemoveStack(count);
                }
            }
            ListPool<GameEffectSpec>.Release(list);
        }
    #endregion
    }
}