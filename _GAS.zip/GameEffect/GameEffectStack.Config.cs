using System;
using MemoryPack;
using Sirenix.OdinInspector;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    public enum EGameEffectStackDurationRefreshPolicy
    {
        None = 0,
        RefreshOnGameEffectApply = 1,
    }
    
    public enum EGameEffectStackExpirePolicy
    {
        RemoveAll = 0,
        RemoveSingleAndRefreshDuration = 1,
        RefreshDuration = 2,
    }
    
    public enum EGameEffectStackPeriodResetPolicy
    {
        None = 0,
        RefreshOnGameEffectApply = 1,
    }
    
    
    public enum EGameEffectStackPolicy
    {
        [LabelText("不堆叠")]
        None = 0,

        [LabelText("来源堆叠")]
        Source = 1,

        [LabelText("目标堆叠")]
        Target = 2,
    }
    
    [MemoryPackable]
    [Serializable]
    public partial class GameEffectStack
    {
        [LabelText("堆叠类型")]
        [LabelWidth(100)]
        public EGameEffectStackPolicy stackPolicy;

        [LabelText("总数限制")]
        [LabelWidth(100)]
        [ShowIf("@stackPolicy == EGameEffectStackPolicy.None")]
        public bool totalLimit;
        
        [LabelText("最大层数")]
        [ShowIf("@stackPolicy != EGameEffectStackPolicy.None || totalLimit")]
        [LabelWidth(100)]
        public int maxCount;

        [LabelText("持续时间刷新")]
        [HideIf("@stackPolicy == EGameEffectStackPolicy.None")]
        [Tooltip(@"添加一层时，刷新这个GE的持续时间")]
        [LabelWidth(100)]
        public EGameEffectStackDurationRefreshPolicy durationRefreshPolicy;

        [LabelText("生效周期重置")]
        [HideIf("@stackPolicy == EGameEffectStackPolicy.None")]
        [Tooltip(@"添加一层时，刷新这个GE的生效周期")]
        [LabelWidth(100)]
        public EGameEffectStackPeriodResetPolicy periodResetPolicy;

        [LabelText("失效策略")]
        [HideIf("@stackPolicy == EGameEffectStackPolicy.None")]
        [Tooltip(@"当GE到期时，如何处理逻辑
1.清空所有层数并删除
2.删除一层，并刷新持续时间
3.刷新持续时间（等于永久生效")]
        [LabelWidth(100)]
        public EGameEffectStackExpirePolicy expirePolicy;
    }
}