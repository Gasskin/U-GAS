using System;
using System.Collections.Generic;
using Meow.Runtime.AOT;
using UnityEngine;
using UnityEngine.Pool;

namespace Meow.Runtime.HotUpdate
{
    public struct GameEffectContext
    {
        // 伤害击中点
        public Vector3 hitPoint;

        // 破刃来源技能
        public int skillDbId;

        // 忽略防御，百分比
        public float defIgnoreRate;

        // 暴击增加,百分比
        public float crit;
    }

    public enum EGameCueDurationalPoint
    {
        None = 0,
        OnAdd,
        OnRemove,
        OnTick,
        OnActive,
        OnDeActive,
    }

    public class GameEffectSpec : IPoolable
    {
        private static ulong s_IdFactory;

        // ge内部会导致很多事件跳转，任何事件触发都可能导致ge失效，所以任何触发事件的代码后，都需要先判断valid再进行代 码执行
        public bool IsValid => Id > 0;
        public GameEffect GameEffect { get; private set; }
        public bool IsActive { get; private set; }

        public ulong Id { get; private set; }

        public GameAbilitySystem Source { get; private set; }

        public GameAbilitySystem Target { get; private set; }

        public GameEffectContext Context { get; private set; }

        public float ActiveTime { get; private set; }

        public float ElapsedTime { get; private set; }

        public int StackCount { get; private set; }

        public float PeriodRemaining { get; private set; }

        public GameEffectSpec PeriodGameEffectSpec { get; private set; }


        private List<GameCueSpec> _cueInstantOnExecute = new();
        private List<GameCueSpec> _cueInstantOnAdd = new();
        private List<GameCueSpec> _cueInstantOnRemove = new();
        private List<GameCueSpec> _cueInstantOnActive = new();
        private List<GameCueSpec> _cueInstantOnDeActive = new();
        private List<GameCueSpec> _cueDurational = new();

        private List<GameAbilitySpec> _grantedAbilities = new();

        public void Init(GameEffect gameEffect, GameAbilitySystem source, GameAbilitySystem target)
        {
            GameEffect = gameEffect;
            IsActive = false;
            Id = ++s_IdFactory;
            Source = source;
            Target = target;
            ActiveTime = 0;
            ElapsedTime = 0;
            StackCount = 1;
            PeriodRemaining = gameEffect.period;
            // Period GameEffect
            if (GameEffect.durationPolicy != EDurationPolicy.Instant
                && GameEffect.periodGameEffect != null)
            {
                if (GameEffect.periodGameEffect.effect.durationPolicy == EDurationPolicy.Instant)
                {
                    PeriodGameEffectSpec = AOT.GenericPool<GameEffectSpec>.Alloc();
                    PeriodGameEffectSpec.Init(GameEffect.periodGameEffect, source, target);
                }
                else
                {
                    throw new InvalidOperationException("Period GameEffect 暂时只支持 Instant");
                }
            }
            // Cue
            InitCue();
        }

        public void Clear()
        {
            GameEffect = null;
            IsActive = true;
            Id = 0;
            Source = null;
            Target = null;
            ActiveTime = 0;
            ElapsedTime = 0;
            StackCount = 1;
            PeriodRemaining = float.MaxValue;
            if (PeriodGameEffectSpec != null)
            {
                AOT.GenericPool<GameEffectSpec>.Release(PeriodGameEffectSpec);
            }
            PeriodGameEffectSpec = null;
            Context = default;
            ClearCue();
            _grantedAbilities.Clear();
        }

        public void Start()
        {
            // period ge
            // SnapShot();
        }

        #region 条件判断
        public bool CanApply()
        {
            if (!IsValid)
            {
                return false;
            }
            if (GameEffect.applyRequiredTags == null)
            {
                return true;
            }
            return Target.GameTagComponent.HasAllTag(GameEffect.applyRequiredTags);
        }

        public bool CanRunning()
        {
            if (!IsValid)
            {
                return false;
            }
            if (GameEffect.ongoingRequiredTags == null)
            {
                return true;
            }
            return Target.GameTagComponent.HasAllTag(GameEffect.ongoingRequiredTags);
        }

        public bool IsImmune()
        {
            if (!IsValid)
            {
                return true;
            }
            // 判断自身是否被免疫
            if (GameEffect.immuneTags != null && Target.GameTagComponent.HasAnyTag(GameEffect.immuneTags))
            {
                return true;
            }
            // 判断是否被其他GE阻挡
            var flag = false;
            var list = ListPool<GameEffectSpec>.Get();
            Target.GameEffectComponent.GetGameEffectSpecs(list);
            for (int i = 0; i < list.Count; i++)
            {
                var spec = list[i];
                if (GameEffect.assetTags != null
                    && spec.GameEffect.BlockGameWithTagsContainer.HasAnyTags(GameEffect.assetTags))
                {
                    flag = true;
                    break;
                }
                if (GameEffect.grantedTags != null
                    && spec.GameEffect.BlockGameWithTagsContainer.HasAnyTags(GameEffect.grantedTags))
                {
                    flag = true;
                    break;
                }
            }
            ListPool<GameEffectSpec>.Release(list);
            return flag;
        }
        #endregion

        private void SnapShot()
        {
        }

        public void SetContext(GameEffectContext ctx)
        {
            Context = ctx;
        }

        #region 生命周期
        public void OnExecute()
        {
            TriggerCueInstant(_cueInstantOnExecute);
            Target.ApplyModFromInstantGameEffect(this);
            if (IsValid)
            {
                // ge是可能导致自身被移除
                // 比如当一个GE被移除时，会移除他的period ge
                Target.GameEffectComponent.RemoveGameEffectWithAnyTags(GameEffect.removeGameEffectsWithTags);
            }
        }

        public void OnTick(float dt)
        {
            if (GameEffect.durationPolicy == EDurationPolicy.Instant)
            {
                return;
            }
            TriggerCueDurational(EGameCueDurationalPoint.OnTick, dt);

            TickPeriod(dt);

            if (!IsValid)
            {
                return;
            }

            TickDuration();

            ElapsedTime += dt;
        }

        public void OnAdd()
        {
            TriggerCueInstant(_cueInstantOnAdd);
            TriggerCueDurational(EGameCueDurationalPoint.OnAdd);
            Target.GameAttributeComponent.OnGameEffectDirty();
            if (IsValid)
            {
                if (GameEffect.grantedAbility is { Count: > 0 })
                {
                    for (int i = 0; i < GameEffect.grantedAbility.Count; i++)
                    {
                        var ability = GameEffect.grantedAbility[i];
                        if (ability.CanAdd(Target))
                        {
                            var spec = Target.GameAbilityComponent.AddGameAbilityByGameEffect(this, ability);
                            _grantedAbilities.Add(spec);
                        }
                    }
                }
            }
        }

        public void OnRemove()
        {
            TriggerCueInstant(_cueInstantOnRemove);
            TriggerCueDurational(EGameCueDurationalPoint.OnRemove);
            Target.GameAttributeComponent.OnGameEffectDirty();
            if (IsValid)
            {
                if (_grantedAbilities is { Count: > 0 })
                {
                    for (int i = 0; i < _grantedAbilities.Count; i++)
                    {
                        var spec = _grantedAbilities[i];
                        Target.GameAbilityComponent.RemoveGameAbility(spec);
                    }
                    _grantedAbilities.Clear();
                }
            }
        }

        public void OnActive()
        {
            if (IsActive)
            {
                return;
            }
            IsActive = true;
            ActiveTime = Time.time;

            TriggerCueInstant(_cueInstantOnActive);
            TriggerCueDurational(EGameCueDurationalPoint.OnActive);
            Target.GameTagComponent.AddTagsWithDirty(GameEffect.grantedTags);

            if (IsValid)
            {
                Target.GameAttributeComponent.OnGameEffectDirty();
            }

            if (IsValid)
            {
                Target.GameEffectComponent.RemoveGameEffectWithAnyTags(GameEffect.removeGameEffectsWithTags);
            }

            if (IsValid)
            {
                if (_grantedAbilities is { Count: > 0 })
                {
                    for (int i = 0; i < _grantedAbilities.Count; i++)
                    {
                        _grantedAbilities[i].Active();
                    }
                }
            }
        }


        public void OnDeActive()
        {
            if (!IsActive)
            {
                return;
            }
            IsActive = false;
            TriggerCueInstant(_cueInstantOnDeActive);
            TriggerCueDurational(EGameCueDurationalPoint.OnDeActive);
            Target.GameTagComponent.RemoveTagsWithDirty(GameEffect.grantedTags);

            if (IsValid)
            {
                Target.GameAttributeComponent.OnGameEffectDirty();
            }

            if (IsValid)
            {
                if (_grantedAbilities is { Count: > 0 })
                {
                    for (int i = 0; i < _grantedAbilities.Count; i++)
                    {
                        _grantedAbilities[i].DeActive();
                    }
                }
            }
        }
        #endregion

        #region 计时
        private void TickPeriod(float dt)
        {
            if (PeriodGameEffectSpec == null || GameEffect.period <= 0)
            {
                return;
            }

            // 警告：如果配置的period间隔太小的话，这里会存在问题
            // 首帧保护，runningTime如果是一个极小值，可能会有浮点数精度问题，干脆第一帧不进行逻辑运算
            var runningTime = Time.time - ActiveTime;
            if (runningTime < Mathf.Epsilon)
            {
                return;
            }

            // 如果运行时间超过了duration，那么计算period时，我们只计算duration内的那一部分
            if (GameEffect.durationPolicy == EDurationPolicy.Duration)
            {
                var outDuration = runningTime - GameEffect.duration;
                if (outDuration >= 0)
                {
                    // 此时应该是最后一次执行
                    dt -= outDuration;
                    // 避免误差, 保证最后一次边界得到执行
                    dt += 0.0001f;
                }
            }

            PeriodRemaining -= dt;

            // period触发的行为可能导致所属的GE(_spec)失活/移除, 所属GE移除时会将_spec设置为null
            while (PeriodRemaining < 0 && IsValid && IsActive)
            {
                // 不能直接重置为Period, 这将累计误差
                PeriodRemaining += GameEffect.period;
                PeriodGameEffectSpec?.OnExecute();
                // 触发周期执行事件
                if (PeriodGameEffectSpec != null)
                {
                    GameEffectPipeline.Instance.ProcessOnPeriodExecute(this, PeriodGameEffectSpec);
                }
            }
        }

        private void TickDuration()
        {
            if (GameEffect.durationPolicy != EDurationPolicy.Duration)
            {
                return;
            }

            var remaining = GameEffect.duration - ElapsedTime;
            if (remaining > 0)
            {
                return;
            }

            if (GameEffect.stack.stackPolicy == EGameEffectStackPolicy.None)
            {
                Target.GameEffectComponent.InternalRemoveGameEffectSpec(this);
            }
            else
            {
                switch (GameEffect.stack.expirePolicy)
                {
                    case EGameEffectStackExpirePolicy.RemoveAll:
                        {
                            Target.GameEffectComponent.InternalRemoveGameEffectSpec(this);
                            break;
                        }
                    case EGameEffectStackExpirePolicy.RefreshDuration:
                        {
                            RefreshDuration();
                            break;
                        }
                    case EGameEffectStackExpirePolicy.RemoveSingleAndRefreshDuration:
                        {
                            RemoveStack(1);
                            break;
                        }
                }
            }
        }
        #endregion

        #region 堆叠
        public void AddStack(int count)
        {
            var refreshDuration =
                GameEffect.stack.durationRefreshPolicy == EGameEffectStackDurationRefreshPolicy.RefreshOnGameEffectApply;
            var refreshPeriod =
                GameEffect.stack.periodResetPolicy == EGameEffectStackPeriodResetPolicy.RefreshOnGameEffectApply;
            SetStackCount(StackCount + count, refreshDuration, refreshPeriod);
        }

        public void RemoveStack(int count)
        {
            if (count >= StackCount)
            {
                Target.GameEffectComponent.InternalRemoveGameEffectSpec(this);
            }
            else
            {
                var nowCount = StackCount - count;
                var refresh =
                    GameEffect.stack.expirePolicy == EGameEffectStackExpirePolicy.RemoveSingleAndRefreshDuration;
                SetStackCount(nowCount, refresh, false);
            }
        }

        private void SetStackCount(int count, bool refreshDuration, bool refreshPeriod)
        {
            if (count <= 0)
            {
                return;
            }

            var oldCount = StackCount;

            if (count <= GameEffect.stack.maxCount)
            {
                // 更新栈数 最小层数为1
                StackCount = count;
                // 是否刷新Duration
                if (refreshDuration)
                {
                    RefreshDuration();
                }
                // 是否重置Period
                if (refreshPeriod)
                {
                    PeriodRemaining = GameEffect.period;
                }
            }
            else
            {
                if (IsValid)
                {
                    if (refreshDuration)
                    {
                        RefreshDuration();
                    }
                }
            }

            // 层数减少
            if (oldCount > StackCount)
            {
                Target.GameAttributeComponent.OnGameEffectDirty();
            }
            // 层数增加
            else if (oldCount < StackCount)
            {
                Target.GameAttributeComponent.OnGameEffectDirty();
            }
        }

        private void RefreshDuration()
        {
            ActiveTime = Time.time;
            ElapsedTime = 0.0f;
        }

        public void AddDuration(float add)
        {
            ElapsedTime -= add;
        }
        #endregion

        #region Cue
        private void TriggerCueInstant(List<GameCueSpec> gameCues)
        {
            for (int i = 0; i < gameCues.Count; i++)
            {
                var cue = gameCues[i];
                if (cue is IGameCueInstant cueInstant)
                {
                    cueInstant.OnTrigger();
                }
            }
        }

        private void TriggerCueDurational(EGameCueDurationalPoint point, float dt = 0)
        {
            for (int i = 0; i < _cueDurational.Count; i++)
            {
                var cue = _cueDurational[i];
                if (cue is IGameCueDurational cueDurational)
                {
                    switch (point)
                    {
                        case EGameCueDurationalPoint.OnAdd:
                            cueDurational.OnAdd();
                            break;
                        case EGameCueDurationalPoint.OnRemove:
                            cueDurational.OnRemove();
                            break;
                        case EGameCueDurationalPoint.OnTick:
                            cueDurational.OnTick(dt);
                            break;
                        case EGameCueDurationalPoint.OnActive:
                            cueDurational.OnActive();
                            break;
                        case EGameCueDurationalPoint.OnDeActive:
                            cueDurational.OnDeActive();
                            break;
                    }
                }
            }
        }

        private void InitCue()
        {
            if (GameEffect.cueInstantOnExecute is { Count: > 0 })
            {
                foreach (var cue in GameEffect.cueInstantOnExecute)
                {
                    _cueInstantOnExecute.Add(cue.CreateSpec(this));
                }
            }
            if (GameEffect.cueInstantOnAdd is { Count: > 0 })
            {
                foreach (var cue in GameEffect.cueInstantOnAdd)
                {
                    _cueInstantOnAdd.Add(cue.CreateSpec(this));
                }
            }
            if (GameEffect.cueInstantOnRemove is { Count: > 0 })
            {
                foreach (var cue in GameEffect.cueInstantOnRemove)
                {
                    _cueInstantOnRemove.Add(cue.CreateSpec(this));
                }
            }
            if (GameEffect.cueInstantOnActive is { Count: > 0 })
            {
                foreach (var cue in GameEffect.cueInstantOnActive)
                {
                    _cueInstantOnActive.Add(cue.CreateSpec(this));
                }
            }
            if (GameEffect.cueInstantOnDeActive is { Count: > 0 })
            {
                foreach (var cue in GameEffect.cueInstantOnDeActive)
                {
                    _cueInstantOnDeActive.Add(cue.CreateSpec(this));
                }
            }
            if (GameEffect.cueDurational is { Count: > 0 })
            {
                foreach (var cue in GameEffect.cueDurational)
                {
                    _cueDurational.Add(cue.CreateSpec(this));
                }
            }
        }

        private void ClearCue()
        {
            void ClearInternal(List<GameCueSpec> specs)
            {
                for (int i = 0; i < specs.Count; i++)
                {
                    GameCueSpec.Release(specs[i]);
                }
                specs.Clear();
            }

            ClearInternal(_cueInstantOnExecute);
            ClearInternal(_cueInstantOnAdd);
            ClearInternal(_cueInstantOnRemove);
            ClearInternal(_cueInstantOnActive);
            ClearInternal(_cueInstantOnDeActive);
            ClearInternal(_cueDurational);
        }
        #endregion

    #region 业务
        public float GetRemainingPercentage()
        {
            if (GameEffect.durationPolicy != EDurationPolicy.Duration)
            {
                return 1.0f;
            }
            var left = 1f - Mathf.Min(ElapsedTime / GameEffect.duration, 1f);
            return Mathf.Max(left, 0f);
        }
    #endregion
    }
}