using MemoryPack;
using UnityEngine;
using Meow.Runtime.HotUpdate.BattleConfig;
using System;
using System.Collections.Generic;
using System.Linq;
using Sirenix.OdinInspector;

namespace Meow.Runtime.HotUpdate
{
    [MemoryPackable]
    [Serializable]
    public sealed partial class GameEffectObjectField
    {
        [HideInInspector]
        public GameEffect effect;
        [SerializeField]
        [HideLabel]
        private GameEffectWrap _wrap;

        [MemoryPackOnSerializing]
        private void OnSerializing()
        {
            if (_wrap == null)
            {
                effect = null;
                return;
            }
            effect = _wrap.data;
        }

        // impicit
        public static implicit operator GameEffect(GameEffectObjectField field)
        {
            return field.effect;
        }
    }
}