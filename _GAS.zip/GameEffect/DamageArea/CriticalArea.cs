using System;
using System.Text;
using cfg.attribute;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 暴击乘区 （伤害，暴击次数，暴击伤害）
    /// 多段伤害每一段的暴击独立计算，且暴击一次就算这次伤害暴击
    /// </summary>
    public static class CriticalArea
    {
        public static (float, int, float) Process(float damage, GameEffectSpec spec, int hit, StringBuilder logger = null)
        {
            var finalDamage = 0f;
            var originalBaseDamage = damage / hit;
            
            var critRate = spec.Source.GameAttributeComponent.GetCurrentValue(AttributeId.CritRate)  + spec.Context.crit;
            var critDmg = spec.Source.GameAttributeComponent.GetCurrentValue(AttributeId.CritDamageRate);
            var critNum = 0;
            
            for (int i = 0; i < hit; i++)
            {
                var baseDamage = originalBaseDamage;
                if (World.Current.GetSystem<RandomService>().RandomProbability(critRate))
                {
                    baseDamage *= critDmg;
                    critNum++;
                }
                finalDamage += baseDamage;
            }
#if UNITY_EDITOR
            logger?.AppendLine("【暴击】");
            logger?.AppendLine($"baseDamage[{originalBaseDamage}] = originalDamage[{damage}]/hit[{hit}]");
            logger?.AppendLine($"finalDamage = {finalDamage}, critB[{critDmg}], critNum[{critNum}]"); 
#endif
            return (finalDamage, critNum, critDmg);
        }
    }
}