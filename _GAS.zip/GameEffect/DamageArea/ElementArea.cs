using System.Text;
using cfg.attribute;
using cfg.hero;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    /// 元素抗性
    /// out = input * (1 - 抗性加成 + 抗性穿透)
    ///     至少为1
    public static class ElementArea
    {
        public static float Process(float damage, GameEffectSpec spec, Element element, StringBuilder logger = null)
        {
            if (element == Element.None)
            {
#if UNITY_EDITOR
                logger?.AppendLine("【元素抗性】");
                logger?.AppendLine("该伤害没有元素类型");
#endif
                return damage;
            }
            var red = element switch
            {
                Element.Light => spec.Target.GameAttributeComponent.GetCurrentValue(AttributeId.LightDefIgnore),
                Element.Void => spec.Target.GameAttributeComponent.GetCurrentValue(AttributeId.VoidDefIgnore),
                Element.Time => spec.Target.GameAttributeComponent.GetCurrentValue(AttributeId.TimeDefIgnore),
                Element.Energy => spec.Target.GameAttributeComponent.GetCurrentValue(AttributeId.EnergyDefIgnore),
                Element.Create => spec.Target.GameAttributeComponent.GetCurrentValue(AttributeId.CreateDefIgnore),
                Element.Dark => spec.Target.GameAttributeComponent.GetCurrentValue(AttributeId.DarkDefIgnore),
                Element.Space => spec.Target.GameAttributeComponent.GetCurrentValue(AttributeId.SpaceDefIgnore),
                _ => 0,
            };
            var add = element switch
            {
                Element.Light => spec.Source.GameAttributeComponent.GetCurrentValue(AttributeId.LightDef),
                Element.Void => spec.Source.GameAttributeComponent.GetCurrentValue(AttributeId.VoidDef),
                Element.Time => spec.Source.GameAttributeComponent.GetCurrentValue(AttributeId.TimeDef),
                Element.Energy => spec.Source.GameAttributeComponent.GetCurrentValue(AttributeId.EnergyDef),
                Element.Create => spec.Source.GameAttributeComponent.GetCurrentValue(AttributeId.CreateDef),
                Element.Dark => spec.Source.GameAttributeComponent.GetCurrentValue(AttributeId.DarkDef),
                Element.Space => spec.Source.GameAttributeComponent.GetCurrentValue(AttributeId.SpaceDef),
                _ => 0,
            };

            var allRed = spec.Target.GameAttributeComponent.GetCurrentValue(AttributeId.AllElementDefIgnore);
            var allAdd = spec.Source.GameAttributeComponent.GetCurrentValue(AttributeId.AllElementDef);

            damage *= 1 - red + add - allRed + allAdd;
            damage = Mathf.Max(damage, 1);

#if UNITY_EDITOR
            logger?.AppendLine("【元素抗性】");
            logger?.AppendLine($"damage[{damage}][{element}] *= 1 - elementAdd[{red}] +  elementMinus[{add}]");
#endif
            return damage;
        }
    }
}