using System.Text;
using cfg.attribute;

namespace Meow.Runtime.HotUpdate
{
    /// 破韧增伤
    /// out = input * (1 + 破韧增伤)
    public static class BreakArea
    {
        public static float Process(float damage, GameEffectSpec spec, StringBuilder logger = null)
        {
            var breakDmg = spec.Target.GameAttributeComponent.GetCurrentValue(AttributeId.BreakMultFinal);
            damage *= 1 + breakDmg;

#if UNITY_EDITOR
            logger?.AppendLine("【破韧增伤】");
            logger?.AppendLine($"damage[{damage}] *= 1 + breakAdd[{breakDmg}]");
#endif
            return damage;
        }
        
    }
}