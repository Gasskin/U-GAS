using System.Text;
using cfg.attribute;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 属性精通
    /// out = i * (1 + 精通)
    /// </summary>
    public class AbnormalArea
    {
        public static float Process(float damage, GameEffectSpec spec, StringBuilder logger = null)
        {
            var add = spec.Source.GameAttributeComponent.GetCurrentValue(AttributeId.AbnormalDamageMult);
            damage *= 1 + add;

#if UNITY_EDITOR
            logger?.AppendLine("【属性精通】");
            logger?.AppendLine($"damage[{damage}] *= 1 + abnormalAdd[{add}]");
#endif
            return damage;
        }
    }
}