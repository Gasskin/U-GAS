using System.Text;
using cfg.attribute;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{   
    // 额外增减伤
    // out = input * (1 + 增伤 - 减伤)
    //     至少为1
    public static class ExtraAddArea
    {
        public static float Process(float damage, GameEffectSpec spec, StringBuilder logger = null)
        {
            var add = spec.Source.GameAttributeComponent.GetCurrentValue(AttributeId.DamageInc);
            var minus = spec.Target.GameAttributeComponent.GetCurrentValue(AttributeId.DamageRed);
            damage *= 1 + add - minus;
            damage = Mathf.Max(damage, 1);

#if UNITY_EDITOR
            logger?.AppendLine("【额外增减伤】");
            logger?.AppendLine($"damage[{damage}] *= 1 + add[{add}] - minus[{minus}]");
#endif
            return damage;
        }
    }
}