using System.Text;
using cfg.attribute;

namespace Meow.Runtime.HotUpdate
{
    /// 易伤
    /// out = input * (1 + 易伤)
    public static class DamageFixArea
    {
        public static float Process(float damage, GameEffectSpec spec, StringBuilder logger = null)
        {
            var dmgFix = spec.Target.GameAttributeComponent.GetCurrentValue(AttributeId.WeakMult);
            damage *= 1 + dmgFix;

#if UNITY_EDITOR
            logger?.AppendLine("【易伤】");
            logger?.AppendLine($"damage[{damage}] *= 1 + dmgFix[{dmgFix}]");
#endif
            return damage;
        }
    }
}