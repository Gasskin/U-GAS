using System;
using System.Text;
using cfg.attribute;
using global::cfg.global;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    /// out = input * 防御承伤比例
    ///     输出至少为1
    /// C = 来源等级 * a + b
    ///     a,b是TbSkillGlobal中配置的常量10004和10005
    /// 防御 = 当前防御 * (1-忽略防御率) - 忽略防御值
    /// 防御承伤比 = C / (防御 + C)
    public static class DefenceArea
    {
        public static float Process(float damage, GameEffectSpec spec, StringBuilder logger = null)
        {
            var roleLv = 1;
            if (!World.Current.TryGetEntityComp(spec.Source.Entity, out FeatureComp featureComp))
            {
                throw new ArgumentOutOfRangeException($"Entity[{spec.Source.Entity}] 不存在 FeatureComp 组件");
            }
            roleLv = featureComp.Level;
            var c = roleLv * TbGlobal.Instance.DefCoefficientA + TbGlobal.Instance.DefCoefficientB;
            var nowDef = spec.Target.GameAttributeComponent.GetCurrentValue(AttributeId.DefFinal);
            var ignoreDef1 = spec.Source.GameAttributeComponent.GetCurrentValue(AttributeId.DefIgnoreRate);
            var ignoreDef2 = spec.Source.GameAttributeComponent.GetCurrentValue(AttributeId.DefIgnore);
            var def = nowDef * (1 - ignoreDef1 - spec.Context.defIgnoreRate) - ignoreDef2;
            var defRate = c / (def + c);
            damage *= defRate;
            damage = Mathf.Max(damage, 1);

#if UNITY_EDITOR
            if (logger != null)
            {
                logger.AppendLine("【防御】");
                logger.AppendLine($"c[{c}] = roleLv[{roleLv}] * DefA[{TbGlobal.Instance.DefCoefficientA}] + DefB[{TbGlobal.Instance.DefCoefficientB}]");
                logger.AppendLine($"def[{def}] = nowDef[{nowDef}] * (1 - IgnRate[{ignoreDef1}] - defIgnore[{spec.Context.defIgnoreRate}]) - Ign[{ignoreDef2}]");
                logger.AppendLine($"defRate[{defRate}] = c[{c}] / (def[{def}] + c[{c}])");
                logger.AppendLine($"damage[{damage}] *= defRate[{defRate}]");
            }
#endif
            
            return damage;
        }
    }
}