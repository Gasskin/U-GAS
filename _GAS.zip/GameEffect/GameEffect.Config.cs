using System.Collections.Generic;
using MemoryPack;
using Sirenix.OdinInspector;
using UnityEngine;
using System.Buffers;
using Meow.Runtime.HotUpdate.BattleConfig;
using System;
using cfg.attribute;
using Time = cfg.skill.Time;

namespace Meow.Runtime.HotUpdate
{
    public enum EDurationPolicy
    {
        [LabelText("瞬时")]
        Instant = 0,

        [LabelText("永久")]
        Infinite = 1,

        [LabelText("限时")]
        Duration = 2,
    }

    [MemoryPackable]
    public sealed partial class GameEffect : SerializableConfig
    {
        [NonSerialized]
        public ulong assetId;

        [Title("<备注>")]
        [HideLabel]
        [TextArea]
        public string backUp;

        [Title("<关联GasValue>")]
        [HideLabel]
        [InfoBox("注意，已配置GasValueId，部分数据将从Excel中读取", InfoMessageType.Warning, "@gasValueId > 0")]
        public int gasValueId;

        [Title("<类型>")]
        [LabelText("持续类型")]
        [LabelWidth(80)]
        [Tooltip("1.瞬时：释放GE时立刻生效1次，随后立刻删除，此时持续时间与生效周期没有意义\n\n" +
                 "2.永久：释放GE时立刻生效1次，随后每个生效周期生效1次，生效周期为0时仅生效1次\n\n" +
                 "3.限时：释放GE时立刻生效1次，随后每个生效周期生效1次，到达持续时间后删除")]
        public EDurationPolicy durationPolicy;


        [LabelText("持续时间")]
        [HideIf("@this.durationPolicy != EDurationPolicy.Duration")]
        [LabelWidth(80)]
        public float duration;

        [LabelText("周期效果")]
        [LabelWidth(80)]
        [HideIf("@this.durationPolicy == EDurationPolicy.Instant")]
        public GameEffectObjectField periodGameEffect;

        [LabelText("生效周期")]
        [LabelWidth(80)]
        [Range(0.1f, 100)]
        [HideIf("@this.durationPolicy == EDurationPolicy.Instant")]
        public float period = 0.1f;

        [Title("<标签>")]
        [ValueDropdown("@GameTagDropdownHelper.GetTagDropdown()", IsUniqueList = true)]
        [Tooltip("该GE的标签，判断移除GE时，会采用这个标签作为依据")]
        [InfoBox("GameEffect至少需要一个Effect_X的AssetTag", InfoMessageType.Error, "@assetTags.Count <= 0")]
        public List<string> assetTags = new List<string>();

        [ValueDropdown("@GameTagDropdownHelper.GetTagDropdown()", IsUniqueList = true)]
        [Tooltip("该GE会附加的标签，生效时添加，失效时移除")]
        public List<string> grantedTags = new List<string>();

        [ValueDropdown("@GameTagDropdownHelper.GetTagDropdown()", IsUniqueList = true)]
        [Tooltip("应用该GE所必须的标签，必须拥有全部标签才可以应用该GE")]
        public List<string> applyRequiredTags = new List<string>();

        [ValueDropdown("@GameTagDropdownHelper.GetTagDropdown()", IsUniqueList = true)]
        [Tooltip("表示该GE处于可激活的标签")]
        public List<string> ongoingRequiredTags = new List<string>();

        [ValueDropdown("@GameTagDropdownHelper.GetTagDropdown()", IsUniqueList = true)]
        [Tooltip("免疫该GE的标签，只要存在任一标签则不可应用该GE")]
        public List<string> immuneTags = new List<string>();

        [ValueDropdown("@GameTagDropdownHelper.GetTagDropdown()", IsUniqueList = true)]
        [Tooltip("GE生效时移除含有以下任一标签的其他GE，周期性GE每次生效都会尝试删除其他")]
        public List<string> removeGameEffectsWithTags = new List<string>();

        [ValueDropdown("@GameTagDropdownHelper.GetTagDropdown()", IsUniqueList = true)]
        [Tooltip("阻止拥有任一标签的其他GE被添加")]
        public List<string> blockGameEffectsWithTags = new List<string>();

        /*[Title("<快照>")]
        [LabelText("TODO")]
        [LabelWidth(80)]
        public bool needSnapShot;*/

        [Title("<堆叠>")]
        [HideLabel]
        [InlineProperty]
        public GameEffectStack stack = new();

        [Title("<瞬时视效>")]
        [LabelText("OnExecute")]
        [LabelWidth(80)]
        public List<GameCue> cueInstantOnExecute = new List<GameCue>();

        [LabelText("OnAdd")]
        [LabelWidth(80)]
        public List<GameCue> cueInstantOnAdd = new List<GameCue>();

        [LabelText("OnRemove")]
        [LabelWidth(80)]
        public List<GameCue> cueInstantOnRemove = new List<GameCue>();

        [LabelText("OnActive")]
        [LabelWidth(80)]
        public List<GameCue> cueInstantOnActive = new List<GameCue>();

        [LabelText("OnDeActive")]
        [LabelWidth(80)]
        public List<GameCue> cueInstantOnDeActive = new List<GameCue>();

        [Title("<持续视效>")]
        [LabelWidth(80)]
        public List<GameCue> cueDurational = new List<GameCue>();

        [Title("<属性修饰器>")]
        [InlineProperty]
        public List<GameEffectModifier> modifiers = new List<GameEffectModifier>();

        [Title("<附加能力>")]
        [HideLabel]
        [LabelWidth(80)]
        [SerializeReference]
        public List<GameAbility> grantedAbility = new List<GameAbility>();

#if UNITY_EDITOR
        [Title("<编辑器辅助函数>")]
        [Button]
        public void SetSkillDamage(int skillDbId)
        {
            modifiers.Clear();
            // 减少韧性值
            modifiers.Add(new GameEffectModifier()
            {
                attribute = AttributeId.NowTough,
                operation = EModifierOperation.Minus,
                magnitude = new ToughnessReduceMagnitude()
                {
                    skillDbId = skillDbId
                }
            });
            // 异常积蓄
            modifiers.Add(new GameEffectModifier()
            {
                attribute = AttributeId.NowVoidAccrue,
                operation = EModifierOperation.Add,
                magnitude = new AbnormalAccrueMagnitude()
                {
                    skillDbId = skillDbId
                }
            });
            // 伤害
            modifiers.Add(new GameEffectModifier()
            {
                attribute = AttributeId.NowHp,
                operation = EModifierOperation.Minus,
                magnitude = new CommonSkillDamageMagnitude()
                {
                    skillDbId = skillDbId
                }
            });
        }

        [Button]
        public void SetSkillEnergyRecover(Time time = Time.Hit, int skillDbId = 0)
        {
            modifiers.Clear();
            modifiers.Add(new GameEffectModifier()
            {
                attribute = AttributeId.PersonalEnergy,
                operation = EModifierOperation.Add,
                magnitude = new EnergyRecoverMagnitude()
                {
                    timing = time,
                    skillDbId = skillDbId
                }
            });
        }
#endif
    }
}