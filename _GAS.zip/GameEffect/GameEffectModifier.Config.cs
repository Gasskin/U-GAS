using System;
using cfg.attribute;
using MemoryPack;
using Meow.Runtime.AOT;
using Sirenix.OdinInspector;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    public enum EModifierOperation
    {
        None = -1,
        
        [LabelText("加")]
        Add = 0,

        [LabelText("减")]
        Minus = 1,

        [LabelText("乘")]
        Multiply = 2,

        [LabelText("除")]
        Divide = 3,

        [LabelText("替")]
        Override = 4,
    }

    [MemoryPackable]
    [Serializable]
    public sealed partial class GameEffectModifier
    {
        [LabelText("目标属性")]
        [LabelWidth(80)]
        public AttributeId attribute;

        [LabelText("操作类型")]
        [LabelWidth(80)]
        public EModifierOperation operation;

        [LabelText("计算器")]
        [LabelWidth(80)]
        [SerializeReference]
        public ModifierMagnitude magnitude;

    }
}