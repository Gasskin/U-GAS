using cfg.gas;
using MemoryPack;
using Meow.Runtime.AOT;
using Sirenix.OdinInspector;

namespace Meow.Runtime.HotUpdate
{
    public partial class GameEffect
    {
        [MemoryPackIgnore] public GameTagsContainer AssetTagsContainer { get; private set; } = new();
        [MemoryPackIgnore] public GameTagsContainer GrantedTagsContainer { get; private set; } = new();
        [MemoryPackIgnore] public GameTagsContainer BlockGameWithTagsContainer { get; private set; } = new();

        public GameEffectSpec CreateSpec(GameAbilitySystem source, GameAbilitySystem target)
        {
            AssetTagsContainer.InitTags(assetTags);
            GrantedTagsContainer.InitTags(grantedTags);
            BlockGameWithTagsContainer.InitTags(blockGameEffectsWithTags);

            TryInitGasValue();
            var spec = GenericPool<GameEffectSpec>.Alloc();
            spec.Init(this, source, target);
            return spec;
        }

        public bool IsStackedGameEffect()
        {
            return stack != null
                   && stack.stackPolicy != EGameEffectStackPolicy.None;
        }


        private void TryInitGasValue()
        {
            if (gasValueId <= 0)
            {
                return;
            }
            if (!TbGasValue.Instance.DataMap.TryGetValue(gasValueId, out var cfg))
            {
                return;
            }
            // 持续时间 & 生效周期
            durationPolicy = EDurationPolicy.Instant;
            switch (cfg.DurationType)
            {
                case 1:
                    durationPolicy = EDurationPolicy.Infinite;
                    break;
                case 2:
                    durationPolicy = EDurationPolicy.Duration;
                    duration = cfg.DurationTime;
                    break;
            }
            period = cfg.DurationPeriod;
            // 堆叠
            stack.stackPolicy = EGameEffectStackPolicy.None;
            if (cfg.StackType == 0 && cfg.StackMaxCount > 0)
            {
                stack.totalLimit = true;
            }
            else
            {
                stack.totalLimit = false;
                switch (cfg.StackType)
                {
                    case 1:
                        stack.stackPolicy = EGameEffectStackPolicy.Source;
                        break;
                    case 2:
                        stack.stackPolicy = EGameEffectStackPolicy.Target;
                        break;
                }
            }
            stack.maxCount = cfg.StackMaxCount;
        }

        [Button]
        [HideInEditorMode]
        public void TestApply()
        {
#if UNITY_EDITOR
            var e = World.Current.GetSystem<BattleTeamSystem>().ActiveRoleEntity;
            if (World.Current.TryGetEntityComp(e, out GameAbilitySystem gas))
            {
                var ge = new GameEffect();
                ge.assetId = assetId;
                ge.backUp = backUp;
                ge.gasValueId = gasValueId;
                ge.durationPolicy = durationPolicy;
                ge.duration = duration;
                ge.period = period;
                ge.assetTags = assetTags;
                ge.grantedTags = grantedTags;
                ge.applyRequiredTags = applyRequiredTags;
                ge.ongoingRequiredTags = ongoingRequiredTags;
                ge.immuneTags = immuneTags;
                ge.removeGameEffectsWithTags = removeGameEffectsWithTags;
                ge.blockGameEffectsWithTags = blockGameEffectsWithTags;
                // ge.needSnapShot = needSnapShot;
                ge.stack = stack;
                ge.cueInstantOnExecute = cueInstantOnExecute;
                ge.cueInstantOnAdd = cueInstantOnAdd;
                ge.cueInstantOnRemove = cueInstantOnRemove;
                ge.cueInstantOnActive = cueInstantOnActive;
                ge.cueDurational = cueDurational;
                ge.modifiers = modifiers;
                ge.grantedAbility = grantedAbility;
                gas.ApplyGameEffectTo(ge, gas);
            }
#endif
        }
    }
}