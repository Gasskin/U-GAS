using System;
using System.Collections.Generic;
using cfg.attribute;
using Meow.Runtime.AOT;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// SkillStageTrigger.Start【技能Timeline开始前】 ---> MakeGameEffect
    /// SkillStageTrigger.Hit【技能命中前】 ---> ApplyGameEffect
    /// GameEffectPipeline -> DamagePipeline、HpRecoverPipeline...
    /// SkillStageTrigger.PostHit【技能命中后】    
    /// </summary>
    public partial class GameAbilitySystem : EntityComp
    {
        // 全局角色
        public const int K_GLOBAL_ENTITY = -1;
        
        public GameEffectComponent GameEffectComponent { get; private set; } = new();

        public GameTagComponent GameTagComponent { get; private set; } = new();

        public GameAttributeComponent GameAttributeComponent { get; private set; } = new();

        public GameAbilityComponent GameAbilityComponent { get; private set; } = new();

        private int _tId;
        private readonly Dictionary<AttributeId, float> _initAttrs;

        public GameAbilitySystem(int tid, Dictionary<AttributeId, float> initAttrs)
        {
            _tId = tid;
            _initAttrs = initAttrs;
        }

        protected override void OnStart()
        {
            GameEffectComponent.OnStart(this);
            GameTagComponent.OnStart(this);
            GameAttributeComponent.OnStart(this, _initAttrs);
            GameAbilityComponent.OnStart(this, _tId);
        }

        protected override void OnEnable()
        {
            GameAbilityComponent.OnEnable();
        }

        protected override void OnDisable()
        {
            GameAbilityComponent.OnDisable();
        }

        protected override void OnDispose()
        {
            GameAbilityComponent.OnDispose();
            GameAttributeComponent.OnDispose();
        }

        public override void Update(float dt)
        {
            GameEffectComponent.Update(dt);
            GameAbilityComponent.Update(dt);
        }

        public void CanActive()
        {
        }

        public ulong ApplyGameEffectTo(GameEffect effect, GameAbilitySystem target)
        {
            return ApplyGameEffectTo(effect, default, target);
        }

        public ulong ApplyGameEffectTo(GameEffect effect, GameEffectContext context, GameAbilitySystem target)
        {
            if (effect.assetTags is null || effect.assetTags.Count == 0)
            {
                GameLog.Error($"GameEffect:{effect.backUp} assetTag不可以为空");
                return 0;
            }
            var spec = effect.CreateSpec(this, target);
            spec.SetContext(context);
            return target.GameEffectComponent.AddGameEffectSpec(spec);
        }

        public void ApplyModFromInstantGameEffect(GameEffectSpec spec)
        {
            foreach (var modifier in spec.GameEffect.modifiers)
            {
                var stat = GameAttributeComponent.GetAttribute(modifier.attribute);
                if (stat == null)
                {
                    throw new NullReferenceException($"Stat of '{modifier.attribute}' not found!");
                }
                var magnitude = modifier.magnitude.CalculateMagnitude(spec);
                var newValue = stat.BaseValue;
                switch (modifier.operation)
                {
                    case EModifierOperation.Add:
                        newValue += magnitude;
                        break;
                    case EModifierOperation.Minus:
                        newValue -= magnitude;
                        break;
                    case EModifierOperation.Multiply:
                        newValue *= magnitude;
                        break;
                    case EModifierOperation.Divide:
                        newValue /= magnitude;
                        break;
                    case EModifierOperation.Override:
                        newValue = magnitude;
                        break;
                    default:
                        throw new NotSupportedException($"Operation '{modifier.operation}' not supported!");
                }
                stat.SetBaseValue(newValue, false);
            }
        }
    
    }
}