﻿using System.Collections.Generic;
using cfg.attribute;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 根据目标属性计算当前属性，目标属性变化时当前属性会随之变化
    /// </summary>
    public class CompositeAttributeMagnitude : ModifierMagnitude
    {
        public AttributeId baseAttr;
        public AttributeId k;
        public AttributeId b;

        public override float CalculateMagnitude(GameEffectSpec spec)
        {
            var attrA = spec.Target.GameAttributeComponent.GetCurrentValue(baseAttr);
            var attrK = spec.Target.GameAttributeComponent.GetCurrentValue(k);
            var attrB = spec.Target.GameAttributeComponent.GetCurrentValue(b);
            // 血量有一个放大系数
            if (baseAttr == AttributeId.HpBase)
            {
                var mod = spec.Target.GameAttributeComponent.GetAttribute(AttributeId.HpMod).CurrentValue;
                return (attrA * (attrK + 1) + attrB) * (1f + mod);
            }
            return attrA * (attrK + 1) + attrB;
        }
    }

    public partial class GameAttributeComponent
    {
        private GameEffect _maxHp = new()
        {
            backUp = "最大血量",
            assetTags = new List<string>() { nameof(EGameTag.Effect_Buff) },
            durationPolicy = EDurationPolicy.Infinite,
            modifiers = new()
            {
                new GameEffectModifier()
                {
                    attribute = AttributeId.HpMax,
                    operation = EModifierOperation.Override,
                    magnitude = new CompositeAttributeMagnitude()
                    {
                        baseAttr = AttributeId.HpBase,
                        k = AttributeId.HpMult,
                        b = AttributeId.HpAdd,
                    },
                },
            },
        };

        private GameEffect _maxHpMod = new()
        {
            backUp = "最大血量修正",
            assetTags = new List<string>() { nameof(EGameTag.Effect_Buff) },
            durationPolicy = EDurationPolicy.Infinite,
            modifiers = new()
            {
                new GameEffectModifier()
                {
                    attribute = AttributeId.HpMax,
                    operation = EModifierOperation.Override,
                    magnitude = new CompositeAttributeMagnitude()
                    {
                        baseAttr = AttributeId.HpMax,
                        k = AttributeId.HpMult,
                        b = AttributeId.HpAdd,
                    },
                },
            },
        };

        private GameEffect _atk = new()
        {
            backUp = "当前攻击力",
            assetTags = new List<string>() { nameof(EGameTag.Effect_Buff) },
            durationPolicy = EDurationPolicy.Infinite,
            modifiers = new()
            {
                new GameEffectModifier()
                {
                    attribute = AttributeId.AtkFinal,
                    operation = EModifierOperation.Override,
                    magnitude = new CompositeAttributeMagnitude()
                    {
                        baseAttr = AttributeId.AtkBase,
                        k = AttributeId.AtkMult,
                        b = AttributeId.AtkAdd,
                    },
                },
            },
        };

        private GameEffect _def = new()
        {
            backUp = "当前防御力",
            assetTags = new List<string>() { nameof(EGameTag.Effect_Buff) },
            durationPolicy = EDurationPolicy.Infinite,
            modifiers = new()
            {
                new GameEffectModifier()
                {
                    attribute = AttributeId.DefFinal,
                    operation = EModifierOperation.Override,
                    magnitude = new CompositeAttributeMagnitude()
                    {
                        baseAttr = AttributeId.DefBase,
                        k = AttributeId.DefMult,
                        b = AttributeId.DefAdd,
                    },
                },
            },
        };
    }
}