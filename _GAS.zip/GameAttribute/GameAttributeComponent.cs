using System.Collections.Generic;
using Meow.Runtime.AOT;
using System.Linq;
using cfg.attribute;
using FixMath.NET;
using global::cfg.global;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    public partial class GameAttributeComponent
    {
        private Dictionary<AttributeId, Attribute> _attributes = new();

        private Dictionary<AttributeId, AttributeAggregator> _aggregators = new();
        private Dictionary<AttributeId, float> _initAttrs;
        private GameAbilitySystem _owner;

        // private HpHook _hpHook;

        public void OnStart(GameAbilitySystem owner, Dictionary<AttributeId, float> initAttributes)
        {
            _owner = owner;
            _initAttrs = initAttributes;
            _attributes.Clear();
            var attrList = GameDomain.ConfigService.Tables.TbAttribute.DataList;
            // 添加所有属性
            foreach (var config in attrList)
            {
                var id = (AttributeId)config.Id;
                _attributes.Add(id, new Attribute(id, 0));
                _aggregators.Add(id, new AttributeAggregator(_attributes[id], _owner));
            }

            // 初始化属性值
            if (_initAttrs != null)
            {
                foreach (var kv in _initAttrs)
                {
                    var attributeId = kv.Key;
                    var initValue = kv.Value;
                    if (_attributes.TryGetValue(attributeId, out var attribute))
                    {
                        var config = GameDomain.ConfigService.Tables.TbAttribute.GetOrDefault((int)attributeId);
                        if (config == null)
                        {
                            GameLog.Error($"找不到attributeId={attributeId}的配置");
                            continue;
                        }
                        attribute.InitBaseValue(config.BoPercentage ? initValue / 10000f : initValue);
                    }
                }
            }

            // 添加相对属性
            owner.ApplyGameEffectTo(_maxHp, owner);
            owner.ApplyGameEffectTo(_atk, owner);
            owner.ApplyGameEffectTo(_def, owner);

            // 重置血量
            _attributes[AttributeId.NowHp].InitBaseValue(_attributes[AttributeId.HpMax].CurrentValue);
        }

        public void OnDispose()
        {
            // _hpHook?.Dispose();
            // _hpHook = null;

            foreach (var attribute in _attributes.Values)
            {
                attribute.Dispose();
            }
            _attributes.Clear();
            foreach (var m in _aggregators.Values)
            {
                m.Dispose();
            }
        }

        public void OnGameEffectDirty()
        {
            foreach (var agg in _aggregators.Values)
            {
                agg.OnGameEffectDirty();
            }
        }

        public float GetCurrentValue(AttributeId attributeId)
        {
            return _attributes[attributeId].CurrentValue;
        }

        public float GetBaseValue(AttributeId attributeId)
        {
            return _attributes[attributeId].BaseValue;
        }

        public Attribute[] GetAttributes()
        {
            return _attributes.Values.ToArray();
        }

        public Attribute GetAttribute(AttributeId attr)
        {
            return _attributes.GetValueOrDefault(attr, null);
        }


    #region 业务接口
        /// <summary>
        /// 拷贝属性
        /// </summary>
        /// <param name="result"></param>
        public void CaptureAttr(Dictionary<AttributeId, float> result)
        {
            foreach (var pair in _attributes)
            {
                result[pair.Key] = pair.Value.CurrentValue;
            }
        }

        /// <summary>
        /// 获取血量百分比
        /// </summary>
        public float GetHpPercentage()
        {
            var hp = (float)_attributes[AttributeId.NowHp].CurrentValue;
            var maxHp = (float)_attributes[AttributeId.HpMax].CurrentValue;
            if (hp <= 0 || maxHp <= 0)
            {
                return 0;
            }
            return hp / maxHp;
        }

        /// <summary>
        /// 获取奥义能量百分比
        /// </summary>
        public float GetPowerPercentage()
        {
            var power = _attributes[AttributeId.Power].CurrentValue;
            var max = _attributes[AttributeId.MaxPower].CurrentValue;
            if (power <= 0 || max <= 0)
            {
                return 0;
            }
            return power / max;
        }

        /// <summary>
        /// 召唤物和远程攻击可能需要替换属性为父类的
        /// </summary>
        /// <param name="attrs"></param>
        public void SetAttributes(Attribute[] attrs)
        {
            foreach (var attr in attrs)
            {
                if (_attributes.TryGetValue(attr.Id, out var _))
                {
                    _attributes[attr.Id] = attr;
                }
                else
                {
                    _attributes.Add(attr.Id, attr);
                }
            }
        }
    #endregion
    }
}