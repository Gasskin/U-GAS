using System;
using System.Collections.Generic;
using cfg.attribute;
using cfg.hero;
using Meow.Runtime.AOT;
using UnityEngine;
using UnityEngine.Pool;

namespace Meow.Runtime.HotUpdate
{
    public class ModifierSpec : IPoolable
    {
        public GameEffectSpec spec;

        public GameEffectModifier modifier;

        public void Clear()
        {
            spec = null;
            modifier = null;
        }
    }

    /// <summary>
    /// 例：最大生命 = 力量 * 100
    /// SomeGE: 力量.BaseValue + 10
    /// -> 力量.OnPostBaseValueChange -> CalculateCurrent -> SetCurrentValue -> 力量.OnPostCurrentValueChange
    /// -> 生命.OnPostDependCurrentValueChange
    /// </summary>
    public partial class AttributeAggregator
    {
        private Attribute _target;
        private GameAbilitySystem _owner;
        private List<ModifierSpec> _modifierSpecs = new();

        private readonly Dictionary<AttributeId, AttributeId> _attrMax = new()
        {
            // 生命值
            { AttributeId.NowHp, AttributeId.HpMax },
            // 个人能量
            { AttributeId.CommonEnergy, AttributeId.CommonEnergyMax },
            { AttributeId.PersonalEnergy, AttributeId.MaxPersonalEnergy },
            { AttributeId.PersonalEnergy2, AttributeId.MaxPersonalEnergy2 },
            { AttributeId.PersonalEnergy3, AttributeId.MaxPersonalEnergy3 },
            { AttributeId.PersonalEnergy4, AttributeId.MaxPersonalEnergy4 },
            // 奥义
            { AttributeId.Power, AttributeId.MaxPower },
            // 异常状态积蓄
            { AttributeId.NowLightAccrue, AttributeId.MaxLightAccrue },
            { AttributeId.NowVoidAccrue, AttributeId.MaxVoidAccrue },
            { AttributeId.NowTimeAccrue, AttributeId.MaxTimeAccrue },
            { AttributeId.NowEnergyAccrue, AttributeId.MaxEnergyAccrue },
            { AttributeId.NowCreateAccrue, AttributeId.MaxCreateAccrue },
            { AttributeId.NowDarkAccrue, AttributeId.MaxDarkAccrue },
            { AttributeId.NowSpaceAccrue, AttributeId.MaxSpaceAccrue },
        };
        
        // 暂时未配表的上限值
        private readonly Dictionary<AttributeId, float> _attrMaxValue = new()
        {
            // 莉亚娜死亡标记充能上限值
            { AttributeId.LyanaDeathMark, 300 },
        };

        public AttributeAggregator(Attribute target, GameAbilitySystem owner)
        {
            _target = target;
            _owner = owner;
            _target.OnPreBaseValueChange += OnPreBaseValueChange;
            _target.OnPreCurrentValueChange += OnPreCurrentValueChange;
            _target.OnPostBaseValueChange += OnPostBaseValueChange;
            _target.OnPostCurrentValueChange += OnPostCurrentValueChange;
        }

        public void Dispose()
        {
            _target.OnPreBaseValueChange -= OnPreBaseValueChange;
            _target.OnPreCurrentValueChange -= OnPreCurrentValueChange;
            _target.OnPostBaseValueChange -= OnPostBaseValueChange;
            _target.OnPostCurrentValueChange -= OnPostCurrentValueChange;
        }


        public void OnGameEffectDirty()
        {
            var isDirty = _modifierSpecs.Count > 0;

            ReleaseModifiers();

            var effects = ListPool<GameEffectSpec>.Get();
            _owner.GameEffectComponent.GetGameEffectSpecs(effects);
            foreach (var spec in effects)
            {
                if (spec.IsActive)
                {
                    foreach (var modifier in spec.GameEffect.modifiers)
                    {
                        if (modifier.attribute == _target.Id)
                        {
                            AddCompositeAttributeListener(modifier.magnitude);
                            var cache = AOT.GenericPool<ModifierSpec>.Alloc();
                            cache.modifier = modifier;
                            cache.spec = spec;
                            _modifierSpecs.Add(cache);
                        }
                    }
                }
            }
            ListPool<GameEffectSpec>.Release(effects);

            isDirty = isDirty || _modifierSpecs.Count > 0;

            if (isDirty)
            {
                CalculateCurrent();
            }
        }

        private float OnPreBaseValueChange(float input)
        {
            return ClampAttribute(input);
        }

        private float OnPreCurrentValueChange(float input)
        {
            return ClampAttribute(input);
        }

        private void OnPostBaseValueChange(float oldValue, float newValue)
        {
            CalculateCurrent();
        }


        private void OnPostCurrentValueChange(float oldValue, float newValue)
        {
            // UI业务需求，和战斗无关
            switch (_target.Id)
            {
                case AttributeId.NowHp:
                    RefreshHpAttributeEvent.Send(_owner.Entity, oldValue, newValue);
                    break;
                case AttributeId.Power:
                    RefreshAoYiEvent.SendMsg(_owner.Entity);
                    break;
                case AttributeId.NowLightAccrue:
                    RefreshUnitExceptionEvent.SendMsg(_owner.Entity, Element.Light);
                    break;
                case AttributeId.NowVoidAccrue:
                    RefreshUnitExceptionEvent.SendMsg(_owner.Entity, Element.Void);
                    break;
                case AttributeId.NowTimeAccrue:
                    RefreshUnitExceptionEvent.SendMsg(_owner.Entity, Element.Time);
                    break;
                case AttributeId.NowEnergyAccrue:
                    RefreshUnitExceptionEvent.SendMsg(_owner.Entity, Element.Energy);
                    break;
                case AttributeId.NowCreateAccrue:
                    RefreshUnitExceptionEvent.SendMsg(_owner.Entity, Element.Create);
                    break;
                case AttributeId.NowDarkAccrue:
                    RefreshUnitExceptionEvent.SendMsg(_owner.Entity, Element.Dark);
                    break;
                case AttributeId.NowSpaceAccrue:
                    RefreshUnitExceptionEvent.SendMsg(_owner.Entity, Element.Space);
                    break;
            }
        }

        private void OnPostDependCurrentValueChange(float oldValue, float newValue)
        {
            CalculateCurrent();
        }

        private void CalculateCurrent()
        {
            var newValue = _target.BaseValue;
            foreach (var mod in _modifierSpecs)
            {
                var spec = mod.spec;
                var modifier = mod.modifier;
                var magnitude = modifier.magnitude.CalculateMagnitude(spec);

                switch (modifier.operation)
                {
                    case EModifierOperation.Add:
                        newValue += magnitude;
                        break;
                    case EModifierOperation.Minus:
                        newValue -= magnitude;
                        break;
                    case EModifierOperation.Multiply:
                        newValue *= magnitude;
                        break;
                    case EModifierOperation.Divide:
                        newValue /= magnitude;
                        break;
                    case EModifierOperation.Override:
                        newValue = magnitude;
                        break;
                    default:
                        throw new ArgumentOutOfRangeException();
                }
            }

            _target.SetCurrentValue(newValue);
        }

        private void ReleaseModifiers()
        {
            foreach (var m in _modifierSpecs)
            {
                RemoveCompositeAttributeListener(m.modifier.magnitude);
                AOT.GenericPool<ModifierSpec>.Release(m);
            }
            _modifierSpecs.Clear();
        }

        private void AddCompositeAttributeListener(ModifierMagnitude m)
        {
            if (m is not CompositeAttributeMagnitude cm)
            {
                return;
            }
            var a = _owner.GameAttributeComponent.GetAttribute(cm.baseAttr);
            var k = _owner.GameAttributeComponent.GetAttribute(cm.k);
            var b = _owner.GameAttributeComponent.GetAttribute(cm.b);
            a.OnPostCurrentValueChange += OnPostDependCurrentValueChange;
            k.OnPostCurrentValueChange += OnPostDependCurrentValueChange;
            b.OnPostCurrentValueChange += OnPostDependCurrentValueChange;
        }

        private void RemoveCompositeAttributeListener(ModifierMagnitude m)
        {
            if (m is not CompositeAttributeMagnitude cm)
            {
                return;
            }
            var a = _owner.GameAttributeComponent.GetAttribute(cm.baseAttr);
            var k = _owner.GameAttributeComponent.GetAttribute(cm.k);
            var b = _owner.GameAttributeComponent.GetAttribute(cm.b);
            a.OnPostCurrentValueChange -= OnPostDependCurrentValueChange;
            k.OnPostCurrentValueChange -= OnPostDependCurrentValueChange;
            b.OnPostCurrentValueChange -= OnPostDependCurrentValueChange;
        }

        private float ClampAttribute(float input)
        {
            if (_attrMaxValue.TryGetValue(_target.Id, out var attrMaValue))
            {
                input = Mathf.Clamp(input, 0, attrMaValue);
            }
            
            if (_attrMax.TryGetValue(_target.Id, out var attrMax))
            {
                var max = _owner.GameAttributeComponent.GetCurrentValue(attrMax);
                input = Mathf.Clamp(input, 0, max);
            }
            
            return input;
        }
    }
}