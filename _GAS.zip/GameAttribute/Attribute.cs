using cfg.attribute;
using FixMath.NET;
using System;
using System.Collections.Generic;
using Meow.Runtime.AOT;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    public class Attribute
    {
        // 直接修改BaseValue可能存在风险的属性列表
        private static readonly HashSet<AttributeId> s_WarningAttributes = new()
        {
            AttributeId.Power,
            AttributeId.CommonEnergy,
            AttributeId.NowHp,
        };

        public AttributeId Id { get; private set; }
        // private readonly bool _isPercent;

        public float BaseValue { get; private set; }

        public float CurrentValue { get; private set; }

        public event Action<float, float> OnPostBaseValueChange;

        // OldValue, NewValue
        public event Action<float, float> OnPostCurrentValueChange;

        public event Func<float, float> OnPreBaseValueChange
        {
            add => _onPreBaseValueChange.Add(value);
            remove => _onPreBaseValueChange.Remove(value);
        }

        private List<Func<float, float>> _onPreBaseValueChange = new();

        public event Func<float, float> OnPreCurrentValueChange
        {
            add => _onPreCurrentValueChange.Add(value);
            remove => _onPreCurrentValueChange.Remove(value);
        }

        private List<Func<float, float>> _onPreCurrentValueChange = new();

        // 额外整数值 = 最终整数值 - 基础整数值
        private float ExtraValue => CurrentValue - BaseValue;

        public Attribute(AttributeId id, float value)
        {
            Id = id;
            BaseValue = value;
        }

        public void Dispose()
        {
        }

        public void InitBaseValue(float value)
        {
            BaseValue = value;
            CurrentValue = BaseValue;
        }

        public void SetBaseValue(float newValue, bool checkWarning = true)
        {
            if (checkWarning && s_WarningAttributes.Contains(Id))
            {
                GameLog.Error($"直接设置属性: {Id}, 可能存在逻辑性问题, 请确认是否正确, 并关闭警告");
            }
            foreach (var func in _onPreBaseValueChange)
            {
                newValue = func(newValue);
            }
            var oldValue = BaseValue;
            BaseValue = newValue;
            if (!Mathf.Approximately(oldValue, newValue))
            {
                OnPostBaseValueChange?.Invoke(oldValue, newValue);
            }
        }

        /// <summary>
        /// 禁止调用，框架层接口
        /// </summary>
        public void SetCurrentValue(float newValue)
        {
            for (int i = 0; i < _onPreCurrentValueChange.Count; i++)
            {
                newValue = _onPreCurrentValueChange[i].Invoke(newValue);
            }
            var oldValue = CurrentValue;
            CurrentValue = newValue;
            if (!Mathf.Approximately(oldValue, newValue))
            {
                OnPostCurrentValueChange?.Invoke(oldValue, newValue);
            }
        }

    #region ToString
        // public override string ToString()
        // {
        //     if (_isPercent)
        //     {
        //         return $"{Id}: RawValue={BaseValue}, FinalValue={CurrentValue}";
        //     }
        //     else
        //     {
        //         return $"{Id}: RawValue={BaseValue}, FinalValue={CurrentValue}";
        //     }
        // }
        //
        // public string ValueText
        // {
        //     get
        //     {
        //         if (_isPercent)
        //         {
        //             return FormatPercent(CurrentValue);
        //         }
        //         else
        //         {
        //             return CurrentValue.ToString();
        //         }
        //     }
        // }
        //
        // public string ValueText2
        // {
        //     get
        //     {
        //         if (_isPercent)
        //         {
        //             return $"{FormatPercent(CurrentValue)} ({FormatPercent(BaseValue)}+{FormatPercent(ExtraValue)})";
        //         }
        //         else
        //         {
        //             return $"{CurrentValue} ({BaseValue}+{ExtraValue})";
        //         }
        //     }
        // }


        private string FormatPercent(Fix64 value)
        {
            return $"{(float)value * 100f:0.##}%";
        }
    #endregion
    }
}