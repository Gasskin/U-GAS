﻿using System;
using MemoryPack;
using Meow.Runtime.AOT;

namespace Meow.Runtime.HotUpdate
{
    [Serializable]
    [MemoryPackable]
    [MemoryPackUnion(0, typeof(GameCueMakeAudio))]
    [MemoryPackUnion(1, typeof(GameCuePlayVfxDurational))]
    [MemoryPackUnion(2, typeof(GameCueRadialBlurPfx))]
    [MemoryPackUnion(3, typeof(GameCueForceMove))]
    [MemoryPackUnion(4, typeof(GameCueHitVfx))]
    [MemoryPackUnion(5, typeof(GameCueTimeline))]
    [MemoryPackUnion(6, typeof(GameCueNodeEmission))]
    [MemoryPackUnion(7, typeof(GameCueCharacterNodeActive))]
    public abstract partial class GameCue
    {
        public abstract GameCueSpec CreateSpec(GameEffectSpec spec);
    }

    public abstract class GameCueSpec : IPoolable
    {
        #region Pool
        private static AbstractObjectPool<GameCueSpec, Type, Type> s_Pool = new(CreateFunc, GetPoolKey);

        private static GameCueSpec CreateFunc(Type type)
        {
            return (GameCueSpec)Activator.CreateInstance(type);
        }

        private static Type GetPoolKey(Type type)
        {
            return type;
        }

        public static T Alloc<T>() where T : GameCueSpec
        {
            return (T)s_Pool.Alloc(typeof(T));
        }

        public static void Release(GameCueSpec spec)
        {
            s_Pool.Release(spec.GetType(), spec);
        }
        #endregion

        protected GameEffectSpec gameEffectSpec;
        protected GameCue gameCue;

        public void Init(GameCue cue, GameEffectSpec spec)
        {
            gameCue = cue;
            gameEffectSpec = spec;
        }

        protected abstract void OnClear();

        public virtual void Clear()
        {
            OnClear();
            gameCue = null;
            gameEffectSpec = null;
        }
    }
}