﻿namespace Meow.Runtime.HotUpdate
{
    public interface IGameCueDurational
    {
        void OnAdd();
        void OnRemove();
        void OnTick(float dt);
        void OnActive();
        void OnDeActive();
    }
}