using MemoryPack;
using Meow.Runtime.AOT;
using Sirenix.OdinInspector;
using System;

namespace Meow.Runtime.HotUpdate
{
    [Serializable]
    [MemoryPackable]
    public partial class GameCueRadialBlurPfx : GameCue
    {
        /// <summary>
        /// 目标值[0-1]
        /// </summary>
        [LabelText("目标值[0-1]")]
        public float target;

        /// <summary>
        /// 结束时重置
        /// </summary>
        [LabelText("结束时重置")]
        public bool endRest;

        /// <summary>
        /// 过渡时间
        /// </summary>
        [LabelText("过渡时间")]
        public float transitionDuration;

        /// <summary>
        /// 重置过渡时间
        /// </summary>
        [LabelText("重置过渡时间")]
        public float resetDuration;

        public override GameCueSpec CreateSpec(GameEffectSpec spec)
        {
            var cue = GameCueSpec.Alloc<GameCueRadialBlurPfxSpec>();
            cue.Init(this, spec);
            return cue;
        }
    }

    public class GameCueRadialBlurPfxSpec : GameCueSpec, IGameCueDurational
    {
        //private LucisRadialBlurV2VolumeComponent _blurConf;
        private float _initialValue;
        private bool _isTransitioning; // 是否正在过渡
        private uint _ownerId;
        private float _targetValue;
        private float _transitionSpeed; // 每帧变化量

        public void OnAdd()
        {
            OnStart(gameEffectSpec.Target.Entity);
        }

        public void OnRemove()
        {
        }

        public void OnTick(float dt)
        {
        }

        public void OnActive()
        {
        }

        public void OnDeActive()
        {
        }


        private void OnStart(uint entityId)
        {
            _ownerId = entityId;
            var data = (GameCueRadialBlurPfx)gameCue;
            var postVfxService = InGameDomain.PostVfxService;
            var globalVolume = postVfxService.GetGlobalVolume();

            //if (!globalVolume.profile.TryGet(out _blurConf))
            //{
            //    GameLog.Error("GlobalVolume 未找到 LucisRadialBlurV2VolumeComponent");
            //    return;
            //}

            _targetValue = data.target;
            var transitionDuration = data.transitionDuration;
            // _initialValue = _blurConf.RadialBlurIntensity;
            var distance = _targetValue - _initialValue;
            _transitionSpeed = distance / transitionDuration;
            _isTransitioning = true;
            //_blurConf.m_RadialBlurIntensity.overrideState = true;
            AddTickService(data);
        }

        private void AddTickService(GameCueRadialBlurPfx data)
        {
            // 添加更新注册
            if (!World.Current.HasEntity(_ownerId))
            {
                return;
            }

            // 结束过渡重置(非硬切)
            if (data.endRest && data.resetDuration > 0)
            {
                var startEndTime = gameEffectSpec.GameEffect.duration - data.resetDuration;
                var endTimer = InGameDomain.TimeService.UpdateUpdater.AddTimer(startEndTime,
                    () =>
                {
                    _targetValue = _initialValue;
                    var transitionDuration = data.resetDuration;
                    //var distance = _targetValue - _blurConf.RadialBlurIntensity;
                    //_transitionSpeed = distance / transitionDuration;
                    //_isTransitioning = true;
                    //_blurConf.m_RadialBlurIntensity.overrideState = true;
                }, false);
                endTimer.SetId(this);
            }
        }

        protected override void OnClear()
        {
        }
    }
}