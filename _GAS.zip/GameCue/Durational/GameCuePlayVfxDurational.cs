﻿using MemoryPack;
using Meow.Runtime.AOT;
using Meow.Runtime.HotUpdate.BattleConfig;
using Meow.Runtime.HotUpdate.BattleConfig.skill;
using Sirenix.OdinInspector;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

namespace Meow.Runtime.HotUpdate
{
    [Serializable]
    [MemoryPackable]
    public partial class GameCuePlayVfxDurational : GameCue
    {
        [LabelText("持续时间")]
        [LabelWidth(100)]
        public float duration;
        [LabelText("特效资源")]
        [LabelWidth(100)]
        public AssetLocationField<GameObject> prefabLocation;
        [LabelText("创建点")]
        [LabelWidth(100)]
        public E_CharacterBone point;
        [LabelText("创建点名称 优先级低于point")]
        [LabelWidth(100)]
        public string pointName;
        [LabelText("是否跟随")]
        [LabelWidth(100)]
        public bool follow;
        [LabelText("跟随来源，默认是跟随目标")]
        [LabelWidth(100)]
        public bool followSource;
        [LabelText("位置偏移")]
        [LabelWidth(100)]
        public Vector3 localPosition;
        [LabelText("朝向偏移")]
        [LabelWidth(100)]
        public Vector3 localEulerAngles;
        [LabelText("循环次数")]
        [LabelWidth(100)]
        public int loopCounter;
        [LabelText("循环间隔")]
        [LabelWidth(100)]
        public float loopInterval;
        [LabelText("缩放比例")]
        [LabelWidth(100)]
        public float scale;
        [LabelText("是否对象是前台角色时释放")]
        [LabelWidth(100)]
        public bool targetIsActiveRole;

        public override GameCueSpec CreateSpec(GameEffectSpec spec)
        {
            var cue = GameCueSpec.Alloc<GameCuePlayVfxDurationalSpec>();
            cue.Init(this, spec);
            return cue;
        }
    }

    public class GameCuePlayVfxDurationalSpec : GameCueSpec, IGameCueDurational
    {
        private List<int> _vfxIds = new();
        public void OnAdd()
        {
            if (gameCue is GameCuePlayVfxDurational gameCueDuration)
            {
                PlayVfx(gameCueDuration.loopCounter);
            }
        }

        public void OnRemove()
        {
            foreach (var vfxId in _vfxIds)
            {
                InGameDomain.VfxService.StopVfx(vfxId);
            }
            _vfxIds.Clear();
            InGameDomain.TimeService.UpdateUpdater.KillByOwner(this);
        }

        public void OnTick(float dt)
        {
        }

        public void OnActive()
        {
        }

        public void OnDeActive()
        {
        }

        protected override void OnClear()
        {

        }


        private void PlayVfx(int counter)
        {
            // 播放特效逻辑

            if (gameCue is GameCuePlayVfxDurational gameCueDuration)
            {

                if (gameCueDuration.targetIsActiveRole && World.Current.GetSystem<BattleTeamSystem>().ActiveRoleEntity != gameEffectSpec.Target.Entity)
                {
                    return;
                }
                if (!World.Current.TryGetEntityComp<CharacterVfxComp>(gameEffectSpec.Target.Entity, out var vfxComp))
                {
                    return;
                }

                // 播放无限市场特效，由action自己管理
                vfxComp.PlayVfx(gameCueDuration.prefabLocation, gameCueDuration.point, gameCueDuration.follow, gameCueDuration.localPosition, gameCueDuration.localEulerAngles, gameCueDuration.scale, out var vfxId);
                _vfxIds.Add(vfxId);

                // 下面是对于重复逻辑的处理
                var infiniteLoop = counter == -1;
                if (infiniteLoop)
                {
                    var timer = InGameDomain.TimeService.UpdateUpdater.AddTimer(gameCueDuration.loopInterval, () => PlayVfx(counter));
                    timer.SetId(this);
                }
                else if (counter > 0)
                {
                    var timer = InGameDomain.TimeService.UpdateUpdater.AddTimer(gameCueDuration.loopInterval, () => PlayVfx(counter - 1));
                    timer.SetId(this);
                }
            }
        }
    }
}