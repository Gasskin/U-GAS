using MemoryPack;
using System;
using Sirenix.OdinInspector;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    [Serializable]
    [MemoryPackable]
    public partial class GameCueCharacterNodeActive : GameCue
    {
        [LabelText("节点id")]
        [LabelWidth(100)]
        public string id;

        [LabelText("优先级")]
        [LabelWidth(100)]
        public int priority = 0;

        [LabelText("是否激活")]
        [LabelWidth(100)]
        public bool active;

        [Tooltip("[武器溶解专用]是否反向溶解")]
        [LabelWidth(100)]
        public bool isReverse;

        [Tooltip("[武器溶解专用]溶解时间覆盖(-1使用默认配置 ,0为不溶解 直接隐藏)")]
        [LabelWidth(100)]
        public float dissolveTime = -1f;

        public override GameCueSpec CreateSpec(GameEffectSpec spec)
        {
            var cue = GameCueSpec.Alloc<GameCueCharacterNodeActiveSpec>();
            cue.Init(this, spec);
            return cue;
        }
    }

    public class GameCueCharacterNodeActiveSpec : GameCueSpec, IGameCueDurational
    {
        private ulong _tokenId;

        protected override void OnClear()
        {
        }
        void IGameCueDurational.OnAdd()
        {
        }
        void IGameCueDurational.OnRemove()
        {
        }
        void IGameCueDurational.OnActive()
        {
            if (gameCue is not GameCueCharacterNodeActive gameCueCharacterNodeActive)
            {
                return;
            }
            if (!World.Current.TryGetEntityComp<UnitSkinNodeComp>(gameEffectSpec.Source.Entity, out var unitSkinNodeComp))
            {
                return;
            }
            unitSkinNodeComp.SetActive(gameCueCharacterNodeActive.id, gameCueCharacterNodeActive.priority, gameCueCharacterNodeActive.active, gameCueCharacterNodeActive.isReverse, gameCueCharacterNodeActive.dissolveTime, out _tokenId);
        }

        void IGameCueDurational.OnDeActive()
        {
            if (gameCue is not GameCueCharacterNodeActive gameCueCharacterNodeActive)
            {
                return;
            }
            if (!World.Current.TryGetEntityComp<UnitSkinNodeComp>(gameEffectSpec.Source.Entity, out var unitSkinNodeComp))
            {
                return;
            }
            if (_tokenId == 0)
            {
                return;
            }
            unitSkinNodeComp.RemoveToken(gameCueCharacterNodeActive.id, _tokenId);
        }



        void IGameCueDurational.OnTick(float dt)
        {
        }
    }
}