using MemoryPack;
using Meow.Runtime.AOT;
using Meow.Runtime.HotUpdate.BattleConfig.gameAction;
using Sirenix.OdinInspector;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    [Serializable]
    [MemoryPackable]
    public partial class GameCueForceMove : GameCue
    {
        [LabelText("强制移动方式")]
        [LabelWidth(100)]
        public E_ForceMoveType forceMoveType;

        /// <summary>
        /// 移动速度
        /// </summary>
        [LabelText("移动速度")]
        [LabelWidth(100)]
        public float moveSpeed;

        /// <summary>
        /// 移动加速度
        /// </summary>
        [LabelText("移动加速度")]
        [LabelWidth(100)]
        public float moveAccSpeed;

        /// <summary>
        /// 特效
        /// </summary>
        [LabelText("特效")]
        [LabelWidth(100)]
        public GameAction_PlayVfx vfx;


        /// <summary>
        /// 是否对Boss生效
        /// </summary>
        [LabelText("是否对Boss生效")]
        [LabelWidth(100)]
        public bool canAffectBoss;


        public override GameCueSpec CreateSpec(GameEffectSpec spec)
        {
            var cue = GenericPool<GameCueForceMoveSpec>.Alloc();
            cue.Init(this, spec);
            return cue;
        }
    }

    public class GameCueForceMoveSpec : GameCueSpec, IGameCueDurational
    {
        private GameCueForceMove _cfg;
        private CharacterMovementComponent _cc;

        private float _curMoveSpeed;
        private readonly List<int> _ids = new();
        public void OnAdd()
        {
            _cfg = (GameCueForceMove)gameCue;
            _curMoveSpeed = _cfg.moveSpeed;
            if (World.Current.TryGetEntityComp<HeroUnitComp>(gameEffectSpec.Target.Entity, out var heroComp))
            {
                if (!_cfg.canAffectBoss)
                {
                    var monsterCfg = GameDomain.ConfigService.Tables.TbMonster.GetOrDefault(heroComp.HeroTid);
                    if (monsterCfg != null && monsterCfg.IsBoss())
                    {
                        return;
                    }
                }

                if (World.Current.TryGetEntityComp<CharacterMovementComponent>(gameEffectSpec.Target.Entity, out _cc))
                {
                    PlayVfx();
                }
            }
        }

        public void OnRemove()
        {
            DoStop();
        }

        public void OnTick(float dt)
        {

            if (_curMoveSpeed <= 0)
            {
                return;
            }

            if (World.Current.TryGetEntityComp<UnitGameObjectComp>(gameEffectSpec.Source.Entity, out var sugo) &&
                World.Current.TryGetEntityComp<UnitGameObjectComp>(gameEffectSpec.Target.Entity, out var tugo))
            {
                var dir = tugo.Root.transform.position - sugo.Root.transform.position;
                if (_cfg.forceMoveType == E_ForceMoveType.Pull)
                {
                    dir = -dir;
                }
                if (World.Current.TryGetEntityComp<CharacterMovementComponent>(gameEffectSpec.Target.Entity, out var cc))
                {
                    var deltaPos = dir * _curMoveSpeed * dt;
                    cc.AddTransformInputIncrement(deltaPos, Quaternion.identity);
                    _curMoveSpeed = _curMoveSpeed + _cfg.moveAccSpeed * dt;
                }
            }

        }

        public void OnActive()
        {
        }

        public void OnDeActive()
        {
        }


        protected override void OnClear()
        {
            GenericPool<GameCueForceMoveSpec>.Release(this);
        }

        private void PlayVfx()
        {
            if (_cfg.vfx == null)
            {
                return;
            }
            if (World.Current.TryGetEntityComp<CharacterVfxComp>(gameEffectSpec.Target.Entity, out var vfxComp))
            {
                vfxComp.PlayVfx(_cfg.vfx.prefabLocation, _cfg.vfx.point, _cfg.vfx.follow, _cfg.vfx.localPosition, _cfg.vfx.localEulerAngles, _cfg.vfx.scale, _cfg.vfx.loopInterval, out var vfxId);
                _ids.Add(vfxId);
            }
        }

        private void DoStop()
        {
            foreach (var vfxId in _ids)
            {

                InGameDomain.VfxService.StopVfx(vfxId);
            }
            _ids.Clear();
        }

    }
}