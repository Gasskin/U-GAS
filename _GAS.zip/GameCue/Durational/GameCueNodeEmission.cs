using MemoryPack;
using System;
using Sirenix.OdinInspector;
using UnityEngine;
using System.Collections.Generic;
using Meow.Runtime.AOT;

namespace Meow.Runtime.HotUpdate
{

    [Serializable]
    [MemoryPackable]
    public partial class GameCueNodeEmission : GameCue
    {
        [LabelText("节点名称")]
        [LabelWidth(100)]
        public string skinNodeName;

        [LabelText("颜色")]
        [ColorUsage(true, true)]
        [LabelWidth(100)]
        public Color color;
        public override GameCueSpec CreateSpec(GameEffectSpec spec)
        {
            var cue = GameCueSpec.Alloc<GameCueNodeEmissionSpec>();
            cue.Init(this, spec);
            return cue;
        }
    }

    public class GameCueNodeEmissionSpec : GameCueSpec, IGameCueDurational
    {
        private MaterialPropertyBlock _mpb;

        void IGameCueDurational.OnAdd()
        {
            _mpb = new MaterialPropertyBlock();
        }

        void IGameCueDurational.OnRemove()
        {
            if (gameCue is not GameCueNodeEmission gameCueNodeEmission)
            {
                return;
            }
            // 获取节点
            if (!World.Current.TryGetEntityComp<UnitSkinNodeComp>(gameEffectSpec.Source.Entity, out var unitSkinNodeComp))
            {
                return;
            }
            if (_mpb != null)
            {
                unitSkinNodeComp.ClearMaterialPropertyBlock(gameCueNodeEmission.skinNodeName, _mpb);
            }
        }

        void IGameCueDurational.OnActive()
        {
        }

        void IGameCueDurational.OnDeActive()
        {
        }

        void IGameCueDurational.OnTick(float dt)
        {
            if (gameCue is not GameCueNodeEmission gameCueNodeEmission)
            {
                return;
            }
            if (!World.Current.TryGetEntityComp<UnitSkinNodeComp>(gameEffectSpec.Source.Entity, out var unitSkinNodeComp))
            {
                return;
            }
            unitSkinNodeComp.TrySetMaterialTextureIfNull(gameCueNodeEmission.skinNodeName, MaterialDefines.PropId_EmissionMap, MaterialDefines.WhiteTexture, _mpb);
            unitSkinNodeComp.SetMaterialColor(gameCueNodeEmission.skinNodeName, MaterialDefines.PropId_EmissionTintColor, gameCueNodeEmission.color, _mpb);
            unitSkinNodeComp.SetMaterialFloat(gameCueNodeEmission.skinNodeName, MaterialDefines.PropId_EmissionScale, 1, _mpb);
        }


        protected override void OnClear()
        {
        }
    }
}