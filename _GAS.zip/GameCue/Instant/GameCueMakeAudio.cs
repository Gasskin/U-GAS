﻿using System;
using MemoryPack;
using Meow.Runtime.AOT;

namespace Meow.Runtime.HotUpdate
{
    [Serializable]
    [MemoryPackable]
    public partial class GameCueMakeAudio : GameCue
    {
        public string eventName;

        public override GameCueSpec CreateSpec(GameEffectSpec spec)
        {
            var cue = GameCueSpec.Alloc<GameCueMakeAudioSpec>();
            cue.Init(this, spec);
            return cue;
        }
    }

    public class GameCueMakeAudioSpec : GameCueSpec, IGameCueInstant
    {
        public void OnTrigger()
        {
            if (gameCue is GameCueMakeAudio cue)
            {
                WwiseService.Play(cue.eventName);
            }
        }

        protected override void OnClear()
        {
         
        }
    }
}