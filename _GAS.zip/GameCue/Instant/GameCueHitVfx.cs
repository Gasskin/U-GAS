using System;
using MemoryPack;
using Meow.Runtime.HotUpdate.BattleConfig;
using Meow.Runtime.HotUpdate.BattleConfig.skill;
using Sirenix.OdinInspector;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    public enum EHitStateType
    {
        None,
        [LabelText("轻受击")]
        Light,
        [LabelText("重受击")]
        Heavy,
        [LabelText("水平击飞")]
        HitLaunch,
    }
    //开放给策划的选项
    public enum EHitVfxPoint
    {
        [InspectorName("受击特效挂点(HurtVfx_Root)")]
        HurtVfxRoot,// = E_CharacterBone.HurtVfxRoot,
        [InspectorName("根骨骼(Root)")]
        Root// = E_CharacterBone.Root
    }
    [Serializable]
    [MemoryPackable]
    public partial class GameCueHitVfx : GameCue
    {
        [LabelText("特效资源"), LabelWidth(100)]
        public AssetLocationField<GameObject> prefabLocation;

        [LabelText("受击特效挂点"), LabelWidth(100)]
        public EHitVfxPoint hitVfxPoint = EHitVfxPoint.HurtVfxRoot;

        [LabelText("击中坐标"), LabelWidth(100)]
        public bool useHitPoint;

        [LabelText("位置偏移"), LabelWidth(100)]
        public Vector3 localPosition;

        [LabelText("朝向偏移"), LabelWidth(100)]
        public Vector3 localEulerAngles;

        [LabelText("受击状态"), LabelWidth(100)]
        public bool enterHitState;

        [LabelText("受击类型"), LabelWidth(100), ShowIf("enterHitState")]
        public EHitStateType hitStateType = EHitStateType.None;

        [LabelText("受击变向"), LabelWidth(100), ShowIf("enterHitState")]
        public bool changeDir = false;

        public override GameCueSpec CreateSpec(GameEffectSpec spec)
        {
            var cue = GameCueSpec.Alloc<GameCueHitVfxSpec>();
            cue.Init(this, spec);
            return cue;
        }
    }

    public class GameCueHitVfxSpec : GameCueSpec, IGameCueInstant
    {
        protected override void OnClear()
        {
        }

        public void OnTrigger()
        {
            if (gameCue is not GameCueHitVfx cue)
            {
                return;
            }

            // if (!World.Current.TryGetEntityComp<UnitGameObjectComp>(gameEffectSpec.Target.Entity, out var unit))
            // {
            //     return;
            // }

            if (!World.Current.TryGetEntityComp(gameEffectSpec.Target.Entity, out CharacterVfxComp vfxComp))
            {
                return;
            }
            if (!World.Current.TryGetEntityComp<UnitBoneComp>(gameEffectSpec.Target.Entity, out var boneComp))
            {
                return;
            }
            // 坐标偏移
            var pos = cue.localPosition;
            var rot = cue.localEulerAngles;
            var bone = E_CharacterBone.HurtVfxRoot;
            // 真实受击点坐标
            if (cue.useHitPoint)
            {
                ///如果策划没有选择任何挂点，就用<see cref='E_CharacterBone.HurtVfxRoot'>原有逻辑如此</see>
                bone = cue.hitVfxPoint == EHitVfxPoint.HurtVfxRoot ? E_CharacterBone.HurtVfxRoot : E_CharacterBone.Root;
                var vfxRoot = boneComp.GetBone(bone);
                ///如果选择的挂点找不到对应骨骼，就用根骨骼<see cref="E_CharacterBone.Root"/>
                if (vfxRoot == null)
                {
                    bone = E_CharacterBone.Root;
                    vfxRoot = boneComp.GetBone(bone);
                }
                var hitPos = vfxRoot.InverseTransformPoint(gameEffectSpec.Context.hitPoint);
                pos += hitPos;
            }
            vfxComp.PlayVfx(cue.prefabLocation, bone, true, pos, rot, 1.0f, out _);
            // 需要进入受击状态
            if (cue.enterHitState)
            {
                if (!World.Current.TryGetEntityComp(gameEffectSpec.Target.Entity, out CharacterControllerComponent targetCcc))
                {
                    return;
                }
                
                if (!World.Current.TryGetEntityComp(gameEffectSpec.Source.Entity, out CharacterControllerComponent sourceCcc))
                {
                    return;
                }

                var targetPos = targetCcc.MoveComp.Pos;
                var sourcePos = sourceCcc.MoveComp.Pos;
                
                // var vfxRoot = boneComp.GetBone(E_CharacterBone.HurtVfxRoot);
                // var hitPos = vfxRoot.parent.InverseTransformPoint(gameEffectSpec.Context.hitPoint);
                var dir = (targetPos - sourcePos).normalized;
                
                var hitType = cue.hitStateType switch
                {
                    EHitStateType.Light => ECharacterStateType.LightHit,
                    EHitStateType.Heavy => ECharacterStateType.HeavyHit,
                    EHitStateType.HitLaunch => ECharacterStateType.HitUpHorizontal,
                    _ => ECharacterStateType.LightHit,
                };
                
                targetCcc.FsmComp.TryEnterState(hitType, new CharacterStateParam()
                {
                    Vector3Param = dir,
                    BoolParam = cue.changeDir,
                });
            }
        }
    }
}