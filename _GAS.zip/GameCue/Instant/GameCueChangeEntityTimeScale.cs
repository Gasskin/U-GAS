// using System;
// using MemoryPack;
// using Meow.Runtime.HotUpdate.BattleConfig.gameAction;
// using Sirenix.OdinInspector;
// using UnityEngine;

// namespace Meow.Runtime.HotUpdate
// {
//     [Serializable]
//     [MemoryPackable]
//     public partial class GameCueChangeEntityTimeScale : GameCue
//     {
//         [Flags]
//         public enum ETarget
//         {
//             [InspectorName("自身")]
//             Self = 1 << 0,
//             [InspectorName("目标")]
//             Target = 1 << 1,
//         }

//         [InlineProperty]
//         public StuckTimeParam stuckTimeParam;

//         [LabelText("影响目标")]
//         [LabelWidth(100)]
//         public ETarget target = ETarget.Self | ETarget.Target;

//         public override GameCueSpec CreateSpec(GameEffectSpec spec)
//         {
//             var cue = GameCueSpec.Alloc<GameCueChangeEntityTimeScaleSpec>();
//             cue.Init(this, spec);
//             return cue;
//         }
//     }

//     public class GameCueChangeEntityTimeScaleSpec : GameCueSpec, IGameCueInstant
//     {
//         public void OnTrigger()
//         {
//             if (gameCue is not GameCueChangeEntityTimeScale cue)
//             {
//                 return;
//             }
//             if (cue.target.HasFlag(GameCueChangeEntityTimeScale.ETarget.Self))
//             {
//                 if (World.Current.TryGetEntityComp<TimeScaleComp>(gameEffectSpec.Source.Entity, out var timeScaleComp))
//                 {
//                     timeScaleComp.SetTimeScaleForSeconds(cue.stuckTimeParam.timeScale, cue.stuckTimeParam.duration);
//                 }
//             }
//             if (cue.target.HasFlag(GameCueChangeEntityTimeScale.ETarget.Target))
//             {
//                 if (World.Current.TryGetEntityComp<TimeScaleComp>(gameEffectSpec.Target.Entity, out var timeScaleComp))
//                 {
//                     timeScaleComp.SetTimeScaleForSeconds(cue.stuckTimeParam.timeScale, cue.stuckTimeParam.duration);
//                 }
//             }
//         }

//         protected override void OnClear()
//         {
//         }
//     }
// }