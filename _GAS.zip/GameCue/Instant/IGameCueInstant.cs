﻿namespace Meow.Runtime.HotUpdate
{
    public interface IGameCueInstant
    {
        void OnTrigger();
    }
}