using System;
using MemoryPack;
using Meow.Runtime.HotUpdate.BattleConfig;
using Sirenix.OdinInspector;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    [Serializable]
    [MemoryPackable]
    public partial class GameCueTimeline : GameCue
    {
        [MemoryPackIgnore]
        [LabelText("技能配置"), LabelWidth(100)]
        public SkillConfigWrap skill;

        [NonSerialized]
        public int skillId;

        public override GameCueSpec CreateSpec(GameEffectSpec spec)
        {
            var cue = GameCueSpec.Alloc<GameCueTimelineSpec>();
            cue.Init(this, spec);
            return cue;
        }
        
        [MemoryPackOnSerializing]
        public void OnSerializing()
        {
            skillId = skill.data.id;
        }
    }

    public class GameCueTimelineSpec : GameCueSpec, IGameCueInstant
    {
        public void OnTrigger()
        {
            if (gameCue is not GameCueTimeline cue)
            {
                return;
            }
            World.Current.TryGetEntityComp(gameEffectSpec.Target.Entity, out UnitGameObjectComp unit);
            var transform = unit.Root.transform;
            var casterEntityInfo = new BattleCasterEntityInfo()
            {
                sourceID = gameEffectSpec.Source.Entity,
                Position = transform.position,
                Rotation = transform.eulerAngles,
            };
            BattleUnitHelper.CreateCasterEntity(casterEntityInfo, out var casterId);
            World.Current.TryGetEntityComp<SpellCasterComp>(casterId, out var spell);
            spell.Spell(cue.skillId);
        }

        protected override void OnClear()
        {
        }
    }
}