using System;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    public class GhrothEnergyVfxController : MonoBehaviour
    {
        public static GhrothEnergyVfxController Instance;

        public GameObject energy1;
        public GameObject energy2;
        public GameObject energy3;
        
        private void Awake()
        {
            Instance = this;
        }
    }
}