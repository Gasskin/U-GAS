using MemoryPack;
using Sirenix.OdinInspector;
using Meow.Runtime.AOT;
using Meow.Runtime.HotUpdate.BattleConfig.gameAction;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 食物消耗事件
    /// 在 GameAction_SiaConsumeFood 中触发
    /// 用于希娅被动2监听：队友吃食物恢复希娅奥义能量
    /// </summary>
    public struct FoodConsumedEvent : IEventMessage
    {
        /// <summary>
        /// 消耗者的Entity ID
        /// </summary>
        public uint consumerId;

        /// <summary>
        /// 消耗的食物数量
        /// </summary>
        public int count;

        /// <summary>
        /// 发送食物消耗事件
        /// </summary>
        public static void SendMsg(uint consumerId, int count = 1)
        {
            new FoodConsumedEvent
            {
                consumerId = consumerId,
                count = count
            }.SendMessage();
        }
    }
}