using Meow.Runtime.AOT;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 食物吸附管理器
    /// 职责：
    /// 1. 管理所有已落地的食物
    /// 2. 定时检测吸附（根据角色buff数量动态调整间隔）
    /// 3. 按距离排序，优先吸附近的食物
    /// 4. 清理过期食物
    /// </summary>
    public class FoodAttractManager : MonoBehaviour
    {
        private static FoodAttractManager s_Instance;
        public static FoodAttractManager Instance => s_Instance;

        // 所有已落地的食物列表
        private List<FoodInfo> _landedFoods = new List<FoodInfo>();
        // 缓存：有效食物列表（食物 + 距离 + 配置效果）
        private readonly List<(FoodInfo food, float distance, GameEffectObjectField[] effects)> _validFoods = new();
        // 缓存：每种buff的缺失层数
        private readonly Dictionary<ulong, int> _needCountByGeId = new();
        // 缓存：单帧内待预扣的buff id 列表
        private readonly List<ulong> _tempGeIdsToDeduct = new(4);

        // 检测计时器
        private float _checkTimer = 0f;

        // 当前检测间隔（根据buff数量动态调整）
        private float _currentCheckInterval = 1f;

        private class FoodInfo
        {
            public uint entityId;           // 食物Entity ID
            public FoodAttractComp comp;    // 食物组件引用
            //public float checkInterval;     // 检测间隔（从配置读取）
        }

        private void Awake()
        {
            if (s_Instance != null && s_Instance != this)
            {
                Destroy(gameObject);
                return;
            }

            s_Instance = this;
        }

        private void OnDestroy()
        {
            if (s_Instance == this)
            {
                s_Instance = null;
            }
        }

        private void Update()
        {
            if (_landedFoods.Count == 0)
            {
                return;
            }

            // 累计计时器
            _checkTimer += Time.deltaTime;

            // 未到检测间隔，跳过
            if (_checkTimer < _currentCheckInterval)
            {
                return;
            }

            // 重置计时器
            _checkTimer = 0f;

            // 执行吸附检测
            TryAttractFoods();
        }

        /// <summary>
        /// 注册已落地的食物
        /// </summary>
        public void RegisterLandedFood(uint entityId, FoodAttractComp comp)
        {
            // 避免重复注册
            if (_landedFoods.Any(f => f.entityId == entityId))
            {
                return;
            }

            _landedFoods.Add(new FoodInfo
            {
                entityId = entityId,
                comp = comp,
                //checkInterval = 0 // 不再使用，保留字段以防后续需要
            });

            GameLog.Debug($"[FoodAttractManager] 注册食物 EntityId: {entityId}");
        }

        /// <summary>
        /// 注销食物（被吸附或过期）
        /// </summary>
        public void UnregisterFood(uint entityId)
        {
            var removed = _landedFoods.RemoveAll(f => f.entityId == entityId);
            if (removed > 0)
            {
                GameLog.Debug($"[FoodAttractManager] 注销食物 EntityId: {entityId}");
            }
        }

        /// <summary>
        /// 强制立即检查吸附
        /// 当果冻buff被清除后调用，跳过计时器等待
        /// </summary>
        public void ForceCheckAttract()
        {
            _checkTimer = 0f;
            TryAttractFoods();
        }

        /// <summary>
        /// 尝试吸附食物
        /// </summary>
        private void TryAttractFoods()
        {
            // 1. 获取当前在场角色
            var targetId = World.Current.GetSystem<BattleTeamSystem>()?.ActiveRoleEntity ?? 0;
            if (targetId == 0)
            {
                return;
            }

            // 2. 检查角色GAS
            if (!World.Current.TryGetEntityComp<GameAbilitySystem>(targetId, out var targetGas))
            {
                return;
            }

            // 3. 根据角色buff数量动态调整检测间隔
            UpdateCheckIntervalByBuffCount(targetGas);

            // 4. 获取目标位置
            if (!World.Current.TryGetEntityComp<UnitGameObjectComp>(targetId, out var targetUnitGo))
            {
                return;
            }

            var targetPos = targetUnitGo.Root.transform.position;

            // 5. 使用缓存容器构建有效食物列表和buff缺口信息
            _validFoods.Clear();
            _needCountByGeId.Clear();

            var remainingNeedCount = BuildValidFoodsAndBuffNeeds(targetId, targetGas, targetPos);
            if (remainingNeedCount <= 0 || _validFoods.Count == 0)
            {
                return;
            }

            // 6. 执行吸附逻辑
            AttractFoodsByDistance(targetId, remainingNeedCount);
        }

        /// <summary>
        /// 构建有效食物列表，并统计每种buff的缺失层数
        /// 返回：还有缺口的buff种类数量
        /// </summary>
        private int BuildValidFoodsAndBuffNeeds(uint targetId, GameAbilitySystem targetGas, Vector3 targetPos)
        {
            foreach (var info in _landedFoods)
            {
                if (info.comp == null || !info.comp.CanAttractTo(targetId))
                {
                    continue;
                }

                var distance = GetDistance(info.entityId, targetPos);
                if (distance < 0)
                {
                    continue;
                }

                var effects = info.comp.GetFoodEffects();
                if (effects == null || effects.Length == 0)
                {
                    continue;
                }

                _validFoods.Add((info, distance, effects));

                // 顺便收集buff缺失层数（每种只计算一次）
                foreach (var effectField in effects)
                {
                    var effect = effectField?.effect;
                    if (effect == null)
                    {
                        continue;
                    }

                    var geId = effect.assetId;
                    if (geId == 0 || _needCountByGeId.ContainsKey(geId))
                    {
                        continue;
                    }

                    var currentCount = FoodAttractHelper.GetGameEffectCount(targetGas, geId);
                    var maxCount = FoodAttractHelper.GetMaxStackCount(effect);
                    var needCount = maxCount - currentCount;
                    _needCountByGeId[geId] = needCount > 0 ? needCount : 0;
                }
            }

            if (_needCountByGeId.Count == 0)
            {
                return 0;
            }

            var remainingNeedCount = 0;
            foreach (var kv in _needCountByGeId)
            {
                if (kv.Value > 0)
                {
                    remainingNeedCount++;
                }
            }

            return remainingNeedCount;
        }

        /// <summary>
        /// 按距离顺序吸附食物，每种buff只吸收至缺失层数
        /// </summary>
        private void AttractFoodsByDistance(uint targetId, int remainingNeedCount)
        {
            if (remainingNeedCount <= 0)
            {
                return;
            }

            // 按距离排序（近的优先）
            _validFoods.Sort((a, b) => a.distance.CompareTo(b.distance));

            // 按距离依次吸附食物
            foreach (var (food, distance, effects) in _validFoods)
            {
                if (effects == null || effects.Length == 0)
                {
                    continue;
                }

                // 一次遍历：判断缺口 + 收集需要预扣的geId
                _tempGeIdsToDeduct.Clear();
                foreach (var effectField in effects)
                {
                    var effect = effectField?.effect;
                    if (effect == null)
                    {
                        continue;
                    }

                    var geId = effect.assetId;
                    if (geId != 0 && _needCountByGeId.TryGetValue(geId, out var need) && need > 0)
                    {
                        _tempGeIdsToDeduct.Add(geId);
                    }
                }

                // 没有任何buff存在缺口，跳过这颗食物
                if (_tempGeIdsToDeduct.Count == 0)
                {
                    continue;
                }

                // 开始吸附
                food.comp.StartAttract(targetId);
                GameLog.Debug($"[FoodAttractManager] 开始吸附食物 EntityId: {food.entityId}, 距离: {distance:F2}米");

                // 预扣缺口
                foreach (var geId in _tempGeIdsToDeduct)
                {
                    var newNeed = _needCountByGeId[geId] - 1;
                    _needCountByGeId[geId] = newNeed;

                    // 如果这种buff刚好补满，减少计数
                    if (newNeed == 0)
                    {
                        remainingNeedCount--;
                    }
                }

                // 如果所有buff都没有缺口了，提前结束
                if (remainingNeedCount <= 0)
                {
                    break;
                }
            }
        }

        /// <summary>
        /// 根据角色buff数量动态调整检测间隔
        /// 规则：
        /// - buff少（0-4个）→ 快速检测（0.5秒）
        /// - buff中等（5-9个）→ 正常检测（1秒）
        /// - buff较多（10-14个）→ 慢速检测（2秒）
        /// - buff全满（15个）→ 停止检测（不会进入此方法）
        /// </summary>
        private void UpdateCheckIntervalByBuffCount(GameAbilitySystem targetGas)
        {
            // 从第一个食物获取effects配置（所有食物的effects应该是一样的）
            if (_landedFoods.Count == 0 || _landedFoods[0].comp == null)
            {
                _currentCheckInterval = 1f; // 默认1秒
                return;
            }

            var foodEffects = _landedFoods[0].comp.GetFoodEffects();
            if (foodEffects == null || foodEffects.Length == 0)
            {
                _currentCheckInterval = 1f; // 默认1秒
                return;
            }

            // 获取总buff数量
            var totalBuffCount = FoodAttractHelper.GetTotalEffectFieldCount(targetGas, foodEffects);

            // 根据buff数量调整检测间隔
            if (totalBuffCount <= 4)
            {
                _currentCheckInterval = 0.5f; // buff少，快速检测
            }
            else if (totalBuffCount <= 9)
            {
                _currentCheckInterval = 1f; // buff中等，正常检测
            }
            else
            {
                _currentCheckInterval = 2f; // buff较多，慢速检测
            }
        }

        /// <summary>
        /// 获取食物到目标的距离
        /// </summary>
        private float GetDistance(uint foodEntityId, Vector3 targetPos)
        {
            if (!World.Current.TryGetEntityComp<UnitGameObjectComp>(foodEntityId, out var foodUnitGo))
            {
                return -1f; // 无效距离
            }

            return Vector3.Distance(foodUnitGo.Root.transform.position, targetPos);
        }

        /// <summary>
        /// 清空所有食物（用于战斗结束等场景）
        /// </summary>
        public void Clear()
        {
            _landedFoods.Clear();
            _checkTimer = 0f;
            _currentCheckInterval = 1f;
            GameLog.Debug("[FoodAttractManager] 清空所有食物");
        }
    }
}

