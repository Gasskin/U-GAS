using Cysharp.Threading.Tasks;
using Meow.Runtime.AOT;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 食物Buff公共系统
    /// 职责：
    /// 1. 管理食物Buff的应用（需要记录希娅作为Source）
    /// 2. 监听PostHit事件，清除施法者身上的果冻Buff
    /// 3. 果冻buff被清除后触发吸附检查
    /// </summary>
    [SystemBelong(WorldType.BattleWorld)]
    [SystemBelong(WorldType.WildernessWorld)]
    public class FoodBuffSystem : WorldSystem
    {
        /// <summary>
        /// 希娅的GAS引用（食物效果的Source）
        /// </summary>
        private GameAbilitySystem _siaGas;

        /// <summary>
        /// 记录每个实体身上的果冻Buff ID
        /// </summary>
        private ulong _jellyBuffId;

        protected override UniTask Awake()
        {
            // 监听技能阶段事件（用于清除烤肉buff）
            eventGroup.AddListener<SkillStageTrigger>(OnSkillStageTrigger);
            return UniTask.CompletedTask;
        }

        /// <summary>
        /// 注册希娅的GAS（希娅进入战斗时调用）
        /// </summary>
        public void RegisterSiaGas(GameAbilitySystem siaGas)
        {
            _siaGas = siaGas;
            GameLog.Info($"[FoodBuffSystem] 注册希娅GAS: {siaGas.Entity}");
        }

        /// <summary>
        /// 注销希娅的GAS（希娅离开战斗时调用）
        /// </summary>
        public void UnRegisterSiaGas()
        {
            _siaGas = null;
            _jellyBuffId = 0;
            GameLog.Info($"[FoodBuffSystem] 注销希娅GAS，清理果冻Buff记录");
        }

        /// <summary>
        /// 应用食物效果
        /// Source = 希娅（数值计算基于希娅的属性）
        /// Target = 吃食物的角色
        /// </summary>
        /// <param name="foodEffect">食物对应的GameEffect</param>
        /// <param name="targetGas">吃食物的角色GAS</param>
        public void ApplyFoodEffect(GameEffectObjectField foodEffect, GameAbilitySystem targetGas)
        {
            if (_siaGas == null)
            {
                GameLog.Warning($"[FoodBuffSystem] 希娅GAS未注册，无法应用食物效果");
                return;
            }

            if (foodEffect == null || foodEffect.effect == null)
            {
                GameLog.Warning($"[FoodBuffSystem] 食物效果未配置");
                return;
            }

            // 关键：Source是希娅，Target是吃食物的人
            // 这样 AttributeBasedMagnitude 中 fromTarget=false 时会取希娅的属性
            var buffId = _siaGas.ApplyGameEffectTo(foodEffect, targetGas);

            // 如果是果冻Buff（带有State_Buff_Sia_Jelly标签），记录ID
            if (buffId > 0 && foodEffect.effect.GrantedTagsContainer.HasTag(EGameTag.State_Buff_Sia_Jelly))
            {
                _jellyBuffId = buffId;
                GameLog.Info($"[FoodBuffSystem] 应用果冻Buff到 {targetGas.Entity}，BuffID: {buffId}");
            }
            else
            {
                GameLog.Info($"[FoodBuffSystem] 应用食物效果到 {targetGas.Entity}");
            }
        }

        /// <summary>
        /// 技能阶段触发回调
        /// 在PostHit阶段，清除施法者身上的果冻Buff，然后触发吸附检查
        /// </summary>
        private void OnSkillStageTrigger(IEventMessage message)
        {
            if (message is not SkillStageTrigger e)
            {
                return;
            }

            // 只在PostHit阶段处理
            if (e.stage != ESkillStage.PostHit)
            {
                return;
            }

            // 获取施法者的GAS
            if (!World.Current.TryGetEntityComp<GameAbilitySystem>(e.casterId, out var casterGas))
            {
                return;
            }

            // 检查施法者身上是否有果冻Buff
            if (!casterGas.GameTagComponent.HasTag(EGameTag.State_Buff_Sia_Jelly))
            {
                return;
            }

            // 清除施法者身上的果冻Buff（使用RemoveGameEffectSpecById）
            if (_jellyBuffId > 0) 
            {
                casterGas.GameEffectComponent.RemoveGameEffectSpecById(_jellyBuffId);
                GameLog.Debug($"[FoodBuffSystem] 清除果冻Buff，BuffID: {_jellyBuffId}，触发吸附检查");
            }
            // 触发吸附检查（因为buff数量不足了）
            TriggerFoodAttract();
        }

        /// <summary>
        /// 触发食物吸附检查
        /// 当果冻buff被清除后，需要检查是否有新的果冻可以吸附
        /// </summary>
        private void TriggerFoodAttract()
        {
            // 通知FoodAttractManager立即检查吸附
            // FoodAttractManager的Update会定期检查，但清除buff后需要立即触发
            var manager = FoodAttractManager.Instance;
            if (manager != null)
            {
                manager.ForceCheckAttract();
            }
        }
    }
}

