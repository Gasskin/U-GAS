using System;
using System.Collections.Generic;
using cfg.attribute;
using cfg.hero;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    public class AbnormalAccruePipeline
    {
        private static AbnormalAccruePipeline s_Instance;

        public static AbnormalAccruePipeline Instance
        {
            get
            {
                s_Instance ??= new AbnormalAccruePipeline();
                return s_Instance;
            }
        }

        public event Func<GameEffectSpec, Element, float, float> OnPreProcessAbnormalAccrue
        {
            add => _preProcessAbnormalAccrue.Add(value);
            remove => _preProcessAbnormalAccrue.Remove(value);
        }

        private List<Func<GameEffectSpec, Element, float, float>> _preProcessAbnormalAccrue = new();

        public event Action<GameEffectSpec, Element> OnTriggerAbnormal;
        public event Action<GameEffectSpec, Element, EGameTag> OnTriggerChaos;

        public event Action<GameEffectSpec, Element> OnPostTriggerAbnormal;

        public event Action<GameEffectSpec, Element> OnPostProcessAbnormalAccrue;

        public void Process(GameEffectSpec spec, Element element, float add)
        {
            if (!World.Current.TryGetEntityComp(spec.Target.Entity, out AbnormalAccrueStatisticComp aap))
            {
                throw new ArgumentOutOfRangeException($"{spec.Target.Entity} 不存在异常积蓄权重组件");
            }

            var now = element switch
            {
                Element.Light => spec.Target.GameAttributeComponent.GetAttribute(AttributeId.NowLightAccrue),
                Element.Void => spec.Target.GameAttributeComponent.GetAttribute(AttributeId.NowVoidAccrue),
                Element.Time => spec.Target.GameAttributeComponent.GetAttribute(AttributeId.NowTimeAccrue),
                Element.Energy => spec.Target.GameAttributeComponent.GetAttribute(AttributeId.NowEnergyAccrue),
                Element.Create => spec.Target.GameAttributeComponent.GetAttribute(AttributeId.NowCreateAccrue),
                Element.Dark => spec.Target.GameAttributeComponent.GetAttribute(AttributeId.NowDarkAccrue),
                Element.Space => spec.Target.GameAttributeComponent.GetAttribute(AttributeId.NowSpaceAccrue),
                _ => null,
            };
            var max = element switch
            {
                Element.Light => spec.Target.GameAttributeComponent.GetAttribute(AttributeId.MaxLightAccrue),
                Element.Void => spec.Target.GameAttributeComponent.GetAttribute(AttributeId.MaxVoidAccrue),
                Element.Time => spec.Target.GameAttributeComponent.GetAttribute(AttributeId.MaxTimeAccrue),
                Element.Energy => spec.Target.GameAttributeComponent.GetAttribute(AttributeId.MaxEnergyAccrue),
                Element.Create => spec.Target.GameAttributeComponent.GetAttribute(AttributeId.MaxCreateAccrue),
                Element.Dark => spec.Target.GameAttributeComponent.GetAttribute(AttributeId.MaxDarkAccrue),
                Element.Space => spec.Target.GameAttributeComponent.GetAttribute(AttributeId.MaxSpaceAccrue),
                _ => null,
            };

            if (now == null || max == null)
            {
                throw new ArgumentOutOfRangeException($"异常的元素类型：{element}, 找不到对应的异常积蓄属性");
            }

            var abNormal = GetAbnormalTagByElement(element);

            // 前处理
            for (int i = 0; i < _preProcessAbnormalAccrue.Count; i++)
            {
                var func = _preProcessAbnormalAccrue[i];
                add = func(spec, element, add);
            }

            if (abNormal == EGameTag.None)
            {
                throw new ArgumentOutOfRangeException($"异常的元素类型：{element}, 找不到对应的异常类型");
            }

            // 积蓄满了； 触发 -> 清空积蓄值 -> 清空贡献记录
            if (now.BaseValue + add >= max.CurrentValue)
            {
                // 如果目标身上存在异常，并且类型和当前不同，则触发紊乱
                if (spec.Target.GameTagComponent.HasTag(EGameTag.State_DeBuff_Abnormal)
                    && !spec.Target.GameTagComponent.HasTag(abNormal))
                {
                    OnTriggerChaos?.Invoke(spec, element, abNormal);
                }
                aap.AddContribution(element, spec.Source.Entity, max.CurrentValue - now.CurrentValue);
                OnTriggerAbnormal?.Invoke(spec, element);
                now.SetBaseValue(0);
                aap.ClearContribution(element);
                OnPostTriggerAbnormal?.Invoke(spec, element);
            }
            else
            {
                aap.AddContribution(element, spec.Source.Entity, add);
                now.SetBaseValue(now.BaseValue + add);
            }
            OnPostProcessAbnormalAccrue?.Invoke(spec, element);
        }

        public EGameTag GetAbnormalTagByElement(Element element)
        {
            return element switch
            {
                Element.Light => EGameTag.State_DeBuff_Abnormal_Light,
                Element.Void => EGameTag.State_DeBuff_Abnormal_Void,
                Element.Time => EGameTag.State_DeBuff_Abnormal_Time,
                Element.Energy => EGameTag.State_DeBuff_Abnormal_Energy,
                Element.Create => EGameTag.State_DeBuff_Abnormal_Create,
                Element.Dark => EGameTag.State_DeBuff_Abnormal_Dart,
                Element.Space => EGameTag.State_DeBuff_Abnormal_Space,
                _ => EGameTag.None,
            };
        }
    }
}