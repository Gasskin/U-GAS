using System;
using System.Collections.Generic;
using cfg.attribute;
using Meow.Runtime.AOT;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    public class HpRecoverPipeline
    {
        private static HpRecoverPipeline s_Instance;

        public static HpRecoverPipeline Instance
        {
            get
            {
                s_Instance ??= new HpRecoverPipeline();
                return s_Instance;
            }
        }

        public event Func<GameEffectSpec, float, float> OnPreHpRecover
        {
            add => _preHpRecover.Add(value);
            remove => _preHpRecover.Remove(value);
        }

        private List<Func<GameEffectSpec, float, float>> _preHpRecover = new();

        public void Process(GameEffectSpec spec, float value)
        {
            // 治疗前处理（可能修改治疗量）
            for (int i = 0; i < _preHpRecover.Count; i++)
            {
                value = _preHpRecover[i].Invoke(spec, value);
            }

            // 应用治疗
            var now = spec.Target.GameAttributeComponent.GetAttribute(AttributeId.NowHp).BaseValue;
            spec.Target.GameAttributeComponent.GetAttribute(AttributeId.NowHp).SetBaseValue(now + value, false);

            // 触发治疗跳字（除非被禁用）
            if (value > 0)
            {
                ShowHealNumber(spec.Target.Entity, spec.Context.hitPoint, (int)value);
            }
        }

        /// <summary>
        /// 显示治疗跳字
        /// </summary>
        private void ShowHealNumber(uint targetId, Vector3 hitPos, int healValue)
        {
            // 获取目标位置（如果hitPos为零向量，使用目标的位置）
            if (hitPos == Vector3.zero)
            {
                if (World.Current.TryGetEntityComp<UnitGameObjectComp>(targetId, out var unitGo))
                {
                    hitPos = unitGo.Root.transform.position;
                }
            }

            // 发送治疗跳字事件
            HealNumberEvent.SendMsg(targetId, hitPos, healValue);

            GameLog.Debug($"[HpRecoverPipeline] 治疗跳字: EntityId={targetId}, 治疗量={healValue}");
        }

        /// <summary>
        /// 手动触发治疗跳字（用于分段显示）
        /// </summary>
        public static void TriggerHealNumber(uint targetId, Vector3 hitPos, int healValue)
        {
            Instance.ShowHealNumber(targetId, hitPos, healValue);
        }
    }

    /// <summary>
    /// 治疗跳字事件
    /// </summary>
    public struct HealNumberEvent : IEventMessage
    {
        public uint targetId;
        public Vector3 hitPos;
        public int healValue;

        public static void SendMsg(uint targetId, Vector3 hitPos, int healValue)
        {
            new HealNumberEvent
            {
                targetId = targetId,
                hitPos = hitPos,
                healValue = healValue
            }.SendMessage();
        }
    }
}