using System;
using System.Collections.Generic;
using cfg.attribute;
using Meow.Runtime.AOT;
using UnityEngine;

namespace Meow.Runtime.HotUpdate
{
    /// <summary>
    /// 韧性值减少事件
    /// </summary>
    public struct ToughnessReduceEvent : IEventMessage
    {
        public int skillDbId;
        // 目标实体
        public uint target;
        
        // 韧性值减少量
        public float toughnessReduce;
        
        // 减少前的韧性值
        public float previousToughness;
        
        // 减少后的韧性值
        public float currentToughness;
        
        // 是否触发破韧
        public bool isBreakTriggered;
        
        // 受击坐标
        public Vector3 hitPoint;
        
        // 来源GameEffectSpec
        public GameEffectSpec sourceSpec;

        public void Send()
        {
            this.SendMessage();
        }
    }

    /// <summary>
    /// 韧性值处理管道
    /// 负责处理韧性值的减少、破韧判定和相关事件触发
    /// </summary>
    public class ToughnessPipeline
    {
        private static ToughnessPipeline s_Instance;

        public static ToughnessPipeline Instance
        {
            get
            {
                s_Instance ??= new ToughnessPipeline();
                return s_Instance;
            }
        }
        
        /// <summary>
        /// 韧性值减少前处理事件
        /// 可以用于修改韧性值减少量
        /// </summary>
        public event Func<GameEffectSpec, ToughnessReduceEvent, float> PreProcessToughnessReduce
        {
            add => _preProcessToughnessReduce.Add(value);
            remove => _preProcessToughnessReduce.Remove(value);
        }

        private List<Func<GameEffectSpec, ToughnessReduceEvent, float>> _preProcessToughnessReduce = new();


        /// <summary>
        /// 破韧触发事件
        /// 当韧性值降到0或以下时触发
        /// </summary>
        public event Action<GameEffectSpec, ToughnessReduceEvent> OnToughnessBreak;

        /// <summary>
        /// 处理韧性值减少
        /// </summary>
        /// <param name="spec">GameEffect规格</param>
        /// <param name="toughnessEvent">韧性值减少量</param>
        public void Process(GameEffectSpec spec, ToughnessReduceEvent toughnessEvent)
        {
            if (spec?.Target?.GameAttributeComponent == null)
            {
                GameLog.Warning("[ToughnessPipeline] 目标或属性组件为空，跳过韧性值处理");
                return;
            }

            var toughnessAttr = spec.Target.GameAttributeComponent.GetAttribute(AttributeId.NowTough);
            if (toughnessAttr == null)
            {
                GameLog.Warning("[ToughnessPipeline] 目标没有韧性值属性，跳过处理");
                return;
            }

            float previousToughness = toughnessAttr.CurrentValue;

            toughnessEvent.previousToughness = previousToughness;
            // var toughnessEvent = new ToughnessReduceEvent
            // {
            //     target = spec.Target.Entity,
            //     toughnessReduce = toughnessReduceAmount,
            //     previousToughness = previousToughness,
            //     hitPoint = spec.Context.hitPoint,
            //     sourceSpec = spec
            // };

            // 前处理：允许修改韧性值减少量
            foreach (var func in _preProcessToughnessReduce)
            {
                toughnessEvent.toughnessReduce = func(spec, toughnessEvent);
            }

            // 应用韧性值减少
            float newToughness = Mathf.Max(0f, previousToughness - toughnessEvent.toughnessReduce);
            toughnessAttr.SetBaseValue(newToughness);
            
            // 更新事件中的当前韧性值
            toughnessEvent.currentToughness = newToughness;
            
            // 判断是否触发破韧
            bool wasNotBroken = previousToughness > 0f;
            bool isNowBroken = newToughness <= 0f;
            toughnessEvent.isBreakTriggered = wasNotBroken && isNowBroken;

            GameLog.Info($"[ToughnessPipeline] 韧性值处理: {spec.Target.Entity} " +
                        $"韧性值 {previousToughness:F2} -> {newToughness:F2} " +
                        $"(减少 {toughnessEvent.toughnessReduce:F2}) " +
                        $"破韧触发: {toughnessEvent.isBreakTriggered}");

            // 如果触发破韧，先处理破韧事件
            if (toughnessEvent.isBreakTriggered)
            {
                OnToughnessBreak?.Invoke(spec, toughnessEvent);
                GameLog.Info($"[ToughnessPipeline] 触发破韧: {spec.Target.Entity}");
            }
            
            // 发送韧性值减少事件
            toughnessEvent.Send();
        }

        /// <summary>
        /// 注册破韧监听器
        /// 用于ToughnessBreakAbilitySpec注册监听
        /// </summary>
        /// <param name="targetEntity">目标实体ID</param>
        /// <param name="callback">破韧回调</param>
        public void RegisterToughnessBreakListener(uint targetEntity, Action<GameEffectSpec, ToughnessReduceEvent> callback)
        {
            OnToughnessBreak += (spec, evt) =>
            {
                if (evt.target == targetEntity)
                {
                    callback(spec, evt);
                }
            };
        }

        /// <summary>
        /// 移除破韧监听器
        /// </summary>
        /// <param name="callback">要移除的回调</param>
        public void UnregisterToughnessBreakListener(Action<GameEffectSpec, ToughnessReduceEvent> callback)
        {
            OnToughnessBreak -= callback;
        }
    }
}
