using System;
using System.Collections.Generic;
using cfg.attribute;
using Meow.Runtime.HotUpdate.BattleConfig;

namespace Meow.Runtime.HotUpdate
{
    public class DamagePipeline
    {
        private static DamagePipeline s_Instance;

        public static DamagePipeline Instance
        {
            get
            {
                s_Instance ??= new DamagePipeline();
                return s_Instance;
            }
        }

        public event Func<GameEffectSpec, CommonSkillDamageEvent, float> OnPreProcessDamage
        {
            add => _preProcessDamage.Add(value);
            remove => _preProcessDamage.Remove(value);
        }

        private List<Func<GameEffectSpec, CommonSkillDamageEvent, float>> _preProcessDamage = new();

        public event Action<GameEffectSpec, CommonSkillDamageEvent> OnPreProcessDie;

        public event Action<GameEffectSpec, CommonSkillDamageEvent> OnPostProcessDamage;

        public event Action<GameEffectSpec, CommonSkillDamageEvent> OnPostProcessDie;

        public void Process(GameEffectSpec spec, CommonSkillDamageEvent e)
        {
            foreach (var func in _preProcessDamage)
            {
                e.originalDamage = func(spec, e);
            }
            var targetHp = spec.Target.GameAttributeComponent.GetCurrentValue(AttributeId.NowHp);
            if (targetHp <= 0)
            {
                return;
            }
            var targetShield = spec.Target.GameAttributeComponent.GetCurrentValue(AttributeId.Shield);
            if (e.originalDamage > targetShield)
            {
                var newDamage = e.originalDamage - targetShield;
                targetHp -= newDamage;
                spec.Target.GameAttributeComponent.GetAttribute(AttributeId.NowHp).SetBaseValue(targetHp, false);
                spec.Target.GameAttributeComponent.GetAttribute(AttributeId.Shield).SetBaseValue(0, false);
                e.trueDamage = newDamage;
                // 濒死，死亡前
                if (targetHp <= 0)
                {
                    OnPreProcessDie?.Invoke(spec, e);
                }
            }
            else
            {
                targetShield -= e.originalDamage;
                spec.Target.GameAttributeComponent.GetAttribute(AttributeId.Shield).SetBaseValue(targetShield, false);
                e.trueDamage = 0;
            }

            OnPostProcessDamage?.Invoke(spec, e);
            // UI逻辑，GAS内不走Event
            e.Send();

            // 死亡
            if (spec.Target.GameAttributeComponent.GetCurrentValue(AttributeId.NowHp) <= 0)
            {
                OnPostProcessDie?.Invoke(spec, e);
            }
        }
    }
}