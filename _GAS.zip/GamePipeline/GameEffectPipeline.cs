using System;
using System.Collections.Generic;
using UnityEngine.Pool;

namespace Meow.Runtime.HotUpdate
{
    public class GameEffectPipeline
    {
        private static GameEffectPipeline s_Instance;

        public static GameEffectPipeline Instance
        {
            get
            {
                s_Instance ??= new GameEffectPipeline();
                return s_Instance;
            }
        }

        // 返回False表示阻止添加GE，返回True则正常继续
        public event Func<GameEffectSpec, bool> OnPreAddGameEffect
        {
            add => _onPreAddGameEffect.Add(value);
            remove => _onPreAddGameEffect.Remove(value);
        }

        private List<Func<GameEffectSpec, bool>> _onPreAddGameEffect = new();

        /// <summary>
        /// GE被移除后触发
        /// </summary>
        public event Action<GameEffectSpec> OnPostRemoveGameEffect;

        /// <summary>
        /// 只针对于Stack类型的GE，添加GE后事件
        /// </summary>
        public event Action<GameEffectSpec> OnPostAddNewGameEffect;

        /// <summary>
        /// Stack类型GE层数变化时触发
        /// </summary>
        public event Action<GameEffectSpec> OnPostGameEffectStackChange;

        /// <summary>
        /// 周期效果GE执行时触发
        /// 参数1: 持有周期效果的父GE
        /// 参数2: 被执行的周期GE
        /// </summary>
        public event Action<GameEffectSpec, GameEffectSpec> OnPeriodExecute;

        public bool ProcessOnPreAddGameEffect(GameEffectSpec spec)
        {
            for (int i = 0; i < _onPreAddGameEffect.Count; i++)
            {
                if (!_onPreAddGameEffect[i](spec))
                {
                    return false;
                }
            }
            return true;
        }

        public void ProcessOnPostRemoveGameEffect(GameEffectSpec spec)
        {
            OnPostRemoveGameEffect?.Invoke(spec);
        }

        public void ProcessOnPostAddNewGameEffect(GameEffectSpec spec)
        {
            OnPostAddNewGameEffect?.Invoke(spec);
        }

        public void ProcessOnPostGameEffectStackChange(GameEffectSpec spec)
        {
            OnPostGameEffectStackChange?.Invoke(spec);
        }

        /// <summary>
        /// 周期效果执行时调用
        /// </summary>
        /// <param name="parentSpec">持有周期效果的父GE（如 GE_Buff_RedTeaHealBuff）</param>
        /// <param name="periodSpec">被执行的周期GE</param>
        public void ProcessOnPeriodExecute(GameEffectSpec parentSpec, GameEffectSpec periodSpec)
        {
            OnPeriodExecute?.Invoke(parentSpec, periodSpec);
        }
    }
}
